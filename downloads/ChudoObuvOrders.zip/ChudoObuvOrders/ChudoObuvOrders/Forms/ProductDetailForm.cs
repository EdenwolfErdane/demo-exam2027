using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма подробной информации о товаре.
    //
    // Компоненты (в дизайнере):
    //   picImage         — картинка
    //   lblManufacturer  — производство
    //   lblName          — наименование
    //   lblCategory      — категория
    //   lblPrice         — цена
    //   lblComposition   — состав
    //   lblDescription   — описание
    //   lblSizeCaption   — подпись "Размер"
    //   cmbSize          — размеры товара
    //   lblQuantityCaption — подпись "Количество"
    //   numQuantity      — количество пар
    //   errorProvider    — показ ошибок
    //   btnAddToCart     — "Добавить в заказ"
    //   btnBack          — "Назад"
    public partial class ProductDetailForm : Form
    {
        // id товара.
        private readonly int _productId;
        // Репозиторий товаров.
        private readonly ProductRepository _productRepository = new ProductRepository();
        // Складские позиции товара.
        private System.Collections.Generic.List<StockItem> _stockItems;

        public ProductDetailForm(int productId)
        {
            _productId = productId;
            InitializeComponent();

            // Внешний вид.
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            Font = AppStyle.DefaultFont;

            // Обработчики.
            cmbSize.SelectedIndexChanged += (s, e) => UpdateQuantityLimit();
            btnAddToCart.Click += BtnAddToCart_Click;
            btnBack.Click += (s, e) => Close();

            // При загрузке — читаем товар.
            Load += (s, e) => LoadProduct();
        }

        // Загружает данные товара и заполняет поля.
        private void LoadProduct()
        {
            try
            {
                var product = _productRepository.GetById(_productId);
                Text = $"Чудо Обувь — {product.ProductName}";

                lblManufacturer.Text = product.Manufacturer;
                lblName.Text = product.ProductName;
                lblCategory.Text = product.CategoryName;
                lblPrice.Text = $"{product.DiscountPrice:N0} ₽" +
                    (product.HasDiscount ? $"  (было {product.BasePrice:N0} ₽)" : "");
                lblComposition.Text = product.Composition;
                lblDescription.Text = product.Description;

                // Картинка или заглушка.
                string imagePath = System.IO.Path.Combine(AppStyle.ImagesFolder, product.ImageFileName ?? "");
                picImage.Image = System.IO.File.Exists(imagePath)
                    ? System.Drawing.Image.FromFile(imagePath)
                    : System.Drawing.Image.FromFile(AppStyle.PlaceholderImagePath);

                // Оставляем только размеры, которые есть в наличии.
                _stockItems = _productRepository.GetStockItems(_productId).Where(i => i.Quantity > 0).ToList();
                cmbSize.Items.Clear();
                foreach (var item in _stockItems) cmbSize.Items.Add(item.SizeValue);

                // Если ничего нет — выключаем всё и предупреждаем.
                bool anySizeAvailable = cmbSize.Items.Count > 0;
                cmbSize.Enabled = numQuantity.Enabled = btnAddToCart.Enabled = anySizeAvailable;

                if (anySizeAvailable) cmbSize.SelectedIndex = 0;
                else MessageBox.Show(this, "К сожалению, все размеры этой модели сейчас распроданы.",
                        "Нет в наличии", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось загрузить карточку товара: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        // Выбранная складская позиция (по выбранному размеру).
        private StockItem SelectedStockItem =>
            _stockItems?.FirstOrDefault(i => i.SizeValue == (decimal)cmbSize.SelectedItem);

        // Обновляет максимум у поля "Количество" под выбранный размер.
        private void UpdateQuantityLimit()
        {
            var stockItem = SelectedStockItem;
            if (stockItem == null) return;
            numQuantity.Maximum = stockItem.Quantity;
            numQuantity.Value = 1;
        }

        // "Добавить в заказ".
        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();
            var stockItem = SelectedStockItem;

            // Размер не выбран — ошибка.
            if (stockItem == null)
            {
                errorProvider.SetError(cmbSize, "Выберите размер.");
                return;
            }

            // Количество выходит за пределы остатка — ошибка.
            if (numQuantity.Value < 1 || numQuantity.Value > stockItem.Quantity)
            {
                errorProvider.SetError(numQuantity, $"Доступно не более {stockItem.Quantity} пар.");
                return;
            }

            var product = _productRepository.GetById(_productId);

            // Если такая позиция уже в корзине — увеличиваем количество.
            var existing = CartContext.Items.FirstOrDefault(i => i.StockItemId == stockItem.StockItemId);
            if (existing != null)
            {
                existing.Quantity += (int)numQuantity.Value;
            }
            else
            {
                // Иначе добавляем новую.
                CartContext.Items.Add(new CartItem
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    Manufacturer = product.Manufacturer,
                    StockItemId = stockItem.StockItemId,
                    SizeValue = stockItem.SizeValue,
                    Quantity = (int)numQuantity.Value,
                    UnitPrice = product.DiscountPrice
                });
            }

            MessageBox.Show(this, "Товар добавлен в заказ.", "Готово",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
    }
}