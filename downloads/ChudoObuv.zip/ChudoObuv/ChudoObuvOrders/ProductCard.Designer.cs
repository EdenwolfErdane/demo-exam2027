partial class ProductCard
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            this.pnlRoot = new System.Windows.Forms.Panel();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // pnlRoot
            this.pnlRoot.Name = "pnlRoot";
            this.pnlRoot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRoot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRoot.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlRoot.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.pnlRoot.Click += new System.EventHandler(this.Card_Click);
            // picImage
            this.picImage.Name = "picImage";
            this.picImage.Location = new System.Drawing.Point(5, 5);
            this.picImage.Size = new System.Drawing.Size(80, 78);
            this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picImage.Click += new System.EventHandler(this.Card_Click);
            // lblInfo
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Location = new System.Drawing.Point(95, 8);
            this.lblInfo.Size = new System.Drawing.Size(660, 75);
            this.lblInfo.Click += new System.EventHandler(this.Card_Click);
            // lblPrice
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Location = new System.Drawing.Point(760, 8);
            this.lblPrice.Size = new System.Drawing.Size(110, 75);
            this.lblPrice.Click += new System.EventHandler(this.Card_Click);
            this.Controls.Add(this.pnlRoot);
            this.pnlRoot.Controls.Add(this.picImage);
            this.pnlRoot.Controls.Add(this.lblInfo);
            this.pnlRoot.Controls.Add(this.lblPrice);
            // ProductCard
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Size = new System.Drawing.Size(880, 90);
            this.Font = new System.Drawing.Font("Calibri", 10F);
            this.ResumeLayout(false);
    }

        private System.Windows.Forms.Panel pnlRoot;
        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblPrice;
}
