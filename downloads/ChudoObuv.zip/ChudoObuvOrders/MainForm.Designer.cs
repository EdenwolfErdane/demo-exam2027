﻿partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
        this.pnlHeader = new System.Windows.Forms.Panel();
        this.lblTitle = new System.Windows.Forms.Label();
        this.txtSearch = new System.Windows.Forms.TextBox();
        this.cmbSort = new System.Windows.Forms.ComboBox();
        this.cmbCat = new System.Windows.Forms.ComboBox();
        this.btnCart = new System.Windows.Forms.Button();
        this.btnOrders = new System.Windows.Forms.Button();
        this.btnStats = new System.Windows.Forms.Button();
        this.btnExit = new System.Windows.Forms.Button();
        this.lblUser = new System.Windows.Forms.Label();
        this.pnlCatalog = new System.Windows.Forms.FlowLayoutPanel();
        this.pnlHeader.SuspendLayout();
        this.SuspendLayout();
        //
        // pnlHeader — бирюзовая шапка с поиском/кнопками
        //
        this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.pnlHeader.Controls.Add(this.lblTitle);
        this.pnlHeader.Controls.Add(this.txtSearch);
        this.pnlHeader.Controls.Add(this.cmbSort);
        this.pnlHeader.Controls.Add(this.cmbCat);
        this.pnlHeader.Controls.Add(this.btnCart);
        this.pnlHeader.Controls.Add(this.btnOrders);
        this.pnlHeader.Controls.Add(this.btnStats);
        this.pnlHeader.Controls.Add(this.btnExit);
        this.pnlHeader.Controls.Add(this.lblUser);
        this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
        this.pnlHeader.Location = new System.Drawing.Point(0, 0);
        this.pnlHeader.Name = "pnlHeader";
        this.pnlHeader.Size = new System.Drawing.Size(1040, 78);
        //
        // lblTitle
        //
        this.lblTitle.AutoSize = true;
        this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14F);
        this.lblTitle.ForeColor = System.Drawing.Color.White;
        this.lblTitle.Location = new System.Drawing.Point(20, 12);
        this.lblTitle.Name = "lblTitle";
        this.lblTitle.Size = new System.Drawing.Size(115, 25);
        this.lblTitle.Text = "Каталог обуви";
        //
        // txtSearch — поиск по наименованию и описанию
        //
        this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.txtSearch.Location = new System.Drawing.Point(20, 44);
        this.txtSearch.Name = "txtSearch";
        this.txtSearch.Size = new System.Drawing.Size(200, 25);
        this.txtSearch.TabIndex = 0;
        this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
        //
        // cmbSort — сортировка
        //
        this.cmbSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.cmbSort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.cmbSort.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.cmbSort.Items.AddRange(new object[] {
        "Без сортировки",
        "Цена ↑",
        "Цена ↓"});
        this.cmbSort.Location = new System.Drawing.Point(228, 44);
        this.cmbSort.Name = "cmbSort";
        this.cmbSort.Size = new System.Drawing.Size(150, 23);
        this.cmbSort.TabIndex = 1;
        this.cmbSort.SelectedIndexChanged += new System.EventHandler(this.cmbSort_SelectedIndexChanged);
        //
        // cmbCat — фильтр по категории
        //
        this.cmbCat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.cmbCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.cmbCat.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.cmbCat.Location = new System.Drawing.Point(388, 44);
        this.cmbCat.Name = "cmbCat";
        this.cmbCat.Size = new System.Drawing.Size(180, 23);
        this.cmbCat.TabIndex = 2;
        this.cmbCat.SelectedIndexChanged += new System.EventHandler(this.cmbCat_SelectedIndexChanged);
        //
        // btnCart
        //
        this.btnCart.BackColor = System.Drawing.Color.White;
        this.btnCart.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnCart.FlatAppearance.BorderSize = 0;
        this.btnCart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnCart.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnCart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnCart.Location = new System.Drawing.Point(580, 42);
        this.btnCart.Name = "btnCart";
        this.btnCart.Size = new System.Drawing.Size(110, 30);
        this.btnCart.TabIndex = 3;
        this.btnCart.Text = "Корзина (0)";
        this.btnCart.UseVisualStyleBackColor = false;
        this.btnCart.Click += new System.EventHandler(this.btnCart_Click);
        //
        // btnOrders
        //
        this.btnOrders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnOrders.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnOrders.FlatAppearance.BorderSize = 0;
        this.btnOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnOrders.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnOrders.ForeColor = System.Drawing.Color.White;
        this.btnOrders.Location = new System.Drawing.Point(700, 42);
        this.btnOrders.Name = "btnOrders";
        this.btnOrders.Size = new System.Drawing.Size(95, 30);
        this.btnOrders.TabIndex = 4;
        this.btnOrders.Text = "Заказы";
        this.btnOrders.UseVisualStyleBackColor = false;
        this.btnOrders.Click += new System.EventHandler(this.btnOrders_Click);
        //
        // btnStats
        //
        this.btnStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnStats.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnStats.FlatAppearance.BorderSize = 0;
        this.btnStats.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnStats.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnStats.ForeColor = System.Drawing.Color.White;
        this.btnStats.Location = new System.Drawing.Point(803, 42);
        this.btnStats.Name = "btnStats";
        this.btnStats.Size = new System.Drawing.Size(95, 30);
        this.btnStats.TabIndex = 5;
        this.btnStats.Text = "Статистика";
        this.btnStats.UseVisualStyleBackColor = false;
        this.btnStats.Click += new System.EventHandler(this.btnStats_Click);
        //
        // btnExit
        //
        this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(87)))));
        this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnExit.FlatAppearance.BorderSize = 0;
        this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnExit.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.btnExit.Location = new System.Drawing.Point(908, 42);
        this.btnExit.Name = "btnExit";
        this.btnExit.Size = new System.Drawing.Size(110, 30);
        this.btnExit.TabIndex = 6;
        this.btnExit.Text = "Выйти";
        this.btnExit.UseVisualStyleBackColor = false;
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
        //
        // lblUser — ФИО вошедшего или «Гость»
        //
        this.lblUser.AutoSize = true;
        this.lblUser.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.lblUser.ForeColor = System.Drawing.Color.White;
        this.lblUser.Location = new System.Drawing.Point(908, 17);
        this.lblUser.Name = "lblUser";
        this.lblUser.Size = new System.Drawing.Size(40, 15);
        this.lblUser.Text = "Гость";
        //
        // pnlCatalog — лента карточек товара
        //
        this.pnlCatalog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
        | System.Windows.Forms.AnchorStyles.Left)
        | System.Windows.Forms.AnchorStyles.Right)));
        this.pnlCatalog.AutoScroll = true;
        this.pnlCatalog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.pnlCatalog.Location = new System.Drawing.Point(0, 78);
        this.pnlCatalog.Name = "pnlCatalog";
        this.pnlCatalog.Padding = new System.Windows.Forms.Padding(16, 16, 16, 16);
        this.pnlCatalog.Size = new System.Drawing.Size(1040, 580);
        this.pnlCatalog.TabIndex = 8;
        //
        // MainForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.White;
        this.ClientSize = new System.Drawing.Size(1040, 658);
        this.Controls.Add(this.pnlCatalog);
        this.Controls.Add(this.pnlHeader);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MinimumSize = new System.Drawing.Size(800, 500);
        this.Name = "MainForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Чудо Обувь — Каталог";
        this.pnlHeader.ResumeLayout(false);
        this.pnlHeader.PerformLayout();
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.Panel pnlHeader;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.TextBox txtSearch;
    private System.Windows.Forms.ComboBox cmbSort;
    private System.Windows.Forms.ComboBox cmbCat;
    private System.Windows.Forms.Button btnCart;
    private System.Windows.Forms.Button btnOrders;
    private System.Windows.Forms.Button btnStats;
    private System.Windows.Forms.Button btnExit;
    private System.Windows.Forms.Label lblUser;
    private System.Windows.Forms.FlowLayoutPanel pnlCatalog;
}
