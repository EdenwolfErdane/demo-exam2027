using System.ComponentModel;

// Одна строка корзины.
public class CartLine
{
    public int StockItemId { get; set; }
    public string Name { get; set; }
    public decimal Size { get; set; }
    public int Qty { get; set; }
    public decimal Price { get; set; }
}

// Кто сейчас вошёл и что лежит в корзине.
public static class Session
{
    public static int UserId;
    public static string FullName = "";
    public static string Role = "";
    public static bool LoggedOut;
    public static BindingList<CartLine> Cart = new BindingList<CartLine>();

    public static bool IsAuth { get { return UserId > 0; } }
    public static bool IsAdmin { get { return Role.StartsWith("Админ"); } }
    public static bool IsStaff { get { return IsAdmin || Role.StartsWith("Менед"); } }

    public static void Clear()
    {
        UserId = 0; FullName = ""; Role = "";
        Cart.Clear();
    }
}
