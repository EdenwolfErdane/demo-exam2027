using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма статистики заказов (Задание 5).
    //
    // Компоненты (в дизайнере):
    //   gridOrders                 — таблица всех заказов с суммами
    //   pnlStats                   — панель с общими показателями
    //   lblCount/lblRevenue/lblAverage — количество, выручка, средний чек
    //   btnClose                   — закрыть
    public partial class StatisticsForm : Form
    {
        // Репозиторий статистики.
        private readonly StatisticsRepository _statisticsRepository = new StatisticsRepository();

        public StatisticsForm()
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Статистика заказов";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlStats.BackColor = AppStyle.SecondaryBackgroundColor;
            pnlBottom.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;

            // Закрыть.
            btnClose.Click += (s, e) => Close();

            // При загрузке — заполняем таблицу и показатели.
            Load += (s, e) => RefreshStatistics();
        }

        // Перечитывает заказы и пересчитывает показатели.
        private void RefreshStatistics()
        {
            try
            {
                // Заказы с итоговой суммой каждого.
                var rows = _statisticsRepository.GetOrderTotals();

                // Таблица: номер, дата, клиент, сумма.
                gridOrders.DataSource = null;
                gridOrders.DataSource = rows
                    .Select(r => new { Номер = r.OrderId, Дата = r.OrderDate, Клиент = r.ClientName, Сумма = r.OrderTotal })
                    .ToList();

                // Три общих показателя.
                var stats = _statisticsRepository.GetStatistics();
                lblCount.Text = $"Всего заказов: {stats.OrdersCount}";
                lblRevenue.Text = $"Общая выручка: {stats.TotalRevenue:N2} ₽";
                lblAverage.Text = $"Средний чек: {stats.AverageOrder:N2} ₽";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось загрузить статистику: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
