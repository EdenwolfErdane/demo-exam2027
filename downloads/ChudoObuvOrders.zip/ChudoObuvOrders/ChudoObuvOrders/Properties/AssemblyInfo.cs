using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ChudoObuvOrders")]
[assembly: AssemblyDescription("Чудо Обувь — система оформления заказа обуви")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ChudoObuvOrders")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("3f7b2e2a-8b7d-4b7a-9f6d-9c2f6a5b7c11")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
