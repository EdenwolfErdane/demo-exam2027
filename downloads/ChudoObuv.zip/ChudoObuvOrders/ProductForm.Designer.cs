﻿partial class ProductForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductForm));
        this.pnlHeader = new System.Windows.Forms.Panel();
        this.lblFormTitle = new System.Windows.Forms.Label();
        this.picImage = new System.Windows.Forms.PictureBox();
        this.pnlInfo = new System.Windows.Forms.Panel();
        this.lblName = new System.Windows.Forms.Label();
        this.lblManufacturer = new System.Windows.Forms.Label();
        this.lblCategory = new System.Windows.Forms.Label();
        this.lblPrice = new System.Windows.Forms.Label();
        this.lblComposition = new System.Windows.Forms.Label();
        this.lblDescription = new System.Windows.Forms.Label();
        this.lblRange = new System.Windows.Forms.Label();
        this.lblSizeCaption = new System.Windows.Forms.Label();
        this.cmbSize = new System.Windows.Forms.ComboBox();
        this.lblQtyCaption = new System.Windows.Forms.Label();
        this.nudQty = new System.Windows.Forms.NumericUpDown();
        this.btnAdd = new System.Windows.Forms.Button();
        this.btnBack = new System.Windows.Forms.Button();
        this.pnlHeader.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
        this.pnlInfo.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.nudQty)).BeginInit();
        this.SuspendLayout();
        //
        // pnlHeader — бирюзовая шапка с названием товара
        //
        this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.pnlHeader.Controls.Add(this.lblFormTitle);
        this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
        this.pnlHeader.Location = new System.Drawing.Point(0, 0);
        this.pnlHeader.Name = "pnlHeader";
        this.pnlHeader.Size = new System.Drawing.Size(620, 56);
        //
        // lblFormTitle
        //
        this.lblFormTitle.AutoSize = true;
        this.lblFormTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
        this.lblFormTitle.ForeColor = System.Drawing.Color.White;
        this.lblFormTitle.Location = new System.Drawing.Point(20, 14);
        this.lblFormTitle.Name = "lblFormTitle";
        this.lblFormTitle.Size = new System.Drawing.Size(83, 23);
        this.lblFormTitle.Text = "Карточка";
        //
        // picImage — фото товара слева
        //
        this.picImage.BackColor = System.Drawing.Color.White;
        this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.picImage.Location = new System.Drawing.Point(20, 76);
        this.picImage.Name = "picImage";
        this.picImage.Size = new System.Drawing.Size(220, 220);
        this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        this.picImage.TabStop = false;
        //
        // pnlInfo — правая колонка с реквизитами
        //
        this.pnlInfo.BackColor = System.Drawing.Color.White;
        this.pnlInfo.Controls.Add(this.lblName);
        this.pnlInfo.Controls.Add(this.lblManufacturer);
        this.pnlInfo.Controls.Add(this.lblCategory);
        this.pnlInfo.Controls.Add(this.lblPrice);
        this.pnlInfo.Controls.Add(this.lblComposition);
        this.pnlInfo.Location = new System.Drawing.Point(260, 76);
        this.pnlInfo.Name = "pnlInfo";
        this.pnlInfo.Size = new System.Drawing.Size(340, 220);
        //
        // lblName — наименование (жирно, крупно)
        //
        this.lblName.AutoEllipsis = true;
        this.lblName.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
        this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblName.Location = new System.Drawing.Point(0, 0);
        this.lblName.Name = "lblName";
        this.lblName.Size = new System.Drawing.Size(340, 28);
        //
        // lblManufacturer
        //
        this.lblManufacturer.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.lblManufacturer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(116)))), ((int)(((byte)(122)))));
        this.lblManufacturer.Location = new System.Drawing.Point(0, 32);
        this.lblManufacturer.Name = "lblManufacturer";
        this.lblManufacturer.Size = new System.Drawing.Size(340, 20);
        //
        // lblCategory
        //
        this.lblCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.lblCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(116)))), ((int)(((byte)(122)))));
        this.lblCategory.Location = new System.Drawing.Point(0, 54);
        this.lblCategory.Name = "lblCategory";
        this.lblCategory.Size = new System.Drawing.Size(340, 20);
        //
        // lblPrice — крупная цена со скидкой
        //
        this.lblPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 14F);
        this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.lblPrice.Location = new System.Drawing.Point(0, 78);
        this.lblPrice.Name = "lblPrice";
        this.lblPrice.Size = new System.Drawing.Size(340, 26);
        //
        // lblComposition
        //
        this.lblComposition.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.lblComposition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblComposition.Location = new System.Drawing.Point(0, 108);
        this.lblComposition.Name = "lblComposition";
        this.lblComposition.Size = new System.Drawing.Size(340, 50);
        //
        // lblDescription — описание во всю ширину
        //
        this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.lblDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblDescription.Location = new System.Drawing.Point(20, 312);
        this.lblDescription.Name = "lblDescription";
        this.lblDescription.Size = new System.Drawing.Size(580, 60);
        //
        // lblRange — размерный ряд
        //
        this.lblRange.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.lblRange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.lblRange.Location = new System.Drawing.Point(20, 380);
        this.lblRange.Name = "lblRange";
        this.lblRange.Size = new System.Drawing.Size(580, 22);
        //
        // lblSizeCaption
        //
        this.lblSizeCaption.AutoSize = true;
        this.lblSizeCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.lblSizeCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblSizeCaption.Location = new System.Drawing.Point(20, 416);
        this.lblSizeCaption.Name = "lblSizeCaption";
        this.lblSizeCaption.Size = new System.Drawing.Size(155, 19);
        this.lblSizeCaption.Text = "Доступные размеры";
        //
        // cmbSize
        //
        this.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.cmbSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.cmbSize.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.cmbSize.Location = new System.Drawing.Point(180, 412);
        this.cmbSize.Name = "cmbSize";
        this.cmbSize.Size = new System.Drawing.Size(110, 25);
        this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
        //
        // lblQtyCaption
        //
        this.lblQtyCaption.AutoSize = true;
        this.lblQtyCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.lblQtyCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblQtyCaption.Location = new System.Drawing.Point(310, 416);
        this.lblQtyCaption.Name = "lblQtyCaption";
        this.lblQtyCaption.Size = new System.Drawing.Size(56, 19);
        this.lblQtyCaption.Text = "Кол-во";
        //
        // nudQty
        //
        this.nudQty.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.nudQty.Location = new System.Drawing.Point(372, 412);
        this.nudQty.Minimum = new decimal(new int[] {
        1,
        0,
        0,
        0});
        this.nudQty.Name = "nudQty";
        this.nudQty.Size = new System.Drawing.Size(80, 25);
        this.nudQty.Value = new decimal(new int[] {
        1,
        0,
        0,
        0});
        //
        // btnAdd — кнопка «В заказ»
        //
        this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnAdd.FlatAppearance.BorderSize = 0;
        this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnAdd.ForeColor = System.Drawing.Color.White;
        this.btnAdd.Location = new System.Drawing.Point(20, 458);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(200, 36);
        this.btnAdd.Text = "В заказ";
        this.btnAdd.UseVisualStyleBackColor = false;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        //
        // btnBack
        //
        this.btnBack.BackColor = System.Drawing.Color.White;
        this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnBack.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnBack.FlatAppearance.BorderSize = 1;
        this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnBack.Location = new System.Drawing.Point(230, 458);
        this.btnBack.Name = "btnBack";
        this.btnBack.Size = new System.Drawing.Size(200, 36);
        this.btnBack.Text = "Назад";
        this.btnBack.UseVisualStyleBackColor = false;
        this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
        //
        // ProductForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.ClientSize = new System.Drawing.Size(620, 510);
        this.Controls.Add(this.pnlHeader);
        this.Controls.Add(this.picImage);
        this.Controls.Add(this.pnlInfo);
        this.Controls.Add(this.lblDescription);
        this.Controls.Add(this.lblRange);
        this.Controls.Add(this.lblSizeCaption);
        this.Controls.Add(this.cmbSize);
        this.Controls.Add(this.lblQtyCaption);
        this.Controls.Add(this.nudQty);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.btnBack);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MaximizeBox = false;
        this.Name = "ProductForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Чудо Обувь — Товар";
        this.pnlHeader.ResumeLayout(false);
        this.pnlHeader.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
        this.pnlInfo.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.nudQty)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.Panel pnlHeader;
    private System.Windows.Forms.Label lblFormTitle;
    private System.Windows.Forms.PictureBox picImage;
    private System.Windows.Forms.Panel pnlInfo;
    private System.Windows.Forms.Label lblName;
    private System.Windows.Forms.Label lblManufacturer;
    private System.Windows.Forms.Label lblCategory;
    private System.Windows.Forms.Label lblPrice;
    private System.Windows.Forms.Label lblComposition;
    private System.Windows.Forms.Label lblDescription;
    private System.Windows.Forms.Label lblRange;
    private System.Windows.Forms.Label lblSizeCaption;
    private System.Windows.Forms.ComboBox cmbSize;
    private System.Windows.Forms.Label lblQtyCaption;
    private System.Windows.Forms.NumericUpDown nudQty;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnBack;
}
