﻿using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.Session;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Главное окно — каталог товаров.
    //
    // Компоненты (в дизайнере):
    //   picLogo         — логотип
    //   lblUserFullName — ФИО пользователя (правый верх)
    //   btnLoginLogout  — "Войти" / "Выйти"
    //   pnlToolbar      — панель инструментов (видна только авторизованным)
    //   txtSearch       — поиск по имени/описанию
    //   cmbCategory     — фильтр по категории
    //   cmbSort         — сортировка по цене
    //   pnlCatalog      — контейнер карточек товаров
    //   btnCart         — переход в корзину
    //   btnOrders       — раздел "Заказы" (только менеджер/админ)
    //   btnStats        — окно статистики заказов (только менеджер/админ)
    public partial class MainForm : Form
    {
        // Репозиторий товаров.
        private readonly ProductRepository _productRepository = new ProductRepository();

        public MainForm()
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Каталог товаров";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlHeader.BackColor = AppStyle.SecondaryBackgroundColor;
            pnlToolbar.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;
            picLogo.Image = System.Drawing.Image.FromFile(AppStyle.LogoPath);

            // Обработчики.
            btnLoginLogout.Click += BtnLoginLogout_Click;
            btnCart.Click += (s, e) => OpenCart();
            btnOrders.Click += (s, e) => { Navigator.OpenModal(this, new OrdersForm()); RefreshCatalog(); };
            btnStats.Click += (s, e) => { Navigator.OpenModal(this, new StatisticsForm()); RefreshCatalog(); };

            // Любое изменение поиска/фильтра/сортировки перечитывает каталог.
            txtSearch.TextChanged += (s, e) => RefreshCatalog();
            cmbSort.SelectedIndexChanged += (s, e) => RefreshCatalog();
            cmbCategory.SelectedIndexChanged += (s, e) => RefreshCatalog();

            // При загрузке — заполняем списки и строим каталог.
            Load += (s, e) =>
            {
                LoadCategories();
                ApplySessionState();
                RefreshCatalog();
            };
        }

        // Заполняет выпадающие списки категорий и сортировки.
        private void LoadCategories()
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("Все категории");
            foreach (var category in _productRepository.GetCategories())
                cmbCategory.Items.Add(category.CategoryName);
            cmbCategory.SelectedIndex = 0;

            cmbSort.Items.Clear();
            cmbSort.Items.AddRange(new object[] { "Без сортировки", "Сначала дешёвые", "Сначала дорогие" });
            cmbSort.SelectedIndex = 0;
        }

        // Показ/скрытие элементов в зависимости от роли.
        private void ApplySessionState()
        {
            bool authorized = CurrentSession.IsAuthorized;

            lblUserFullName.Text = authorized ? CurrentSession.CurrentUser.FullName : "";
            btnLoginLogout.Text = authorized ? "Выйти" : "Войти";

            pnlToolbar.Visible = authorized;     // поиск/фильтр/сортировка — только авторизованным
            btnCart.Visible = authorized;
            btnOrders.Visible = CurrentSession.IsManagerOrAdmin;
            btnStats.Visible = CurrentSession.IsManagerOrAdmin;

            // Если не авторизован — сбрасываем фильтры.
            if (!authorized)
            {
                txtSearch.Text = "";
                cmbCategory.SelectedIndex = 0;
                cmbSort.SelectedIndex = 0;
            }
        }

        // "Войти" / "Выйти".
        private void BtnLoginLogout_Click(object sender, EventArgs e)
        {
            // Если уже вошли — выходим.
            if (CurrentSession.IsAuthorized)
            {
                CurrentSession.LogOut();
                CartContext.Clear();
                ApplySessionState();
                RefreshCatalog();
                return;
            }

            // Иначе открываем форму входа.
            using (var loginForm = new LoginForm())
            {
                var result = Navigator.OpenModal(this, loginForm);
                if (result == DialogResult.OK || result == DialogResult.Ignore)
                {
                    ApplySessionState();
                    RefreshCatalog();
                }
            }
        }

        // Перечитывает каталог и перерисовывает карточки.
        private void RefreshCatalog()
        {
            try
            {
                // Определяем режим сортировки.
                PriceSortOrder sortOrder = cmbSort.SelectedIndex == 1 ? PriceSortOrder.Ascending
                                          : cmbSort.SelectedIndex == 2 ? PriceSortOrder.Descending
                                          : PriceSortOrder.None;

                // Определяем id категории, если выбрана не "Все категории".
                int? categoryId = null;
                if (CurrentSession.IsAuthorized && cmbCategory.SelectedIndex > 0)
                {
                    categoryId = _productRepository.GetCategories()
                        .First(c => c.CategoryName == (string)cmbCategory.SelectedItem)
                        .CategoryId;
                }

                // Поиск работает только у авторизованных.
                string search = CurrentSession.IsAuthorized ? txtSearch.Text : "";

                // Получаем список товаров.
                var products = _productRepository.GetCatalog(search, categoryId, sortOrder);

                // Перерисовываем карточки.
                pnlCatalog.SuspendLayout();
                pnlCatalog.Controls.Clear();
                foreach (var product in products)
                {
                    var card = new ProductCardControl();
                    card.Bind(product);
                    card.ProductClicked += (s, productId) => OpenProductDetail(productId);
                    pnlCatalog.Controls.Add(card);
                }
                pnlCatalog.ResumeLayout();

                // Обновляем счётчик в кнопке корзины.
                btnCart.Text = $"Корзина ({CartContext.Items.Count})";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось загрузить каталог: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Открывает карточку товара.
        private void OpenProductDetail(int productId)
        {
            using (var form = new ProductDetailForm(productId))
            {
                Navigator.OpenModal(this, form);
                RefreshCatalog(); // могли измениться остатки — обновим
            }
        }

        // Открывает корзину.
        private void OpenCart()
        {
            using (var form = new CartForm())
            {
                Navigator.OpenModal(this, form);
                RefreshCatalog();
            }
        }
    }
}