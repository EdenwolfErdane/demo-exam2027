using ChudoObuvOrders.Models;

namespace ChudoObuvOrders.Session
{
    // Хранит текущего авторизованного пользователя в рамках сеанса приложения.
    public static class CurrentSession
    {
        // Текущий пользователь или null, если никто не вошёл.
        public static User CurrentUser { get; set; }

        // Авторизован ли кто-то.
        public static bool IsAuthorized => CurrentUser != null;

        // Это менеджер или админ?
        public static bool IsManagerOrAdmin =>
            CurrentUser != null &&
            (CurrentUser.Role == UserRole.Manager || CurrentUser.Role == UserRole.Administrator);

        // Это админ?
        public static bool IsAdministrator =>
            CurrentUser != null && CurrentUser.Role == UserRole.Administrator;

        // Выход — просто обнуляем пользователя.
        public static void LogOut() => CurrentUser = null;
    }
}