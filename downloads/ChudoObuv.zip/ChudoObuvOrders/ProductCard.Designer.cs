﻿partial class ProductCard
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.pnlRoot = new System.Windows.Forms.Panel();
        this.picImage = new System.Windows.Forms.PictureBox();
        this.lblInfo = new System.Windows.Forms.Label();
        this.lblPrice = new System.Windows.Forms.Label();
        this.pnlRoot.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
        this.SuspendLayout();
        //
        // pnlRoot — вся карточка: кликабельная, со скруглением через бордюр
        //
        this.pnlRoot.BackColor = System.Drawing.Color.White;
        this.pnlRoot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.pnlRoot.Controls.Add(this.picImage);
        this.pnlRoot.Controls.Add(this.lblInfo);
        this.pnlRoot.Controls.Add(this.lblPrice);
        this.pnlRoot.Cursor = System.Windows.Forms.Cursors.Hand;
        this.pnlRoot.Dock = System.Windows.Forms.DockStyle.Fill;
        this.pnlRoot.Name = "pnlRoot";
        this.pnlRoot.Click += new System.EventHandler(this.Card_Click);
        //
        // picImage — фото товара (80×80, Zoom)
        //
        this.picImage.BackColor = System.Drawing.Color.White;
        this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.picImage.Location = new System.Drawing.Point(10, 10);
        this.picImage.Name = "picImage";
        this.picImage.Size = new System.Drawing.Size(80, 80);
        this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        this.picImage.TabStop = false;
        this.picImage.Click += new System.EventHandler(this.Card_Click);
        //
        // lblInfo — производство | наименование, категория, состав
        //
        this.lblInfo.AutoEllipsis = true;
        this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblInfo.Location = new System.Drawing.Point(100, 10);
        this.lblInfo.Name = "lblInfo";
        this.lblInfo.Size = new System.Drawing.Size(560, 80);
        this.lblInfo.Click += new System.EventHandler(this.Card_Click);
        //
        // lblPrice — цена + «много/мало»
        //
        this.lblPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 11F);
        this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.lblPrice.Location = new System.Drawing.Point(670, 10);
        this.lblPrice.Name = "lblPrice";
        this.lblPrice.Size = new System.Drawing.Size(195, 80);
        this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        this.lblPrice.Click += new System.EventHandler(this.Card_Click);
        //
        // ProductCard
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.Controls.Add(this.pnlRoot);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.Margin = new System.Windows.Forms.Padding(0, 0, 0, 12);
        this.Size = new System.Drawing.Size(880, 100);
        this.pnlRoot.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.Panel pnlRoot;
    private System.Windows.Forms.PictureBox picImage;
    private System.Windows.Forms.Label lblInfo;
    private System.Windows.Forms.Label lblPrice;
}
