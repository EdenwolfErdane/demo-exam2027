namespace ChudoObuvOrders.Forms
{
    partial class ProductDetailForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.Label lblManufacturer;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblCompositionCaption;
        private System.Windows.Forms.Label lblComposition;
        private System.Windows.Forms.Label lblDescriptionCaption;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblSizeCaption;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.Label lblQuantityCaption;
        private System.Windows.Forms.NumericUpDown numQuantity;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.Button btnAddToCart;
        private System.Windows.Forms.Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.lblManufacturer = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblCompositionCaption = new System.Windows.Forms.Label();
            this.lblComposition = new System.Windows.Forms.Label();
            this.lblDescriptionCaption = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblSizeCaption = new System.Windows.Forms.Label();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.lblQuantityCaption = new System.Windows.Forms.Label();
            this.numQuantity = new System.Windows.Forms.NumericUpDown();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnAddToCart = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            //
            // picImage
            //
            this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picImage.Location = new System.Drawing.Point(20, 50);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(260, 260);
            this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            //
            // lblManufacturer
            //
            this.lblManufacturer.AutoSize = true;
            this.lblManufacturer.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Italic);
            this.lblManufacturer.Location = new System.Drawing.Point(300, 20);
            this.lblManufacturer.Name = "lblManufacturer";
            this.lblManufacturer.Size = new System.Drawing.Size(90, 19);
            //
            // lblName
            //
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold);
            this.lblName.Location = new System.Drawing.Point(300, 42);
            this.lblName.MaximumSize = new System.Drawing.Size(440, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(120, 28);
            //
            // lblCategory
            //
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(300, 78);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(60, 19);
            //
            // lblPrice
            //
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Bold);
            this.lblPrice.Location = new System.Drawing.Point(300, 102);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(80, 26);
            //
            // lblCompositionCaption
            //
            this.lblCompositionCaption.AutoSize = true;
            this.lblCompositionCaption.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblCompositionCaption.Location = new System.Drawing.Point(300, 140);
            this.lblCompositionCaption.Name = "lblCompositionCaption";
            this.lblCompositionCaption.Size = new System.Drawing.Size(60, 19);
            this.lblCompositionCaption.Text = "Состав";
            //
            // lblComposition
            //
            this.lblComposition.AutoSize = false;
            this.lblComposition.Location = new System.Drawing.Point(300, 162);
            this.lblComposition.Name = "lblComposition";
            this.lblComposition.Size = new System.Drawing.Size(440, 45);
            //
            // lblDescriptionCaption
            //
            this.lblDescriptionCaption.AutoSize = true;
            this.lblDescriptionCaption.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblDescriptionCaption.Location = new System.Drawing.Point(20, 322);
            this.lblDescriptionCaption.Name = "lblDescriptionCaption";
            this.lblDescriptionCaption.Size = new System.Drawing.Size(90, 19);
            this.lblDescriptionCaption.Text = "Описание";
            //
            // lblDescription
            //
            this.lblDescription.AutoSize = false;
            this.lblDescription.Location = new System.Drawing.Point(20, 344);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(720, 50);
            //
            // lblSizeCaption
            //
            this.lblSizeCaption.AutoSize = true;
            this.lblSizeCaption.Location = new System.Drawing.Point(20, 410);
            this.lblSizeCaption.Name = "lblSizeCaption";
            this.lblSizeCaption.Size = new System.Drawing.Size(50, 19);
            this.lblSizeCaption.Text = "Размер";
            //
            // cmbSize
            //
            this.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSize.Location = new System.Drawing.Point(20, 432);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(140, 27);
            //
            // lblQuantityCaption
            //
            this.lblQuantityCaption.AutoSize = true;
            this.lblQuantityCaption.Location = new System.Drawing.Point(180, 410);
            this.lblQuantityCaption.Name = "lblQuantityCaption";
            this.lblQuantityCaption.Size = new System.Drawing.Size(80, 19);
            this.lblQuantityCaption.Text = "Количество";
            //
            // numQuantity
            //
            this.numQuantity.Location = new System.Drawing.Point(180, 432);
            this.numQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            this.numQuantity.Name = "numQuantity";
            this.numQuantity.Size = new System.Drawing.Size(100, 27);
            //
            // errorProvider
            //
            this.errorProvider.ContainerControl = this;
            //
            // btnAddToCart
            //
            this.btnAddToCart.Location = new System.Drawing.Point(20, 480);
            this.btnAddToCart.Name = "btnAddToCart";
            this.btnAddToCart.Size = new System.Drawing.Size(200, 38);
            this.btnAddToCart.Text = "Добавить в заказ";
            this.btnAddToCart.UseVisualStyleBackColor = true;
            //
            // btnBack
            //
            this.btnBack.Location = new System.Drawing.Point(240, 480);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(120, 38);
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = true;
            //
            // ProductDetailForm
            //
            this.ClientSize = new System.Drawing.Size(780, 540);
            this.Controls.Add(this.picImage);
            this.Controls.Add(this.lblManufacturer);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblCompositionCaption);
            this.Controls.Add(this.lblComposition);
            this.Controls.Add(this.lblDescriptionCaption);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblSizeCaption);
            this.Controls.Add(this.cmbSize);
            this.Controls.Add(this.lblQuantityCaption);
            this.Controls.Add(this.numQuantity);
            this.Controls.Add(this.btnAddToCart);
            this.Controls.Add(this.btnBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
