using System.Configuration;
using System.Data;
using System.Data.SqlClient;

// Всё общение с базой данных — в этом классе.
public static class Db
{
    // Строку подключения создаёт мастер Visual Studio (раздел 6а) в App.config.
    static string cs = ConfigurationManager
        .ConnectionStrings["ChudoObuvOrders.Properties.Settings.ConnectionString"].ConnectionString;

    // Команда с параметрами: пары "имя", значение, "имя", значение...
    public static SqlCommand Cmd(SqlConnection c, string sql, object[] p, SqlTransaction t = null)
    {
        var m = new SqlCommand(sql, c, t);
        for (int i = 0; i < p.Length; i += 2)
            m.Parameters.AddWithValue((string)p[i], p[i + 1]);
        return m;
    }

    // SELECT: вернуть таблицу.
    public static DataTable Table(string sql, params object[] p)
    {
        using (var c = new SqlConnection(cs))
        {
            var t = new DataTable();
            new SqlDataAdapter(Cmd(c, sql, p)).Fill(t);
            return t;
        }
    }

    // INSERT / UPDATE / DELETE.
    public static void Run(string sql, params object[] p)
    {
        using (var c = new SqlConnection(cs))
        {
            c.Open();
            Cmd(c, sql, p).ExecuteNonQuery();
        }
    }

    // Открытое подключение — для транзакций.
    public static SqlConnection Open()
    {
        var c = new SqlConnection(cs);
        c.Open();
        return c;
    }
}
