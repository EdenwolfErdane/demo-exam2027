﻿partial class OrdersForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrdersForm));
        this.pnlHeader = new System.Windows.Forms.Panel();
        this.lblTitle = new System.Windows.Forms.Label();
        this.gridOrders = new System.Windows.Forms.DataGridView();
        this.btnDelete = new System.Windows.Forms.Button();
        this.btnAdd = new System.Windows.Forms.Button();
        this.dtp = new System.Windows.Forms.DateTimePicker();
        this.btnDate = new System.Windows.Forms.Button();
        this.gridItems = new System.Windows.Forms.DataGridView();
        this.lblTotal = new System.Windows.Forms.Label();
        this.btnDelItem = new System.Windows.Forms.Button();
        this.pnlHeader.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.gridItems)).BeginInit();
        this.SuspendLayout();
        //
        // pnlHeader
        //
        this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.pnlHeader.Controls.Add(this.lblTitle);
        this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
        this.pnlHeader.Location = new System.Drawing.Point(0, 0);
        this.pnlHeader.Name = "pnlHeader";
        this.pnlHeader.Size = new System.Drawing.Size(820, 56);
        //
        // lblTitle
        //
        this.lblTitle.AutoSize = true;
        this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
        this.lblTitle.ForeColor = System.Drawing.Color.White;
        this.lblTitle.Location = new System.Drawing.Point(20, 14);
        this.lblTitle.Name = "lblTitle";
        this.lblTitle.Size = new System.Drawing.Size(80, 23);
        this.lblTitle.Text = "Заказы";
        //
        // gridOrders — список заказов
        //
        this.gridOrders.AllowUserToAddRows = false;
        this.gridOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.gridOrders.BackgroundColor = System.Drawing.Color.White;
        this.gridOrders.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.gridOrders.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.gridOrders.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
        this.gridOrders.ColumnHeadersHeight = 32;
        this.gridOrders.EnableHeadersVisualStyles = false;
        this.gridOrders.Location = new System.Drawing.Point(20, 76);
        this.gridOrders.Name = "gridOrders";
        this.gridOrders.ReadOnly = true;
        this.gridOrders.RowHeadersVisible = false;
        this.gridOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.gridOrders.Size = new System.Drawing.Size(780, 170);
        this.gridOrders.SelectionChanged += new System.EventHandler(this.gridOrders_SelectionChanged);
        //
        // btnDelete — удалить заказ (с возвратом товара на склад)
        //
        this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
        this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDelete.FlatAppearance.BorderSize = 0;
        this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnDelete.ForeColor = System.Drawing.Color.White;
        this.btnDelete.Location = new System.Drawing.Point(20, 256);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(160, 32);
        this.btnDelete.Text = "Удалить заказ";
        this.btnDelete.UseVisualStyleBackColor = false;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        //
        // btnAdd — добавить заказ через каталог
        //
        this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnAdd.FlatAppearance.BorderSize = 0;
        this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnAdd.ForeColor = System.Drawing.Color.White;
        this.btnAdd.Location = new System.Drawing.Point(190, 256);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(140, 32);
        this.btnAdd.Text = "Добавить";
        this.btnAdd.UseVisualStyleBackColor = false;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        //
        // dtp — выбор даты (админ)
        //
        this.dtp.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.dtp.Location = new System.Drawing.Point(490, 258);
        this.dtp.Name = "dtp";
        this.dtp.Size = new System.Drawing.Size(160, 25);
        //
        // btnDate — сменить дату заказа (админ)
        //
        this.btnDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(87)))));
        this.btnDate.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDate.FlatAppearance.BorderSize = 0;
        this.btnDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnDate.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.btnDate.Location = new System.Drawing.Point(660, 256);
        this.btnDate.Name = "btnDate";
        this.btnDate.Size = new System.Drawing.Size(140, 32);
        this.btnDate.Text = "Сменить дату";
        this.btnDate.UseVisualStyleBackColor = false;
        this.btnDate.Click += new System.EventHandler(this.btnDate_Click);
        //
        // gridItems — состав выбранного заказа
        //
        this.gridItems.AllowUserToAddRows = false;
        this.gridItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.gridItems.BackgroundColor = System.Drawing.Color.White;
        this.gridItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.gridItems.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.gridItems.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
        this.gridItems.ColumnHeadersHeight = 30;
        this.gridItems.EnableHeadersVisualStyles = false;
        this.gridItems.Location = new System.Drawing.Point(20, 302);
        this.gridItems.Name = "gridItems";
        this.gridItems.ReadOnly = true;
        this.gridItems.RowHeadersVisible = false;
        this.gridItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.gridItems.Size = new System.Drawing.Size(780, 160);
        //
        // lblTotal — итог по составу
        //
        this.lblTotal.AutoSize = true;
        this.lblTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F);
        this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.lblTotal.Location = new System.Drawing.Point(20, 472);
        this.lblTotal.Name = "lblTotal";
        this.lblTotal.Size = new System.Drawing.Size(95, 21);
        this.lblTotal.Text = "Итого: 0 ₽";
        //
        // btnDelItem — удалить позицию заказа (админ)
        //
        this.btnDelItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
        this.btnDelItem.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDelItem.FlatAppearance.BorderSize = 0;
        this.btnDelItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnDelItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnDelItem.ForeColor = System.Drawing.Color.White;
        this.btnDelItem.Location = new System.Drawing.Point(640, 468);
        this.btnDelItem.Name = "btnDelItem";
        this.btnDelItem.Size = new System.Drawing.Size(160, 32);
        this.btnDelItem.Text = "Удалить позицию";
        this.btnDelItem.UseVisualStyleBackColor = false;
        this.btnDelItem.Click += new System.EventHandler(this.btnDelItem_Click);
        //
        // OrdersForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.ClientSize = new System.Drawing.Size(820, 510);
        this.Controls.Add(this.pnlHeader);
        this.Controls.Add(this.gridOrders);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.dtp);
        this.Controls.Add(this.btnDate);
        this.Controls.Add(this.gridItems);
        this.Controls.Add(this.lblTotal);
        this.Controls.Add(this.btnDelItem);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MaximizeBox = false;
        this.Name = "OrdersForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Чудо Обувь — Заказы";
        this.pnlHeader.ResumeLayout(false);
        this.pnlHeader.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.gridItems)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.Panel pnlHeader;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.DataGridView gridOrders;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.DateTimePicker dtp;
    private System.Windows.Forms.Button btnDate;
    private System.Windows.Forms.DataGridView gridItems;
    private System.Windows.Forms.Label lblTotal;
    private System.Windows.Forms.Button btnDelItem;
}
