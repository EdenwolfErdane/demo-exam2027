using System;
using System.Windows.Forms;
using ChudoObuvOrders.Forms;

namespace ChudoObuvOrders
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
