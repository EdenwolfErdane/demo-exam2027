@echo off
rem ============================================================
rem  Собрать.bat — сборка ChudoObuvOrders.exe без Visual Studio.
rem  Использует штатный компилятор csc.exe из .NET Framework,
rem  который есть в любой Windows 10/11, и ResGen.exe из Windows SDK.
rem  Запускать двойным щелчком. Результат: ChudoObuvOrders\Bin\ChudoObuvOrders.exe
rem ============================================================
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d "%~dp0ChudoObuvOrders"

echo [1/5] Ищу компилятор csc.exe...
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo [ОШИБКА] Не найден csc.exe. Установите .NET Framework 4.8 и повторите.
    pause
    exit /b 1
)
echo        Найден: %CSC%

echo [2/5] Ищу ResGen.exe (Windows SDK)...
set "RESGEN="
for %%P in (
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.8 Tools"
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.7.2 Tools"
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6.2 Tools"
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6.1 Tools"
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v8.1A\bin\NETFX 4.5.1 Tools"
    "%ProgramFiles(x86)%\Microsoft SDKs\Windows\v8.0A\bin\NETFX 4.0 Tools"
) do (
    if exist "%%~P\ResGen.exe" if not defined RESGEN set "RESGEN=%%~P\ResGen.exe"
)
if not defined RESGEN (
    echo [ОШИБКА] Не найден ResGen.exe из Windows SDK.
    echo Установите "Windows SDK" или соберите проект в Visual Studio ^(ChudoObuvOrders.sln^).
    pause
    exit /b 1
)
echo        Найден: %RESGEN%

echo [3/5] Готовлю папку Bin...
if exist Bin rmdir /s /q Bin
mkdir Bin || (echo [ОШИБКА] Не удалось создать Bin& pause& exit /b 1)

echo [4/5] Конвертирую формы (*.resx - *.resources)...
for %%R in (*.resx) do (
    "%RESGEN%" /compile "%%~fR,Bin\%%~nR.resources" >nul
    if errorlevel 1 (
        echo [ОШИБКА] ResGen не смог обработать %%R
        pause
        exit /b 1
    )
)

echo [5/5] Компилирую...
set "CS="
for %%F in (*.cs) do set "CS=!CS! "%%~fF""
set "RES="
for %%F in (Bin\*.resources) do set "RES=!RES! /resource:%%~fF,%%~nF.resources"
"%CSC%" -nologo -target:winexe -out:Bin\ChudoObuvOrders.exe -win32icon:Resources\chudo_obuv.ico !RES! !CS! -r:System.dll -r:System.Core.dll -r:System.Data.dll -r:System.Drawing.dll -r:System.Windows.Forms.dll -r:System.Configuration.dll -r:System.Xml.dll
if errorlevel 1 (
    echo [ОШИБКА] Компилятор сообщил об ошибках выше.
    pause
    exit /b 1
)
del /q Bin\*.resources >nul 2>&1

copy /y App.config Bin\ChudoObuvOrders.exe.config >nul
xcopy /e /i /y Resources Bin\Resources >nul

echo.
echo [ГОТОВО] Собрано: ChudoObuvOrders\Bin\ChudoObuvOrders.exe
echo Не забудьте: рядом с .exe должны лежать папка Resources и база
echo Чудо_Обувь.mdf (как её создать — см. README, раздел "Как запустить").
pause
