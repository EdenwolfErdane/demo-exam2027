﻿using System;
using System.Windows.Forms;
using System.Drawing;

static class Program
{
    [STAThread]
    static void Main()
    {

        Application.EnableVisualStyles();
        while (true)
        {
            // 1) окно входа; закрыли крестиком — выходим
            using (var login = new LoginForm())
                if (login.ShowDialog() != DialogResult.OK) break;
            // 2) главное окно; если нажали «Выйти» — снова вход
            Session.LoggedOut = false;
            using (var main = new MainForm())
                main.ShowDialog();
            if (!Session.LoggedOut) break;
        }
    }
}
