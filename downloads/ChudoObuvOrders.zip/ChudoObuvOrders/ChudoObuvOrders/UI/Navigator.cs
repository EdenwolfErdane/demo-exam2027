﻿using System.Windows.Forms;

namespace ChudoObuvOrders.UI
{
    // Помощник для открытия модальных форм.
    public static class Navigator
    {
        // Скрывает текущую форму, открывает новую модально, потом возвращает текущую.
        public static DialogResult OpenModal(Form current, Form next)
        {
            current.Hide();
            try
            {
                return next.ShowDialog();
            }
            finally
            {
                current.Show();
            }
        }
    }
}