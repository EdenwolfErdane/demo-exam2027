namespace ChudoObuvOrders.Models
{
    // Роль пользователя.
    public enum UserRole
    {
        AuthorizedUser, // обычный авторизованный
        Manager,        // менеджер
        Administrator   // администратор
    }

    // Пользователь системы (авторизация только по логину).
    public class User
    {
        public int UserId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Login { get; set; }
        public UserRole Role { get; set; }

        // ФИО одной строкой, лишние пробелы обрезаем через Trim.
        public string FullName => $"{LastName} {FirstName} {MiddleName}".Trim();

        // Название роли из базы -> enum. Неизвестное — считаем обычным пользователем.
        public static UserRole ParseRole(string roleName)
        {
            switch (roleName)
            {
                case "Администратор": return UserRole.Administrator;
                case "Менеджер": return UserRole.Manager;
                default: return UserRole.AuthorizedUser;
            }
        }
    }
}