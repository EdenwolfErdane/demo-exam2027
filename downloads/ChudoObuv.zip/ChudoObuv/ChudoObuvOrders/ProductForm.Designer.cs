partial class ProductForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductForm));
            this.picImage = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblManufacturer = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblComposition = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblRange = new System.Windows.Forms.Label();
            this.lblSizeCaption = new System.Windows.Forms.Label();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.lblQtyCaption = new System.Windows.Forms.Label();
            this.nudQty = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).BeginInit();
            this.SuspendLayout();
            // 
            // picImage
            // 
            this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picImage.Location = new System.Drawing.Point(15, 15);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(200, 200);
            this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picImage.TabIndex = 0;
            this.picImage.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(230, 15);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(315, 40);
            this.lblName.TabIndex = 1;
            // 
            // lblManufacturer
            // 
            this.lblManufacturer.Location = new System.Drawing.Point(230, 60);
            this.lblManufacturer.Name = "lblManufacturer";
            this.lblManufacturer.Size = new System.Drawing.Size(315, 20);
            this.lblManufacturer.TabIndex = 2;
            // 
            // lblCategory
            // 
            this.lblCategory.Location = new System.Drawing.Point(230, 85);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(315, 20);
            this.lblCategory.TabIndex = 3;
            // 
            // lblPrice
            // 
            this.lblPrice.Location = new System.Drawing.Point(230, 110);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(315, 20);
            this.lblPrice.TabIndex = 4;
            // 
            // lblComposition
            // 
            this.lblComposition.Location = new System.Drawing.Point(230, 135);
            this.lblComposition.Name = "lblComposition";
            this.lblComposition.Size = new System.Drawing.Size(315, 60);
            this.lblComposition.TabIndex = 5;
            // 
            // lblDescription
            // 
            this.lblDescription.Location = new System.Drawing.Point(15, 225);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(530, 55);
            this.lblDescription.TabIndex = 6;
            // 
            // lblRange
            // 
            this.lblRange.Location = new System.Drawing.Point(15, 290);
            this.lblRange.Name = "lblRange";
            this.lblRange.Size = new System.Drawing.Size(530, 20);
            this.lblRange.TabIndex = 7;
            // 
            // lblSizeCaption
            // 
            this.lblSizeCaption.AutoSize = true;
            this.lblSizeCaption.Location = new System.Drawing.Point(15, 325);
            this.lblSizeCaption.Name = "lblSizeCaption";
            this.lblSizeCaption.Size = new System.Drawing.Size(162, 21);
            this.lblSizeCaption.TabIndex = 8;
            this.lblSizeCaption.Text = "Доступные размеры:";
            // 
            // cmbSize
            // 
            this.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSize.Location = new System.Drawing.Point(150, 322);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(90, 29);
            this.cmbSize.TabIndex = 9;
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
            // 
            // lblQtyCaption
            // 
            this.lblQtyCaption.AutoSize = true;
            this.lblQtyCaption.Location = new System.Drawing.Point(265, 325);
            this.lblQtyCaption.Name = "lblQtyCaption";
            this.lblQtyCaption.Size = new System.Drawing.Size(64, 21);
            this.lblQtyCaption.TabIndex = 10;
            this.lblQtyCaption.Text = "Кол-во:";
            // 
            // nudQty
            // 
            this.nudQty.Location = new System.Drawing.Point(325, 322);
            this.nudQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudQty.Name = "nudQty";
            this.nudQty.Size = new System.Drawing.Size(80, 28);
            this.nudQty.TabIndex = 11;
            this.nudQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(15, 365);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(130, 30);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "В заказ";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(160, 365);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(130, 30);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Назад";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // ProductForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(560, 410);
            this.Controls.Add(this.picImage);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblManufacturer);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblComposition);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblRange);
            this.Controls.Add(this.lblSizeCaption);
            this.Controls.Add(this.cmbSize);
            this.Controls.Add(this.lblQtyCaption);
            this.Controls.Add(this.nudQty);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnBack);
            this.Font = new System.Drawing.Font("Calibri", 10F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProductForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Чудо Обувь — Товар";
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblManufacturer;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblComposition;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblRange;
        private System.Windows.Forms.Label lblSizeCaption;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.Label lblQtyCaption;
        private System.Windows.Forms.NumericUpDown nudQty;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBack;
}
