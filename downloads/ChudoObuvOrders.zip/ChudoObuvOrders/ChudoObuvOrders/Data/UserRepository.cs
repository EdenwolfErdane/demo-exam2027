// Dictionary.
using System.Collections.Generic;
// SqlCommand, SqlDataReader.
using System.Data.SqlClient;
// OrderBy, ThenBy, ToDictionary.
using System.Linq;
// Модель User.
using ChudoObuvOrders.Models;

namespace ChudoObuvOrders.Data
{
    // Всё, что связано с пользователями.
    public class UserRepository
    {
        // Читаем роли из таблицы Roles в словарь "RoleId -> RoleName".
        // Нужен, чтобы потом превратить RoleId пользователя в название роли.
        private static Dictionary<int, string> LoadRoles()
        {
            // Пустой словарь.
            var roles = new Dictionary<int, string>();

            // Открываем подключение — оно закроется автоматически в конце блока.
            using (var conn = DbHelper.GetConnection())
            // Запрос: все роли.
            using (var cmd = new SqlCommand("SELECT RoleId, RoleName FROM Roles", conn))
            // Читатель строк.
            using (var reader = cmd.ExecuteReader())
            {
                // Идём по строкам, пока они есть.
                while (reader.Read())
                {
                    // Ключ — RoleId, значение — RoleName.
                    roles[(int)reader["RoleId"]] = (string)reader["RoleName"];
                }
            }

            // Возвращаем словарь.
            return roles;
        }

        // Ищем пользователя по логину. Если нет — вернём null.
        public User FindByLogin(string login)
        {
            // Сначала роли — они пригодятся в Map.
            var roles = LoadRoles();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Параметр @Login, а не склейка строк — так безопаснее.
            using (var cmd = new SqlCommand("SELECT * FROM Users WHERE Login = @Login", conn))
            {
                // Подставляем логин.
                cmd.Parameters.AddWithValue("@Login", login);

                // Выполняем запрос.
                using (var reader = cmd.ExecuteReader())
                {
                    // Строк нет — пользователя с таким логином не существует.
                    if (!reader.Read())
                        return null;

                    // Есть — превращаем строку в объект User.
                    return Map(reader, roles);
                }
            }
        }

        // Возвращаем всех пользователей, отсортированных по фамилии, потом по имени.
        public List<User> GetAll()
        {
            // Роли — для Map.
            var roles = LoadRoles();
            // Сюда будем накапливать результат.
            var result = new List<User>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Читаем всю таблицу Users.
            using (var cmd = new SqlCommand("SELECT * FROM Users", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                // Пока есть строки — превращаем в User и добавляем.
                while (reader.Read())
                    result.Add(Map(reader, roles));
            }

            // Сортировка: сначала по фамилии, при равенстве — по имени.
            return result.OrderBy(u => u.LastName).ThenBy(u => u.FirstName).ToList();
        }

        // Превращает одну строку результата в объект User.
        private static User Map(SqlDataReader reader, Dictionary<int, string> roles)
        {
            return new User
            {
                UserId = (int)reader["UserId"],
                LastName = (string)reader["LastName"],
                FirstName = (string)reader["FirstName"],
                // MiddleName может быть NULL — тогда подставим пустую строку.
                MiddleName = reader["MiddleName"] as string ?? "",
                Login = (string)reader["Login"],
                // RoleId -> название роли -> enum.
                Role = User.ParseRole(roles[(int)reader["RoleId"]])
            };
        }
    }
}