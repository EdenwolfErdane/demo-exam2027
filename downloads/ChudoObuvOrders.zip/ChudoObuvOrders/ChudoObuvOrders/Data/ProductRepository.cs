// Math.Round, DateTime.
using System;
// List, Dictionary, IEnumerable.
using System.Collections.Generic;
// SqlCommand, SqlDataReader.
using System.Data.SqlClient;
// Where, OrderBy, ToDictionary и прочий LINQ.
using System.Linq;
// Модели Product, StockItem.
using ChudoObuvOrders.Models;

namespace ChudoObuvOrders.Data
{
    // Как сортировать по цене.
    public enum PriceSortOrder
    {
        None,        // без сортировки по цене (по имени)
        Ascending,   // сначала дешёвые
        Descending   // сначала дорогие
    }

    // Всё про товары, категории и склад.
    public class ProductRepository
    {
        // Список категорий, отсортированных по имени.
        public List<Category> GetCategories()
        {
            // Сюда собираем результат.
            var result = new List<Category>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Читаем категории.
            using (var cmd = new SqlCommand("SELECT CategoryId, CategoryName FROM Categories", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                // Идём по строкам.
                while (reader.Read())
                {
                    result.Add(new Category
                    {
                        CategoryId = (int)reader["CategoryId"],
                        CategoryName = (string)reader["CategoryName"]
                    });
                }
            }

            // Сортируем по имени и отдаём.
            return result.OrderBy(c => c.CategoryName).ToList();
        }

        // Собираем полный каталог: товары + остатки + скидки.
        private List<Product> LoadCatalog()
        {
            // Справочник категорий "id -> название".
            var categories = GetCategories().ToDictionary(c => c.CategoryId, c => c.CategoryName);

            // Товары (сразу с названием категории).
            var products = ReadProducts(categories);
            // Суммарный остаток по каждому товару.
            var totalByProduct = ReadTotalByProduct();
            // Множество товаров, заказанных в прошлом месяце.
            var orderedLastMonth = ReadProductsOrderedLastMonth();

            // Пробегаем по всем товарам и досчитываем остаток и цену.
            foreach (var p in products)
            {
                // Если товара нет в словаре — остаток 0.
                p.TotalQuantity = totalByProduct.ContainsKey(p.ProductId) ? totalByProduct[p.ProductId] : 0;
                // Был заказ в прошлом месяце — скидки нет. Иначе — минус 25%.
                p.DiscountPrice = orderedLastMonth.Contains(p.ProductId)
                    ? p.BasePrice
                    : Math.Round(p.BasePrice * 0.75m, 2);
            }

            return products;
        }

        // Читаем таблицу Products. Название категории проставляем сразу из словаря.
        private List<Product> ReadProducts(Dictionary<int, string> categories)
        {
            var products = new List<Product>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Все товары.
            using (var cmd = new SqlCommand("SELECT * FROM Products", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        ProductId = (int)reader["ProductId"],
                        ProductName = (string)reader["ProductName"],
                        Manufacturer = (string)reader["Manufacturer"],
                        // Может быть NULL.
                        Description = reader["Description"] as string ?? "",
                        // Может быть NULL.
                        Composition = reader["Composition"] as string ?? "",
                        // Может быть NULL — оставляем как есть.
                        ImageFileName = reader["ImageFileName"] as string,
                        CategoryId = (int)reader["CategoryId"],
                        BasePrice = (decimal)reader["BasePrice"],
                        // Название категории достаём из словаря.
                        CategoryName = categories[(int)reader["CategoryId"]]
                    });
                }
            }

            return products;
        }

        // Суммарный остаток по каждому товару — складываем Quantity по всем размерам.
        private Dictionary<int, int> ReadTotalByProduct()
        {
            var totalByProduct = new Dictionary<int, int>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Все складские позиции.
            using (var cmd = new SqlCommand("SELECT ProductId, Quantity FROM StockItems", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int productId = (int)reader["ProductId"];
                    int qty = (int)reader["Quantity"];

                    // Если товар уже встречался — прибавляем, иначе кладём первое значение.
                    if (totalByProduct.ContainsKey(productId))
                        totalByProduct[productId] += qty;
                    else
                        totalByProduct[productId] = qty;
                }
            }

            return totalByProduct;
        }

        // Возвращает id товаров, которые заказывали в прошлом календарном месяце.
        // Связи между таблицами строим в C#, без JOIN.
        private HashSet<int> ReadProductsOrderedLastMonth()
        {
            // Сегодня.
            var today = DateTime.Today;
            // Первое число текущего месяца.
            var startOfThisMonth = new DateTime(today.Year, today.Month, 1);
            // Первое число прошлого месяца.
            var startOfPrevMonth = startOfThisMonth.AddMonths(-1);

            // OrderId -> дата заказа.
            var orderDates = ReadOrderDates();
            // StockItemId -> ProductId.
            var productByStockItem = ReadProductByStockItem();

            // Здесь соберём id товаров.
            var orderedLastMonth = new HashSet<int>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Все позиции всех заказов.
            using (var cmd = new SqlCommand("SELECT OrderId, StockItemId FROM OrderItems", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int orderId = (int)reader["OrderId"];
                    int stockItemId = (int)reader["StockItemId"];

                    // Дата заказа, к которому относится позиция.
                    var date = orderDates[orderId];

                    // Попадает ли дата в прошлый месяц?
                    if (date >= startOfPrevMonth && date < startOfThisMonth)
                        // Если да — добавляем товар в множество.
                        orderedLastMonth.Add(productByStockItem[stockItemId]);
                }
            }

            return orderedLastMonth;
        }

        // Читаем пары "OrderId -> OrderDate".
        private Dictionary<int, DateTime> ReadOrderDates()
        {
            var orderDates = new Dictionary<int, DateTime>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Заказы.
            using (var cmd = new SqlCommand("SELECT OrderId, OrderDate FROM Orders", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                    orderDates[(int)reader["OrderId"]] = (DateTime)reader["OrderDate"];
            }

            return orderDates;
        }

        // Читаем пары "StockItemId -> ProductId".
        private Dictionary<int, int> ReadProductByStockItem()
        {
            var productByStockItem = new Dictionary<int, int>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Складские позиции.
            using (var cmd = new SqlCommand("SELECT StockItemId, ProductId FROM StockItems", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                    productByStockItem[(int)reader["StockItemId"]] = (int)reader["ProductId"];
            }

            return productByStockItem;
        }

        // Каталог с учётом поиска, фильтра по категории и сортировки.
        public List<Product> GetCatalog(string searchText, int? categoryId, PriceSortOrder sortOrder)
        {
            // Начинаем с полного каталога.
            IEnumerable<Product> query = LoadCatalog();

            // Если в поиске что-то написано — фильтруем по имени и описанию без учёта регистра.
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                query = query.Where(p =>
                    p.ProductName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    p.Description.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            // Если категория выбрана (не null) — оставляем только её товары.
            if (categoryId.HasValue)
                query = query.Where(p => p.CategoryId == categoryId.Value);

            // Сортировка.
            if (sortOrder == PriceSortOrder.Ascending)
                query = query.OrderBy(p => p.DiscountPrice);           // дешёвые сверху
            else if (sortOrder == PriceSortOrder.Descending)
                query = query.OrderByDescending(p => p.DiscountPrice); // дорогие сверху
            else
                query = query.OrderBy(p => p.ProductName);             // по имени

            // Материализуем и отдаём список.
            return query.ToList();
        }

        // Один товар по id — или null, если такого нет.
        public Product GetById(int productId)
        {
            return LoadCatalog().FirstOrDefault(p => p.ProductId == productId);
        }

        // Складские позиции одного товара: размер + количество.
        public List<StockItem> GetStockItems(int productId)
        {
            // Сначала справочник размеров.
            var sizes = ReadSizes();

            // Сюда собираем результат.
            var result = new List<StockItem>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Только позиции нужного товара.
            using (var cmd = new SqlCommand("SELECT * FROM StockItems WHERE ProductId = @ProductId", conn))
            {
                // Подставляем id товара.
                cmd.Parameters.AddWithValue("@ProductId", productId);

                // Читатель.
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new StockItem
                        {
                            StockItemId = (int)reader["StockItemId"],
                            ProductId = (int)reader["ProductId"],
                            // Числовое значение размера берём из справочника.
                            SizeValue = sizes[(int)reader["SizeId"]],
                            Quantity = (int)reader["Quantity"]
                        });
                    }
                }
            }

            // Сортируем по размеру и отдаём.
            return result.OrderBy(s => s.SizeValue).ToList();
        }

        // Справочник размеров "SizeId -> SizeValue".
        private Dictionary<int, decimal> ReadSizes()
        {
            var sizes = new Dictionary<int, decimal>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Все размеры.
            using (var cmd = new SqlCommand("SELECT SizeId, SizeValue FROM Sizes", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                    sizes[(int)reader["SizeId"]] = (decimal)reader["SizeValue"];
            }

            return sizes;
        }
    }

    // Категория товара.
    public class Category
    {
        // id категории.
        public int CategoryId { get; set; }
        // Название.
        public string CategoryName { get; set; }
    }
}