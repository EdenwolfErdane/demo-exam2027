using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма выбора клиента.
    //
    // Компоненты (в дизайнере):
    //   lblCaption    — подпись "Выберите клиента"
    //   cmbUsers      — список пользователей
    //   errorProvider — показ ошибок
    //   btnOk         — "Далее"
    //   btnCancel     — "Отмена"
    public partial class UserPickForm : Form
    {
        // Все пользователи.
        private System.Collections.Generic.List<User> _users;
        // Кого выбрали.
        public User SelectedUser { get; private set; }

        public UserPickForm()
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Выбор клиента";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            Font = AppStyle.DefaultFont;

            // Кнопки.
            btnOk.Click += (s, e) => Accept();
            btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            // При загрузке — заполняем список.
            Load += (s, e) => LoadUsers();
        }

        // Загружает список пользователей в ComboBox.
        private void LoadUsers()
        {
            _users = new UserRepository().GetAll();
            cmbUsers.DisplayMember = "FullName";
            cmbUsers.DataSource = _users;
        }

        // Кнопка "Далее".
        private void Accept()
        {
            errorProvider.Clear();

            // Ничего не выбрано — ошибка.
            if (cmbUsers.SelectedItem == null)
            {
                errorProvider.SetError(cmbUsers, "Выберите клиента из списка.");
                return;
            }

            // Запоминаем выбор и закрываем форму с результатом OK.
            SelectedUser = (User)cmbUsers.SelectedItem;
            DialogResult = DialogResult.OK;
        }
    }
}