using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Session;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма списка заказов.
    //
    // Компоненты (в дизайнере):
    //   gridOrders     — таблица заказов
    //   btnAdd         — добавить заказ
    //   btnDelete      — удалить заказ
    //   btnComposition — состав заказа
    //   btnClose       — закрыть
    public partial class OrdersForm : Form
    {
        // Репозиторий заказов.
        private readonly OrderRepository _orderRepository = new OrderRepository();
        // Список заказов.
        private System.Collections.Generic.List<Models.Order> _orders;

        public OrdersForm()
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Заказы";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlBottom.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;

            // Обработчики кнопок.
            btnAdd.Click += (s, e) => AddOrder();
            btnDelete.Click += (s, e) => DeleteOrder();
            btnComposition.Click += (s, e) => ShowComposition();
            btnClose.Click += (s, e) => Close();

            // При загрузке — строим таблицу.
            Load += (s, e) => RefreshGrid();
        }

        // Перечитывает заказы и обновляет таблицу.
        private void RefreshGrid()
        {
            _orders = _orderRepository.GetOrders();
            gridOrders.DataSource = null;
            gridOrders.DataSource = _orders
                .Select(o => new { Дата = o.OrderDate, Клиент = o.UserFullName })
                .ToList();
        }

        // Выбранный в таблице заказ.
        private Models.Order SelectedOrder =>
            gridOrders.CurrentRow != null && gridOrders.CurrentRow.Index < _orders.Count
                ? _orders[gridOrders.CurrentRow.Index]
                : null;

        // Добавить заказ: сначала выбираем клиента, потом товары.
        private void AddOrder()
        {
            using (var userPick = new UserPickForm())
            {
                if (Navigator.OpenModal(this, userPick) != DialogResult.OK) return;

                using (var picker = new ProductPickerForm(userPick.SelectedUser))
                {
                    Navigator.OpenModal(this, picker);
                }
            }
            RefreshGrid();
        }

        // Удалить заказ целиком.
        private void DeleteOrder()
        {
            var order = SelectedOrder;
            if (order == null) return;

            var confirm = MessageBox.Show(this,
                $"Удалить заказ от {order.OrderDate:dd.MM.yyyy} (клиент: {order.UserFullName})? " +
                "Товар будет возвращён на склад. Действие необратимо.",
                "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            try
            {
                _orderRepository.DeleteOrder(order.OrderId);
                RefreshGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось удалить заказ: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Открыть состав выбранного заказа.
        private void ShowComposition()
        {
            var order = SelectedOrder;
            if (order == null)
            {
                MessageBox.Show(this, "Выберите заказ в списке.", "Заказ не выбран",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var form = new OrderCompositionForm(order))
                Navigator.OpenModal(this, form);

            RefreshGrid();
        }
    }
}