﻿using System.ComponentModel;
using ChudoObuvOrders;

// Одна строка корзины.
public class CartLine
{
    public int StockItemId { get; set; }
    public string Name { get; set; }
    public decimal Size { get; set; }
    public int Qty { get; set; }
    public decimal Price { get; set; }
}

// Кто вошёл, корзина и одна общая копия данных программы.
// Данные в неё кладут адаптеры из мастера (Чудо_ОбувьDataSet.xsd) — Fill, без SQL-команд.
public static class Session
{
    public static readonly Чудо_ОбувьDataSet Data = new Чудо_ОбувьDataSet();

    public static int UserId;
    public static string FullName = "";
    public static string Role = "";
    public static bool LoggedOut;
    public static BindingList<CartLine> Cart = new BindingList<CartLine>();

    public static bool IsAuth { get { return UserId > 0; } }
    public static bool IsAdmin { get { return Role.StartsWith("Админ"); } }
    public static bool IsStaff { get { return IsAdmin || Role.StartsWith("Менед"); } }

    public static void Clear()
    {
        UserId = 0; FullName = ""; Role = "";
        Cart.Clear();
    }
}
