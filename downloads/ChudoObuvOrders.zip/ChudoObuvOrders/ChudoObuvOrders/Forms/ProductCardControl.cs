using System;
using System.IO;
using System.Windows.Forms;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Карточка товара (UserControl).
    //
    // Компоненты (в дизайнере):
    //   picImage            — картинка товара или заглушка
    //   lblManufacturerName — "Производство | Наименование"
    //   lblCategory         — категория
    //   lblQuantity         — "много" / "мало"
    //   lblComposition      — состав
    //   lblPrice            — цена со скидкой
    //   pnlRoot             — корневая панель, на неё ловим клик
    public partial class ProductCardControl : UserControl
    {
        // Событие: пользователь кликнул по карточке, передаём id товара.
        public event EventHandler<int> ProductClicked;

        // Данные товара, чтобы обрабатывать клик.
        private Product _product;

        public ProductCardControl()
        {
            InitializeComponent();
            Font = AppStyle.DefaultFont;

            // Клик по панели и всем вложенным элементам открывает товар.
            pnlRoot.Click += (s, e) => ProductClicked?.Invoke(this, _product.ProductId);
            foreach (Control c in pnlRoot.Controls)
                c.Click += (s, e) => ProductClicked?.Invoke(this, _product.ProductId);
        }

        // Заполняет карточку данными товара.
        public void Bind(Product product)
        {
            _product = product;

            lblManufacturerName.Text = $"{product.Manufacturer} | {product.ProductName}";
            lblCategory.Text = product.CategoryName;
            lblQuantity.Text = product.QuantityLabel;
            lblComposition.Text = product.Composition;
            lblPrice.Text = $"{product.DiscountPrice:N0} ₽" +
                (product.HasDiscount ? $"  (было {product.BasePrice:N0} ₽)" : "");

            // Подсветка, если на складе мало.
            pnlRoot.BackColor = product.IsLowStock ? AppStyle.LowStockColor : AppStyle.BackgroundColor;

            // Картинка или заглушка.
            string imagePath = Path.Combine(AppStyle.ImagesFolder, product.ImageFileName ?? "");
            picImage.Image = File.Exists(imagePath)
                ? System.Drawing.Image.FromFile(imagePath)
                : System.Drawing.Image.FromFile(AppStyle.PlaceholderImagePath);
        }
    }
}