﻿using System;
using System.Data;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Заказы (менеджер/админ). Вид — в OrdersForm.Designer.cs.
public partial class OrdersForm : Form
{
    Чудо_ОбувьDataSet ds = Session.Data;

    public OrdersForm()
    {
        InitializeComponent();
        // Дата и удаление позиции — только администратору.
        dtp.Visible = btnDate.Visible = btnDelItem.Visible = Session.IsAdmin;
        LoadOrders();
    }

    int OrderId() { return gridOrders.CurrentRow == null ? 0 : (int)gridOrders.CurrentRow.Cells["Номер"].Value; }

    void LoadOrders()
    {
        // Заказы и пользователи загружают адаптеры из мастера.
        new ЗаказыTableAdapter().Fill(ds.Заказы);
        new ПользователиTableAdapter().Fill(ds.Пользователи);

        // Таблица для списка: ФИО берём из связанной строки пользователя.
        var t = new DataTable("Заказы");
        t.Columns.Add("Номер", typeof(int));
        t.Columns.Add("Дата", typeof(DateTime));
        t.Columns.Add("Клиент", typeof(string));
        foreach (var o in ds.Заказы)
        {
            var u = o.ПользователиRow;
            t.Rows.Add(o.Код_заказа, o.Дата_заказа, u == null ? "" : u.Фамилия + " " + u.Имя);
        }
        t.DefaultView.Sort = "Дата DESC";   // свежие заказы сверху
        gridOrders.DataSource = t;
        LoadItems();
    }

    void LoadItems()
    {
        // Состав выбранного заказа: строки, товары и размеры из набора.
        new Строки_заказовTableAdapter().Fill(ds.Строки_заказов);
        new Товарные_позицииTableAdapter().Fill(ds.Товарные_позиции);
        new ТоварыTableAdapter().Fill(ds.Товары);
        new РазмерыTableAdapter().Fill(ds.Размеры);

        var t = new DataTable("Состав");
        t.Columns.Add("Код", typeof(int));
        t.Columns.Add("Модель", typeof(string));
        t.Columns.Add("Размер", typeof(decimal));
        t.Columns.Add("Количество", typeof(int));
        t.Columns.Add("Цена", typeof(decimal));
        decimal sum = 0;
        var order = ds.Заказы.FindByКод_заказа(OrderId());
        if (order != null)
            foreach (var oi in order.GetСтроки_заказовRows())
            {
                var s = oi.Товарные_позицииRow;
                var p = s == null ? null : s.ТоварыRow;
                var z = s == null ? null : s.РазмерыRow;
                t.Rows.Add(oi.Код_строки,
                    p == null ? "?" : p.Производство + " | " + p.Наименование,
                    z == null ? 0m : z.Размер, oi.Количество, oi.Цена_за_единицу);
                sum += oi.Количество * oi.Цена_за_единицу;
            }
        gridItems.DataSource = t;
        lblTotal.Text = "Итого: " + sum.ToString("N2") + " ₽";
    }

    // Выбрали заказ — показываем его состав.
    private void gridOrders_SelectionChanged(object sender, EventArgs e) { LoadItems(); }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        // Каталог с поиском → карточка → корзина → выбор клиента → подтверждение.
        new MainForm(true).ShowDialog();
        LoadOrders();
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (OrderId() == 0) return;
        if (MessageBox.Show("Удалить заказ и вернуть товар на склад?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        var order = ds.Заказы.FindByКод_заказа(OrderId());
        if (order == null) return;
        new Товарные_позицииTableAdapter().Fill(ds.Товарные_позиции);
        // Сначала вернуть остатки и удалить строки, потом сам заказ.
        foreach (var oi in order.GetСтроки_заказовRows())
        {
            var s = oi.Товарные_позицииRow;
            if (s != null) s.Количество += oi.Количество;
            oi.Delete();
        }
        new Строки_заказовTableAdapter().Update(ds.Строки_заказов);
        new Товарные_позицииTableAdapter().Update(ds.Товарные_позиции);
        order.Delete();
        new ЗаказыTableAdapter().Update(ds.Заказы);
        LoadOrders();
    }

    private void btnDate_Click(object sender, EventArgs e)
    {
        if (OrderId() == 0) return;
        var order = ds.Заказы.FindByКод_заказа(OrderId());
        if (order == null) return;
        order.Дата_заказа = dtp.Value;
        new ЗаказыTableAdapter().Update(ds.Заказы);
        LoadOrders();
    }

    private void btnDelItem_Click(object sender, EventArgs e)
    {
        if (gridItems.CurrentRow == null) return;
        int id = (int)gridItems.CurrentRow.Cells["Код"].Value;
        var oi = ds.Строки_заказов.FindByКод_строки(id);
        if (oi == null) return;
        var s = oi.Товарные_позицииRow;
        if (s != null)
        {
            s.Количество += oi.Количество;
            new Товарные_позицииTableAdapter().Update(ds.Товарные_позиции);
        }
        oi.Delete();
        new Строки_заказовTableAdapter().Update(ds.Строки_заказов);
        LoadItems();
    }
}
