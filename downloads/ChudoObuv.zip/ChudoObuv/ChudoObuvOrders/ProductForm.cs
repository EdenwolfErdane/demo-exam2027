using System;
using System.Data;
using System.Windows.Forms;

// Форма просмотра товара. Вид — в ProductForm.Designer.cs.
public partial class ProductForm : Form
{
    string name; decimal price;

    public ProductForm(DataRow r)
    {
        InitializeComponent();
        name = (string)r["ProductName"];
        price = (decimal)r["Price"];
        int productId = (int)r["ProductId"];
        // Все поля заполняются данными выбранного товара.
        Text = "Чудо Обувь — " + name;
        lblName.Text = name;
        lblManufacturer.Text = "Производство: " + r["Manufacturer"];
        lblCategory.Text = "Категория: " + r["CategoryName"];
        lblPrice.Text = "Цена со скидкой: " + price.ToString("N0") + " ₽";
        lblComposition.Text = "Состав: " + r["Composition"];
        lblDescription.Text = "Описание: " + r["Description"];
        picImage.Image = ProductCard.LoadImage(r["ImageFileName"] as string);

        // Размерный ряд — все размеры модели, от наименьшего до наибольшего.
        var range = Db.Table(@"SELECT MIN(z.Размер) AS MinSize, MAX(z.Размер) AS MaxSize FROM Товарные_позиции s
                               JOIN Размеры z ON z.Код_размера = s.Код_размера WHERE s.Код_товара = @p", "@p", productId);
        lblRange.Text = range.Rows[0]["MinSize"] is DBNull ? "Размерный ряд: нет данных"
            : "Размерный ряд: " + ((decimal)range.Rows[0]["MinSize"]).ToString("0.#") + " – " + ((decimal)range.Rows[0]["MaxSize"]).ToString("0.#");

        // Доступные для заказа размеры — только те, что есть на складе.
        var sizes = Db.Table(@"SELECT s.Код_позиции AS StockItemId, z.Размер AS SizeValue, s.Количество AS Quantity FROM Товарные_позиции s
                               JOIN Размеры z ON z.Код_размера = s.Код_размера
                               WHERE s.Код_товара = @p AND s.Количество > 0 ORDER BY z.Размер", "@p", productId);
        cmbSize.DisplayMember = "SizeValue";
        cmbSize.ValueMember = "StockItemId";
        cmbSize.DataSource = sizes;
        btnAdd.Visible = Session.IsAuth && sizes.Rows.Count > 0;
    }

    // Выбрали размер — больше остатка этого размера заказать нельзя.
    private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        var row = cmbSize.SelectedItem as DataRowView;
        if (row != null) nudQty.Maximum = (int)row["Quantity"];
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        var row = (DataRowView)cmbSize.SelectedItem;
        Session.Cart.Add(new CartLine { StockItemId = (int)row["StockItemId"], Name = name,
            Size = (decimal)row["SizeValue"], Qty = (int)nudQty.Value, Price = price });
        MessageBox.Show("Добавлено в заказ. Можно выбрать ещё товары или открыть корзину.", "Готово",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        Close();
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }
}
