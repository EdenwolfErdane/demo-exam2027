using System;
using System.Windows.Forms;

// Внешний вид окна настраивается мышкой (LoginForm.Designer.cs). Здесь — только логика.
public partial class LoginForm : Form
{
    public LoginForm() { InitializeComponent(); }

    // Кнопка «Войти»
    private void btnOk_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtLogin.Text))
        {
            MessageBox.Show("Введите логин из списка пользователей и нажмите «Войти».", "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        var t = Db.Table(@"SELECT u.Код_пользователя AS UserId, u.Фамилия + ' ' + u.Имя + ' ' + ISNULL(u.Отчество,'') AS Fio, r.Название_роли AS RoleName
                           FROM Пользователи u JOIN Роли r ON r.Код_роли = u.Код_роли WHERE u.Логин = @l",
                         "@l", txtLogin.Text.Trim());
        if (t.Rows.Count == 0)
        {
            MessageBox.Show("Пользователь не найден. Проверьте логин.", "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        Session.UserId = (int)t.Rows[0]["UserId"];
        Session.FullName = (string)t.Rows[0]["Fio"];
        Session.Role = (string)t.Rows[0]["RoleName"];
        DialogResult = DialogResult.OK;
    }

    // Кнопка «Без входа»
    private void btnGuest_Click(object sender, EventArgs e)
    {
        DialogResult = DialogResult.OK;
    }
}
