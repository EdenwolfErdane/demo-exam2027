﻿-- Проверка базы «Чудо_Обувь». Выполните целиком в окне запроса базы
-- (Visual Studio: Серверный обозреватель → правый клик по подключению → Создать запрос).
USE Чудо_Обувь;
GO

-- 1. Сколько строк в таблицах (должно совпасть с колонкой «Ожидалось»)
SELECT 'Роли' AS Таблица, COUNT(*) AS Строк, 3 AS Ожидалось FROM Роли
UNION ALL SELECT 'Категории', COUNT(*), 3 FROM Категории
UNION ALL SELECT 'Размеры', COUNT(*), 35 FROM Размеры
UNION ALL SELECT 'Товары', COUNT(*), 31 FROM Товары
UNION ALL SELECT 'Товарные_позиции', COUNT(*), 92 FROM Товарные_позиции
UNION ALL SELECT 'Пользователи', COUNT(*), 20 FROM Пользователи
UNION ALL SELECT 'Заказы', COUNT(*), 10 FROM Заказы
UNION ALL SELECT 'Строки_заказов', COUNT(*), 30 FROM Строки_заказов;

-- 2. Товары без остатков и позиции без товара (оба результата должны быть пустыми после чистки Excel)
SELECT Наименование, Производство FROM Товары t
WHERE NOT EXISTS (SELECT 1 FROM Товарные_позиции p WHERE p.Код_товара = t.Код_товара);

-- 3. Остались ли временные таблицы импорта (должно быть пусто)
SELECT name FROM sys.tables WHERE name LIKE N'Импорт[_]%';

-- 4. Каталог так, как его строит программа (тот же запрос, что в MainForm.cs)
DECLARE @b DATETIME2 = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
DECLARE @a DATETIME2 = DATEADD(MONTH, -1, @b);
DECLARE @s NVARCHAR(100) = N'%%';
DECLARE @cat INT = 0;
SELECT p.Код_товара AS ProductId, p.Наименование AS ProductName, p.Производство AS Manufacturer, p.Состав AS Composition,
              p.Описание AS Description, p.Изображение AS ImageFileName, c.Название_категории AS CategoryName,
              ISNULL((SELECT SUM(Количество) FROM Товарные_позиции WHERE Код_товара = p.Код_товара), 0) AS Qty,
              CASE WHEN EXISTS (SELECT 1 FROM Строки_заказов oi
                                JOIN Заказы o ON o.Код_заказа = oi.Код_заказа
                                JOIN Товарные_позиции si ON si.Код_позиции = oi.Код_позиции
                                WHERE si.Код_товара = p.Код_товара AND o.Дата_заказа >= @a AND o.Дата_заказа < @b)
                   THEN p.Цена ELSE ROUND(p.Цена * 0.75, 2) END AS Price
              FROM Товары p JOIN Категории c ON c.Код_категории = p.Код_категории
              WHERE (p.Наименование LIKE @s OR p.Описание LIKE @s)
                AND (@cat = 0 OR p.Код_категории = @cat)
ORDER BY Price;

-- 5. Статистика заказов (задание 5): те же цифры, что показывает окно «Статистика заказов»
SELECT o.Код_заказа AS Номер, o.Дата_заказа AS Дата,
       u.Фамилия + ' ' + u.Имя AS Клиент,
       ISNULL(SUM(oi.Количество * oi.Цена_за_единицу), 0) AS Сумма
FROM Заказы o
JOIN Пользователи u ON u.Код_пользователя = o.Код_пользователя
LEFT JOIN Строки_заказов oi ON oi.Код_заказа = o.Код_заказа
GROUP BY o.Код_заказа, o.Дата_заказа, u.Фамилия, u.Имя
ORDER BY o.Код_заказа;

SELECT COUNT(*) AS Всего_заказов,
       ISNULL(SUM(oi.Количество * oi.Цена_за_единицу), 0) AS Общая_выручка,
       ISNULL(SUM(oi.Количество * oi.Цена_за_единицу), 0)
           / NULLIF((SELECT COUNT(*) FROM Заказы), 0) AS Средний_чек
FROM Заказы o LEFT JOIN Строки_заказов oi ON oi.Код_заказа = o.Код_заказа;
