﻿using System;
using System.Data;
using System.Windows.Forms;

// Статистика заказов (задание 5). Вид — в StatisticsForm.Designer.cs.
public partial class StatisticsForm : Form
{
    public StatisticsForm()
    {
        InitializeComponent();
        LoadStats();
    }

    void LoadStats()
    {
        // Все заказы базы с итоговой суммой каждого (сумма строк заказа).
        // LEFT JOIN нужен, чтобы заказ без позиций тоже попал в список (с суммой 0).
        var t = Db.Table(@"SELECT o.Код_заказа AS Номер, o.Дата_заказа AS Дата,
                                  u.Фамилия + ' ' + u.Имя AS Клиент,
                                  ISNULL(SUM(oi.Количество * oi.Цена_за_единицу), 0) AS Сумма
                           FROM Заказы o
                           JOIN Пользователи u ON u.Код_пользователя = o.Код_пользователя
                           LEFT JOIN Строки_заказов oi ON oi.Код_заказа = o.Код_заказа
                           GROUP BY o.Код_заказа, o.Дата_заказа, u.Фамилия, u.Имя
                           ORDER BY o.Код_заказа");
        gridOrders.DataSource = t;

        // Три общих показателя считаем по уже полученной таблице.
        decimal revenue = 0;
        foreach (DataRow r in t.Rows) revenue += (decimal)r["Сумма"];
        lblCount.Text = "Всего заказов: " + t.Rows.Count;
        lblRevenue.Text = "Общая выручка: " + revenue.ToString("N2") + " ₽";
        lblAverage.Text = "Средний чек: " + (t.Rows.Count == 0 ? 0m : revenue / t.Rows.Count).ToString("N2") + " ₽";
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }
}
