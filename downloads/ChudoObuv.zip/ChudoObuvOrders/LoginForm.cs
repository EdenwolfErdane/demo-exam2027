﻿using System;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Внешний вид окна настраивается мышкой (LoginForm.Designer.cs). Здесь — только логика.
public partial class LoginForm : Form
{
    public LoginForm() { InitializeComponent(); }

    // Кнопка «Войти»
    private void btnOk_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtLogin.Text))
        {
            MessageBox.Show("Введите логин из списка пользователей и нажмите «Войти».", "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // Пользователи и роли загружает адаптер из мастера, поиск — по готовой таблице.
        var ds = Session.Data;
        new ПользователиTableAdapter().Fill(ds.Пользователи);
        new РолиTableAdapter().Fill(ds.Роли);

        string login = txtLogin.Text.Trim();
        Чудо_ОбувьDataSet.ПользователиRow user = null;
        foreach (var u in ds.Пользователи)
            if (string.Equals(u.Логин, login, StringComparison.OrdinalIgnoreCase)) { user = u; break; }

        if (user == null)
        {
            MessageBox.Show("Пользователь не найден. Проверьте логин.", "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        Session.UserId = user.Код_пользователя;
        Session.FullName = user.Фамилия + " " + user.Имя + (user.IsОтчествоNull() ? "" : " " + user.Отчество);
        Session.Role = user.РолиRow == null ? "" : user.РолиRow.Название_роли;
        DialogResult = DialogResult.OK;
    }

    // Кнопка «Без входа»
    private void btnGuest_Click(object sender, EventArgs e)
    {
        DialogResult = DialogResult.OK;
    }
}
