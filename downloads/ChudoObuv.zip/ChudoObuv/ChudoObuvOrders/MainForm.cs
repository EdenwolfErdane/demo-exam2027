using System;
using System.Data;
using System.Windows.Forms;

// Каталог: поиск, фильтр, сортировка, карточки. Вид окна — в MainForm.Designer.cs.
public partial class MainForm : Form
{
    bool ready = false;   // пока окно строится, каталог не перечитываем
    bool pick;            // true — каталог открыт из «Заказов» для добавления заказа

    public MainForm(bool pick = false)
    {
        InitializeComponent();
        this.pick = pick;
        cmbCat.DisplayMember = "CategoryName";
        cmbCat.ValueMember = "CategoryId";
        cmbCat.DataSource = Db.Table("SELECT 0 AS CategoryId, N'Все категории' AS CategoryName UNION ALL SELECT Код_категории, Название_категории FROM Категории");
        cmbSort.SelectedIndex = 0;
        // Права: гость не ищет и не фильтрует; «Заказы» — менеджер/админ.
        txtSearch.Visible = cmbSort.Visible = cmbCat.Visible = btnCart.Visible = Session.IsAuth;
        btnOrders.Visible = Session.IsStaff;
        lblUser.Text = Session.IsAuth ? Session.FullName : "Гость";
        if (pick) { btnOrders.Visible = false; btnExit.Text = "Назад"; }
        ready = true;
        LoadCatalog();
    }

    // Поиск, сортировка, фильтр — любое изменение перерисовывает каталог.
    private void txtSearch_TextChanged(object sender, EventArgs e) { LoadCatalog(); }
    private void cmbSort_SelectedIndexChanged(object sender, EventArgs e) { LoadCatalog(); }
    private void cmbCat_SelectedIndexChanged(object sender, EventArgs e) { LoadCatalog(); }

    private void btnCart_Click(object sender, EventArgs e) { new CartForm().ShowDialog(); LoadCatalog(); }
    private void btnOrders_Click(object sender, EventArgs e) { new OrdersForm().ShowDialog(); LoadCatalog(); }
    private void btnExit_Click(object sender, EventArgs e)
    {
        if (!pick)   // «Выйти» — на экран входа; «Назад» просто закрывает окно
        {
            Session.Clear();
            Session.LoggedOut = true;
        }
        Close();
    }

    void LoadCatalog()
    {
        if (!ready) return;
        // Прошлый месяц: с 1-го числа прошлого месяца до 1-го числа этого (не включая).
        var thisMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        string order = cmbSort.SelectedIndex == 1 ? "ORDER BY Price ASC"
                     : cmbSort.SelectedIndex == 2 ? "ORDER BY Price DESC" : "ORDER BY p.Код_товара";
        // Цена: заказывали в прошлом месяце — базовая, иначе минус 25%.
        var t = Db.Table(@"SELECT p.Код_товара AS ProductId, p.Наименование AS ProductName, p.Производство AS Manufacturer, p.Состав AS Composition,
              p.Описание AS Description, p.Изображение AS ImageFileName, c.Название_категории AS CategoryName,
              ISNULL((SELECT SUM(Количество) FROM Товарные_позиции WHERE Код_товара = p.Код_товара), 0) AS Qty,
              CASE WHEN EXISTS (SELECT 1 FROM Строки_заказов oi
                                JOIN Заказы o ON o.Код_заказа = oi.Код_заказа
                                JOIN Товарные_позиции si ON si.Код_позиции = oi.Код_позиции
                                WHERE si.Код_товара = p.Код_товара AND o.Дата_заказа >= @a AND o.Дата_заказа < @b)
                   THEN p.Цена ELSE ROUND(p.Цена * 0.75, 2) END AS Price
              FROM Товары p JOIN Категории c ON c.Код_категории = p.Код_категории
              WHERE (p.Наименование LIKE @s OR p.Описание LIKE @s)
                AND (@cat = 0 OR p.Код_категории = @cat) " + order,
            "@a", thisMonth.AddMonths(-1), "@b", thisMonth,
            "@s", "%" + txtSearch.Text + "%", "@cat", Session.IsAuth ? (int)cmbCat.SelectedValue : 0);

        pnlCatalog.Controls.Clear();
        foreach (DataRow r in t.Rows)
        {
            var card = new ProductCard();
            card.Bind(r);
            card.Clicked += OpenProduct;
            pnlCatalog.Controls.Add(card);
        }
        btnCart.Text = "Корзина (" + Session.Cart.Count + ")";
    }

    void OpenProduct(DataRow r)
    {
        new ProductForm(r).ShowDialog();
        LoadCatalog();
    }
}
