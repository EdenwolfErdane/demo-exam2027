﻿using System;
using System.Data;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Форма просмотра товара. Вид — в ProductForm.Designer.cs.
public partial class ProductForm : Form
{
    string name; decimal price;

    public ProductForm(DataRow r)
    {
        InitializeComponent();
        name = (string)r["ProductName"];
        price = (decimal)r["Price"];
        int productId = (int)r["ProductId"];
        // Все поля заполняются данными выбранного товара.
        Text = "Чудо Обувь — " + name;
        lblName.Text = name;
        lblManufacturer.Text = "Производство: " + r["Manufacturer"];
        lblCategory.Text = "Категория: " + r["CategoryName"];
        lblPrice.Text = "Цена со скидкой: " + price.ToString("N0") + " ₽";
        lblComposition.Text = "Состав: " + r["Composition"];
        lblDescription.Text = "Описание: " + r["Description"];
        picImage.Image = ProductCard.LoadImage(r["ImageFileName"] as string);

        // Склад и размеры загружают адаптеры из мастера.
        new Товарные_позицииTableAdapter().Fill(Session.Data.Товарные_позиции);
        new РазмерыTableAdapter().Fill(Session.Data.Размеры);

        // Размерный ряд и свободные размеры собираем по строкам набора.
        decimal min = decimal.MaxValue, max = decimal.MinValue;
        var free = new DataTable("Размеры");
        free.Columns.Add("StockItemId", typeof(int));
        free.Columns.Add("SizeValue", typeof(decimal));
        free.Columns.Add("Quantity", typeof(int));
        foreach (var s in Session.Data.Товарные_позиции)
        {
            if (s.Код_товара != productId) continue;
            var z = s.РазмерыRow;
            if (z == null) continue;
            if (z.Размер < min) min = z.Размер;
            if (z.Размер > max) max = z.Размер;
            if (s.Количество > 0) free.Rows.Add(s.Код_позиции, z.Размер, s.Количество);
        }
        lblRange.Text = min == decimal.MaxValue ? "Размерный ряд: нет данных"
            : "Размерный ряд: " + min.ToString("0.#") + " – " + max.ToString("0.#");

        // Доступные для заказа размеры — только те, что есть на складе.
        cmbSize.DisplayMember = "SizeValue";
        cmbSize.ValueMember = "StockItemId";
        cmbSize.DataSource = free;
        btnAdd.Visible = Session.IsAuth && free.Rows.Count > 0;
    }

    // Выбрали размер — больше остатка этого размера заказать нельзя.
    private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        var row = cmbSize.SelectedItem as DataRowView;
        if (row != null) nudQty.Maximum = (int)row["Quantity"];
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        var row = (DataRowView)cmbSize.SelectedItem;
        Session.Cart.Add(new CartLine { StockItemId = (int)row["StockItemId"], Name = name,
            Size = (decimal)row["SizeValue"], Qty = (int)nudQty.Value, Price = price });
        MessageBox.Show("Добавлено в заказ. Можно выбрать ещё товары или открыть корзину.", "Готово",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        Close();
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }
}
