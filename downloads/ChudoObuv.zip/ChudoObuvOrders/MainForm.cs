﻿using System;
using System.Data;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Каталог: поиск, фильтр, сортировка, карточки. Вид окна — в MainForm.Designer.cs.
public partial class MainForm : Form
{
    bool ready = false;   // пока окно строится, каталог не перечитываем
    bool pick;            // true — каталог открыт из «Заказов» для добавления заказа

    public MainForm(bool pick = false)
    {
        InitializeComponent();
        this.pick = pick;
        // Список категорий для фильтра: первая строка «Все категории».
        new КатегорииTableAdapter().Fill(Session.Data.Категории);
        var cat = new DataTable("Категории");
        cat.Columns.Add("CategoryId", typeof(int));
        cat.Columns.Add("CategoryName", typeof(string));
        cat.Rows.Add(0, "Все категории");
        foreach (var c in Session.Data.Категории)
            cat.Rows.Add(c.Код_категории, c.Название_категории);
        cmbCat.DisplayMember = "CategoryName";
        cmbCat.ValueMember = "CategoryId";
        cmbCat.DataSource = cat;
        cmbSort.SelectedIndex = 0;
        // Права: гость не ищет и не фильтрует; «Заказы» и «Статистика» — менеджер/админ.
        txtSearch.Visible = cmbSort.Visible = cmbCat.Visible = btnCart.Visible = Session.IsAuth;
        btnOrders.Visible = Session.IsStaff;
        btnStats.Visible = Session.IsStaff;
        lblUser.Text = Session.IsAuth ? Session.FullName : "Гость";
        if (pick) { btnOrders.Visible = false; btnStats.Visible = false; btnExit.Text = "Назад"; }
        ready = true;
        LoadCatalog();
    }

    // Поиск, сортировка, фильтр — любое изменение перерисовывает каталог.
    private void txtSearch_TextChanged(object sender, EventArgs e) { LoadCatalog(); }
    private void cmbSort_SelectedIndexChanged(object sender, EventArgs e) { LoadCatalog(); }
    private void cmbCat_SelectedIndexChanged(object sender, EventArgs e) { LoadCatalog(); }

    private void btnCart_Click(object sender, EventArgs e) { new CartForm().ShowDialog(); LoadCatalog(); }
    private void btnOrders_Click(object sender, EventArgs e) { new OrdersForm().ShowDialog(); LoadCatalog(); }
    private void btnStats_Click(object sender, EventArgs e) { new StatisticsForm().ShowDialog(); }
    private void btnExit_Click(object sender, EventArgs e)
    {
        if (!pick)   // «Выйти» — на экран входа; «Назад» просто закрывает окно
        {
            Session.Clear();
            Session.LoggedOut = true;
        }
        Close();
    }

    void LoadCatalog()
    {
        if (!ready) return;
        var ds = Session.Data;
        // Все таблицы, нужные каталогу, загружают адаптеры из мастера.
        new ТоварыTableAdapter().Fill(ds.Товары);
        new КатегорииTableAdapter().Fill(ds.Категории);
        new Товарные_позицииTableAdapter().Fill(ds.Товарные_позиции);
        new Строки_заказовTableAdapter().Fill(ds.Строки_заказов);
        new ЗаказыTableAdapter().Fill(ds.Заказы);

        // Прошлый месяц: с 1-го числа прошлого месяца до 1-го числа этого (не включая).
        var thisMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        var from = thisMonth.AddMonths(-1);

        // Каталог собирается в памяти из строк набора — без единого запроса.
        var t = new DataTable("Каталог");
        t.Columns.Add("ProductId", typeof(int));
        t.Columns.Add("ProductName", typeof(string));
        t.Columns.Add("Manufacturer", typeof(string));
        t.Columns.Add("Composition", typeof(string));
        t.Columns.Add("Description", typeof(string));
        t.Columns.Add("ImageFileName", typeof(string));
        t.Columns.Add("CategoryName", typeof(string));
        t.Columns.Add("Qty", typeof(int));
        t.Columns.Add("Price", typeof(decimal));
        t.Columns.Add("Код_категории", typeof(int));
        foreach (var p in ds.Товары)
        {
            int qty = 0;
            foreach (var s in p.GetТоварные_позицииRows()) qty += s.Количество;
            // Заказывали в прошлом месяце — базовая цена, иначе минус 25%.
            bool ordered = false;
            foreach (var oi in ds.Строки_заказов)
            {
                var pos = oi.Товарные_позицииRow;
                if (pos == null || pos.Код_товара != p.Код_товара) continue;
                var o = oi.ЗаказыRow;
                if (o != null && o.Дата_заказа >= from && o.Дата_заказа < thisMonth) { ordered = true; break; }
            }
            decimal price = ordered ? p.Цена : Math.Round(p.Цена * 0.75m, 2);
            var cat = p.КатегорииRow;
            t.Rows.Add(p.Код_товара, p.Наименование, p.Производство,
                p.IsСоставNull() ? "" : p.Состав,
                p.IsОписаниеNull() ? "" : p.Описание,
                p.IsИзображениеNull() ? "" : p.Изображение,
                cat == null ? "" : cat.Название_категории, qty, price, p.Код_категории);
        }

        // Поиск, фильтр и сортировка — DataView по готовой таблице (это не SQL).
        string search = txtSearch.Text.Replace("'", "''").Trim();
        string filter = "";
        if (search != "") filter += "ProductName LIKE '%" + search + "%' OR Description LIKE '%" + search + "%'";
        if (Session.IsAuth && (int)cmbCat.SelectedValue != 0)
        {
            if (filter != "") filter += " AND ";
            filter += "Код_категории = " + cmbCat.SelectedValue;
        }
        string sort = cmbSort.SelectedIndex == 1 ? "Price ASC"
                    : cmbSort.SelectedIndex == 2 ? "Price DESC" : "ProductId";
        var view = new DataView(t, filter, sort, DataViewRowState.CurrentRows);

        pnlCatalog.Controls.Clear();
        foreach (DataRowView row in view)
        {
            var card = new ProductCard();
            card.Bind(row.Row);
            card.Clicked += OpenProduct;
            pnlCatalog.Controls.Add(card);
        }
        btnCart.Text = "Корзина (" + Session.Cart.Count + ")";
    }

    void OpenProduct(DataRow r)
    {
        new ProductForm(r).ShowDialog();
        LoadCatalog();
    }
}
