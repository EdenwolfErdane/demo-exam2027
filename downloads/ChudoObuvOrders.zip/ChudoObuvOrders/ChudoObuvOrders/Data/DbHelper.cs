// Тянем строку подключения из App.config.
using System.Configuration;
// Всё для работы с SQL Server.
using System.Data.SqlClient;

namespace ChudoObuvOrders.Data
{
    // Класс статический — просто набор полезных методов, экземпляр создавать не нужно.
    public static class DbHelper
    {
        // Строку подключения читаем один раз при старте.
        // "ChudoObuvOrders.Properties.Settings.ConnectionString" — имя строки в App.config.
        private static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["ChudoObuvOrders.Properties.Settings.ConnectionString"].ConnectionString;

        // Создаёт и открывает новое подключение к базе.
        // Закрывать не надо — пусть вызывающий код использует using (...).
        public static SqlConnection GetConnection()
        {
            // Создаём объект подключения по строке.
            var connection = new SqlConnection(ConnectionString);
            // Открываем соединение.
            connection.Open();
            // Отдаём уже открытое подключение.
            return connection;
        }
    }
}