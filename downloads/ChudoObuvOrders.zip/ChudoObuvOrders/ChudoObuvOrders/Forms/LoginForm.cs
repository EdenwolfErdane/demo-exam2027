using System;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Session;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма входа в систему.
    //
    // Компоненты (в дизайнере):
    //   lblTitle     — заголовок "Вход в систему"
    //   lblLogin     — подпись "Логин"
    //   txtLogin     — поле ввода логина
    //   errorProvider — показ ошибок под полем
    //   btnLogin     — кнопка "Войти"
    //   btnGuest     — "Продолжить без входа"
    public partial class LoginForm : Form
    {
        // Репозиторий пользователей.
        private readonly UserRepository _userRepository = new UserRepository();

        public LoginForm()
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Вход в систему";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            Font = AppStyle.DefaultFont;

            // "Продолжить без входа" — просто закрываем окно с результатом Ignore.
            btnGuest.Click += (s, e) => DialogResult = DialogResult.Ignore;
        }

        // Обработчик кнопки "Войти".
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            // Сбрасываем старые ошибки валидации.
            errorProvider.Clear();
            string login = txtLogin.Text.Trim();

            // Пустой логин — показываем ошибку и выходим.
            if (string.IsNullOrWhiteSpace(login))
            {
                errorProvider.SetError(txtLogin, "Введите логин.");
                return;
            }

            try
            {
                // Ищем пользователя в базе.
                var user = _userRepository.FindByLogin(login);
                if (user == null)
                {
                    MessageBox.Show(this,
                        "Пользователь с таким логином не найден в системе. Проверьте правильность ввода.",
                        "Ошибка входа", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Запоминаем пользователя в сессии и закрываем форму с результатом OK.
                CurrentSession.CurrentUser = user;
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                // Ошибка подключения к базе.
                MessageBox.Show(this,
                    $"Не удалось подключиться к базе данных: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}