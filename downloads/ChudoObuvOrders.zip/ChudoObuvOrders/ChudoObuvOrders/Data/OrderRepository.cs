// Exception, DateTime.
using System;
// List, Dictionary.
using System.Collections.Generic;
// SqlConnection, SqlCommand, SqlTransaction.
using System.Data.SqlClient;
// LINQ.
using System.Linq;
// Модели заказов и корзины.
using ChudoObuvOrders.Models;

namespace ChudoObuvOrders.Data
{
    // Своё исключение — чтобы вызывающий код мог поймать именно "не хватает товара".
    public class InsufficientStockException : Exception
    {
        // Просто передаём сообщение в базовый Exception.
        public InsufficientStockException(string message) : base(message) { }
    }

    // Всё, что связано с заказами.
    public class OrderRepository
    {
        // Список заказов с ФИО клиента.
        public List<Order> GetOrders()
        {
            // Сначала все пользователи — превращаем в словарь "id -> User".
            var users = new UserRepository().GetAll().ToDictionary(u => u.UserId);
            // Сюда собираем заказы.
            var result = new List<Order>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Все заказы.
            using (var cmd = new SqlCommand("SELECT * FROM Orders", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    // id клиента из строки заказа.
                    int userId = (int)reader["UserId"];

                    result.Add(new Order
                    {
                        OrderId = (int)reader["OrderId"],
                        OrderDate = (DateTime)reader["OrderDate"],
                        UserId = userId,
                        // ФИО достаём из словаря пользователей.
                        UserFullName = users.ContainsKey(userId) ? users[userId].FullName : ""
                    });
                }
            }

            // Свежие заказы — сверху.
            return result.OrderByDescending(o => o.OrderDate).ToList();
        }

        // Состав одного заказа: товар, размер, количество, цена.
        public List<OrderItem> GetOrderItems(int orderId)
        {
            // Справочник размеров.
            var sizes = ReadSizes();
            // "StockItemId -> (ProductId, SizeValue)".
            var stockToProduct = ReadStockToProduct(sizes);
            // "ProductId -> (Name, Manufacturer)".
            var products = ReadProducts();

            // Результат.
            var result = new List<OrderItem>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Позиции конкретного заказа.
            using (var cmd = new SqlCommand("SELECT * FROM OrderItems WHERE OrderId = @OrderId", conn))
            {
                // Подставляем id заказа.
                cmd.Parameters.AddWithValue("@OrderId", orderId);

                // Читатель.
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // По складской позиции узнаём товар и размер.
                        int stockItemId = (int)reader["StockItemId"];
                        var pair = stockToProduct[stockItemId];
                        int productId = pair.ProductId;
                        decimal sizeValue = pair.SizeValue;

                        // По товару — имя и производителя.
                        var product = products[productId];
                        string name = product.Name;
                        string manufacturer = product.Manufacturer;

                        result.Add(new OrderItem
                        {
                            OrderItemId = (int)reader["OrderItemId"],
                            OrderId = (int)reader["OrderId"],
                            StockItemId = stockItemId,
                            ProductName = name,
                            Manufacturer = manufacturer,
                            SizeValue = sizeValue,
                            Quantity = (int)reader["Quantity"],
                            UnitPrice = (decimal)reader["UnitPrice"]
                        });
                    }
                }
            }

            return result;
        }

        // Справочник размеров "SizeId -> SizeValue".
        private Dictionary<int, decimal> ReadSizes()
        {
            var sizes = new Dictionary<int, decimal>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Размеры.
            using (var cmd = new SqlCommand("SELECT SizeId, SizeValue FROM Sizes", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                    sizes[(int)reader["SizeId"]] = (decimal)reader["SizeValue"];
            }

            return sizes;
        }

        // "StockItemId -> (ProductId, SizeValue)".
        private Dictionary<int, StockProductPair> ReadStockToProduct(Dictionary<int, decimal> sizes)
        {
            var stockToProduct = new Dictionary<int, StockProductPair>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Складские позиции.
            using (var cmd = new SqlCommand("SELECT StockItemId, ProductId, SizeId FROM StockItems", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    // Складываем пару: id товара + значение размера.
                    var pair = new StockProductPair();
                    pair.ProductId = (int)reader["ProductId"];
                    pair.SizeValue = sizes[(int)reader["SizeId"]];
                    stockToProduct[(int)reader["StockItemId"]] = pair;
                }
            }

            return stockToProduct;
        }

        // "ProductId -> (Name, Manufacturer)".
        private Dictionary<int, ProductNamePair> ReadProducts()
        {
            var products = new Dictionary<int, ProductNamePair>();

            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Товары.
            using (var cmd = new SqlCommand("SELECT ProductId, ProductName, Manufacturer FROM Products", conn))
            // Читатель.
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var pair = new ProductNamePair();
                    pair.Name = (string)reader["ProductName"];
                    pair.Manufacturer = (string)reader["Manufacturer"];
                    products[(int)reader["ProductId"]] = pair;
                }
            }

            return products;
        }

        // Создаёт заказ и позиции, списывает товар со склада.
        // Всё в одной транзакции: либо всё, либо ничего.
        public int CreateOrder(int userId, List<CartItem> items)
        {
            // Подключение.
            using (var conn = DbHelper.GetConnection())
            {
                // Транзакция живёт до конца метода.
                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        // Вставляем заказ и получаем его OrderId.
                        int orderId = InsertOrder(conn, transaction, userId);

                        // Каждую позицию корзины обрабатываем отдельно.
                        foreach (var item in items)
                            AddOrderItem(conn, transaction, orderId, item);

                        // Всё ок — фиксируем.
                        transaction.Commit();
                        return orderId;
                    }
                    catch
                    {
                        // Любая ошибка — откатываем всё, что успели.
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        // INSERT заказа + возврат нового OrderId.
        private int InsertOrder(SqlConnection conn, SqlTransaction transaction, int userId)
        {
            // OUTPUT INSERTED.OrderId — SQL Server вернёт id вставленной строки.
            using (var cmd = new SqlCommand(
                "INSERT INTO Orders (OrderDate, UserId) OUTPUT INSERTED.OrderId VALUES (@Date, @UserId)",
                conn, transaction))
            {
                cmd.Parameters.AddWithValue("@Date", DateTime.Now);
                cmd.Parameters.AddWithValue("@UserId", userId);

                // ExecuteScalar возвращает одно значение — OrderId.
                return (int)cmd.ExecuteScalar();
            }
        }

        // Проверяет остаток, списывает товар и добавляет строку в OrderItems.
        private void AddOrderItem(SqlConnection conn, SqlTransaction transaction, int orderId, CartItem item)
        {
            // Сколько сейчас на складе.
            int available = GetAvailableQuantity(conn, transaction, item.StockItemId);

            // Запрошено больше, чем есть — прерываем оформление.
            if (available < item.Quantity)
            {
                throw new InsufficientStockException(
                    $"Недостаточно пар «{item.ProductName}» размера {item.SizeValue}: " +
                    $"доступно {available}, запрошено {item.Quantity}.");
            }

            // Уменьшаем остаток.
            DecreaseStock(conn, transaction, item.StockItemId, item.Quantity);
            // Добавляем позицию в OrderItems.
            InsertOrderItem(conn, transaction, orderId, item);
        }

        // Читаем остаток по складской позиции.
        private int GetAvailableQuantity(SqlConnection conn, SqlTransaction transaction, int stockItemId)
        {
            using (var cmd = new SqlCommand(
                "SELECT Quantity FROM StockItems WHERE StockItemId = @StockItemId", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@StockItemId", stockItemId);
                // Одно число.
                return (int)cmd.ExecuteScalar();
            }
        }

        // UPDATE: уменьшаем остаток.
        private void DecreaseStock(SqlConnection conn, SqlTransaction transaction, int stockItemId, int qty)
        {
            using (var cmd = new SqlCommand(
                "UPDATE StockItems SET Quantity = Quantity - @Qty WHERE StockItemId = @StockItemId",
                conn, transaction))
            {
                cmd.Parameters.AddWithValue("@Qty", qty);
                cmd.Parameters.AddWithValue("@StockItemId", stockItemId);
                // UPDATE ничего не возвращает.
                cmd.ExecuteNonQuery();
            }
        }

        // INSERT позиции заказа.
        private void InsertOrderItem(SqlConnection conn, SqlTransaction transaction, int orderId, CartItem item)
        {
            using (var cmd = new SqlCommand(
                "INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice) " +
                "VALUES (@OrderId, @StockItemId, @Qty, @UnitPrice)",
                conn, transaction))
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.Parameters.AddWithValue("@StockItemId", item.StockItemId);
                cmd.Parameters.AddWithValue("@Qty", item.Quantity);
                cmd.Parameters.AddWithValue("@UnitPrice", item.UnitPrice);
                cmd.ExecuteNonQuery();
            }
        }

        // Админ: поменять дату заказа.
        public void UpdateOrderDate(int orderId, DateTime newDate)
        {
            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // UPDATE одной строки.
            using (var cmd = new SqlCommand(
                "UPDATE Orders SET OrderDate = @Date WHERE OrderId = @OrderId", conn))
            {
                cmd.Parameters.AddWithValue("@Date", newDate);
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.ExecuteNonQuery();
            }
        }

        // Админ: удалить позицию заказа, а товар вернуть на склад.
        public void DeleteOrderItem(int orderItemId)
        {
            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Транзакция.
            using (var transaction = conn.BeginTransaction())
            {
                try
                {
                    // Что и сколько возвращать.
                    var item = ReadOrderItem(conn, transaction, orderItemId);

                    // Возвращаем остаток.
                    IncreaseStock(conn, transaction, item.StockItemId, item.Quantity);
                    // Удаляем саму позицию.
                    DeleteOrderItemRow(conn, transaction, orderItemId);

                    // Фиксируем.
                    transaction.Commit();
                }
                catch
                {
                    // Что-то пошло не так — откат.
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // Читаем StockItemId и Quantity одной позиции заказа.
        private StockQuantity ReadOrderItem(SqlConnection conn, SqlTransaction transaction, int orderItemId)
        {
            using (var cmd = new SqlCommand(
                "SELECT StockItemId, Quantity FROM OrderItems WHERE OrderItemId = @Id", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@Id", orderItemId);

                using (var reader = cmd.ExecuteReader())
                {
                    // У позиции ровно одна строка.
                    reader.Read();

                    var result = new StockQuantity();
                    result.StockItemId = (int)reader["StockItemId"];
                    result.Quantity = (int)reader["Quantity"];
                    return result;
                }
            }
        }

        // UPDATE: увеличиваем остаток.
        private void IncreaseStock(SqlConnection conn, SqlTransaction transaction, int stockItemId, int qty)
        {
            using (var cmd = new SqlCommand(
                "UPDATE StockItems SET Quantity = Quantity + @Qty WHERE StockItemId = @StockItemId",
                conn, transaction))
            {
                cmd.Parameters.AddWithValue("@Qty", qty);
                cmd.Parameters.AddWithValue("@StockItemId", stockItemId);
                cmd.ExecuteNonQuery();
            }
        }

        // DELETE строки из OrderItems.
        private void DeleteOrderItemRow(SqlConnection conn, SqlTransaction transaction, int orderItemId)
        {
            using (var cmd = new SqlCommand(
                "DELETE FROM OrderItems WHERE OrderItemId = @Id", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@Id", orderItemId);
                cmd.ExecuteNonQuery();
            }
        }

        // Удаляем заказ целиком, товар возвращаем на склад.
        public void DeleteOrder(int orderId)
        {
            // Подключение.
            using (var conn = DbHelper.GetConnection())
            // Транзакция.
            using (var transaction = conn.BeginTransaction())
            {
                try
                {
                    // Все позиции заказа.
                    var items = ReadOrderItemsForOrder(conn, transaction, orderId);

                    // Возвращаем каждую позицию на склад.
                    foreach (var item in items)
                        IncreaseStock(conn, transaction, item.StockItemId, item.Quantity);

                    // Удаляем сам заказ (позиции уйдут каскадно по FK).
                    DeleteOrderRow(conn, transaction, orderId);

                    // Фиксируем.
                    transaction.Commit();
                }
                catch
                {
                    // Откат при ошибке.
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // Читаем позиции заказа: список пар (StockItemId, Quantity).
        private List<StockQuantity> ReadOrderItemsForOrder(
            SqlConnection conn, SqlTransaction transaction, int orderId)
        {
            var items = new List<StockQuantity>();

            using (var cmd = new SqlCommand(
                "SELECT StockItemId, Quantity FROM OrderItems WHERE OrderId = @OrderId", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var item = new StockQuantity();
                        item.StockItemId = (int)reader["StockItemId"];
                        item.Quantity = (int)reader["Quantity"];
                        items.Add(item);
                    }
                }
            }

            return items;
        }

        // DELETE заказа из Orders.
        private void DeleteOrderRow(SqlConnection conn, SqlTransaction transaction, int orderId)
        {
            using (var cmd = new SqlCommand(
                "DELETE FROM Orders WHERE OrderId = @OrderId", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // Простой класс-пара, чтобы не использовать кортежи (C# 7.3 без ValueTuple-пакета).
    public class StockProductPair
    {
        public int ProductId { get; set; }
        public decimal SizeValue { get; set; }
    }

    // Пара "имя товара + производитель".
    public class ProductNamePair
    {
        public string Name { get; set; }
        public string Manufacturer { get; set; }
    }

    // Пара "складская позиция + количество".
    public class StockQuantity
    {
        public int StockItemId { get; set; }
        public int Quantity { get; set; }
    }
}