﻿partial class CartForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CartForm));
        this.pnlHeader = new System.Windows.Forms.Panel();
        this.lblTitle = new System.Windows.Forms.Label();
        this.gridCart = new System.Windows.Forms.DataGridView();
        this.nudQty = new System.Windows.Forms.NumericUpDown();
        this.btnQty = new System.Windows.Forms.Button();
        this.btnDelete = new System.Windows.Forms.Button();
        this.lblClient = new System.Windows.Forms.Label();
        this.cmbClient = new System.Windows.Forms.ComboBox();
        this.btnConfirm = new System.Windows.Forms.Button();
        this.btnCancel = new System.Windows.Forms.Button();
        this.btnBack = new System.Windows.Forms.Button();
        this.pnlHeader.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.gridCart)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.nudQty)).BeginInit();
        this.SuspendLayout();
        //
        // pnlHeader
        //
        this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.pnlHeader.Controls.Add(this.lblTitle);
        this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
        this.pnlHeader.Location = new System.Drawing.Point(0, 0);
        this.pnlHeader.Name = "pnlHeader";
        this.pnlHeader.Size = new System.Drawing.Size(700, 56);
        //
        // lblTitle
        //
        this.lblTitle.AutoSize = true;
        this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
        this.lblTitle.ForeColor = System.Drawing.Color.White;
        this.lblTitle.Location = new System.Drawing.Point(20, 14);
        this.lblTitle.Name = "lblTitle";
        this.lblTitle.Size = new System.Drawing.Size(80, 23);
        this.lblTitle.Text = "Корзина";
        //
        // gridCart — список позиций корзины
        //
        this.gridCart.AllowUserToAddRows = false;
        this.gridCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.gridCart.BackgroundColor = System.Drawing.Color.White;
        this.gridCart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.gridCart.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.gridCart.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
        this.gridCart.ColumnHeadersHeight = 32;
        this.gridCart.EnableHeadersVisualStyles = false;
        this.gridCart.Location = new System.Drawing.Point(20, 76);
        this.gridCart.Name = "gridCart";
        this.gridCart.ReadOnly = true;
        this.gridCart.RowHeadersVisible = false;
        this.gridCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.gridCart.Size = new System.Drawing.Size(660, 230);
        //
        // nudQty — количество выбранной позиции
        //
        this.nudQty.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.nudQty.Location = new System.Drawing.Point(20, 320);
        this.nudQty.Minimum = new decimal(new int[] {
        1,
        0,
        0,
        0});
        this.nudQty.Name = "nudQty";
        this.nudQty.Size = new System.Drawing.Size(70, 25);
        this.nudQty.Value = new decimal(new int[] {
        1,
        0,
        0,
        0});
        //
        // btnQty
        //
        this.btnQty.BackColor = System.Drawing.Color.White;
        this.btnQty.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnQty.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnQty.FlatAppearance.BorderSize = 1;
        this.btnQty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnQty.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnQty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnQty.Location = new System.Drawing.Point(100, 318);
        this.btnQty.Name = "btnQty";
        this.btnQty.Size = new System.Drawing.Size(170, 30);
        this.btnQty.Text = "Изменить кол-во";
        this.btnQty.UseVisualStyleBackColor = false;
        this.btnQty.Click += new System.EventHandler(this.btnQty_Click);
        //
        // btnDelete
        //
        this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
        this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDelete.FlatAppearance.BorderSize = 0;
        this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F);
        this.btnDelete.ForeColor = System.Drawing.Color.White;
        this.btnDelete.Location = new System.Drawing.Point(280, 318);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(170, 30);
        this.btnDelete.Text = "Удалить позицию";
        this.btnDelete.UseVisualStyleBackColor = false;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        //
        // lblClient
        //
        this.lblClient.AutoSize = true;
        this.lblClient.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.lblClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblClient.Location = new System.Drawing.Point(20, 366);
        this.lblClient.Name = "lblClient";
        this.lblClient.Size = new System.Drawing.Size(56, 19);
        this.lblClient.Text = "Клиент";
        //
        // cmbClient — выбор клиента для менеджера/админа
        //
        this.cmbClient.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.cmbClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.cmbClient.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.cmbClient.Location = new System.Drawing.Point(82, 363);
        this.cmbClient.Name = "cmbClient";
        this.cmbClient.Size = new System.Drawing.Size(360, 23);
        //
        // btnConfirm — оформить заказ
        //
        this.btnConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnConfirm.FlatAppearance.BorderSize = 0;
        this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnConfirm.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnConfirm.ForeColor = System.Drawing.Color.White;
        this.btnConfirm.Location = new System.Drawing.Point(20, 408);
        this.btnConfirm.Name = "btnConfirm";
        this.btnConfirm.Size = new System.Drawing.Size(200, 36);
        this.btnConfirm.Text = "Подтвердить";
        this.btnConfirm.UseVisualStyleBackColor = false;
        this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
        //
        // btnCancel — очистить корзину
        //
        this.btnCancel.BackColor = System.Drawing.Color.White;
        this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnCancel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
        this.btnCancel.FlatAppearance.BorderSize = 1;
        this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnCancel.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
        this.btnCancel.Location = new System.Drawing.Point(230, 408);
        this.btnCancel.Name = "btnCancel";
        this.btnCancel.Size = new System.Drawing.Size(200, 36);
        this.btnCancel.Text = "Отказаться";
        this.btnCancel.UseVisualStyleBackColor = false;
        this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
        //
        // btnBack — закрыть окно
        //
        this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(87)))));
        this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnBack.FlatAppearance.BorderSize = 0;
        this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.btnBack.Location = new System.Drawing.Point(480, 408);
        this.btnBack.Name = "btnBack";
        this.btnBack.Size = new System.Drawing.Size(200, 36);
        this.btnBack.Text = "Назад";
        this.btnBack.UseVisualStyleBackColor = false;
        this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
        //
        // CartForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.ClientSize = new System.Drawing.Size(700, 460);
        this.Controls.Add(this.pnlHeader);
        this.Controls.Add(this.gridCart);
        this.Controls.Add(this.nudQty);
        this.Controls.Add(this.btnQty);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.lblClient);
        this.Controls.Add(this.cmbClient);
        this.Controls.Add(this.btnConfirm);
        this.Controls.Add(this.btnCancel);
        this.Controls.Add(this.btnBack);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MaximizeBox = false;
        this.Name = "CartForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Чудо Обувь — Корзина";
        this.pnlHeader.ResumeLayout(false);
        this.pnlHeader.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.gridCart)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.nudQty)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.Panel pnlHeader;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.DataGridView gridCart;
    private System.Windows.Forms.NumericUpDown nudQty;
    private System.Windows.Forms.Button btnQty;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.Label lblClient;
    private System.Windows.Forms.ComboBox cmbClient;
    private System.Windows.Forms.Button btnConfirm;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.Button btnBack;
}
