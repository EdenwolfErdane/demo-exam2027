using System;
using System.Windows.Forms;

// Корзина и оформление заказа. Вид — в CartForm.Designer.cs.
public partial class CartForm : Form
{
    public CartForm()
    {
        InitializeComponent();
        gridCart.DataSource = Session.Cart;   // таблица сама показывает список
        // Менеджер и администратор оформляют заказ на выбранного клиента.
        lblClient.Visible = cmbClient.Visible = Session.IsStaff;
        if (Session.IsStaff)
        {
            cmbClient.DisplayMember = "Fio";
            cmbClient.ValueMember = "UserId";
            cmbClient.DataSource = Db.Table("SELECT Код_пользователя AS UserId, Фамилия + ' ' + Имя + ' ' + ISNULL(Отчество, '') AS Fio FROM Пользователи ORDER BY Фамилия");
        }
    }

    // Изменить количество у выбранной строки.
    private void btnQty_Click(object sender, EventArgs e)
    {
        if (gridCart.CurrentRow == null) return;
        int i = gridCart.CurrentRow.Index;
        Session.Cart[i].Qty = (int)nudQty.Value;
        Session.Cart.ResetItem(i);   // перерисовать строку
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (gridCart.CurrentRow != null) Session.Cart.RemoveAt(gridCart.CurrentRow.Index);
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        if (MessageBox.Show("Очистить корзину?", "Отказ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        { Session.Cart.Clear(); Close(); }
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }

    private void btnConfirm_Click(object sender, EventArgs e)
    {
        if (Session.Cart.Count == 0) { MessageBox.Show("Корзина пуста.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        if (MessageBox.Show("Оформить заказ?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            int clientId = Session.IsStaff ? (int)cmbClient.SelectedValue : Session.UserId;
            using (var c = Db.Open())
            using (var t = c.BeginTransaction())      // всё или ничего
            {
                try
                {
                    int orderId = (int)Db.Cmd(c, "INSERT INTO Заказы (Код_пользователя) OUTPUT INSERTED.Код_заказа VALUES (@u)",
                        new object[] { "@u", clientId }, t).ExecuteScalar();
                    foreach (var l in Session.Cart)
                    {
                        // Списываем остаток; если не хватило — 0 строк изменено.
                        int n = Db.Cmd(c, "UPDATE Товарные_позиции SET Количество = Количество - @q WHERE Код_позиции = @s AND Количество >= @q",
                            new object[] { "@q", l.Qty, "@s", l.StockItemId }, t).ExecuteNonQuery();
                        if (n == 0) throw new Exception("Не хватает на складе: " + l.Name);
                        Db.Cmd(c, "INSERT INTO Строки_заказов (Код_заказа, Код_позиции, Количество, Цена_за_единицу) VALUES (@o, @s, @q, @p)",
                            new object[] { "@o", orderId, "@s", l.StockItemId, "@q", l.Qty, "@p", l.Price }, t).ExecuteNonQuery();
                    }
                    t.Commit();
                }
                catch { t.Rollback(); throw; }
            }
            Session.Cart.Clear();
            MessageBox.Show("Заказ оформлен.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Не удалось оформить заказ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
