namespace ChudoObuvOrders.Models
{
    // Одна складская позиция: конкретный размер товара и его количество.
    public class StockItem
    {
        public int StockItemId { get; set; }
        public int ProductId { get; set; }
        public decimal SizeValue { get; set; }
        public int Quantity { get; set; }
    }
}