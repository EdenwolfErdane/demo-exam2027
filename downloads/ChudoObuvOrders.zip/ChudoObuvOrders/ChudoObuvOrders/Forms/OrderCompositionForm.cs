using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.Session;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма состава заказа.
    //
    // Компоненты (в дизайнере):
    //   lblOrderInfo  — "Заказ от {дата} — {ФИО клиента}"
    //   dtpOrderDate  — дата заказа (правит только админ)
    //   btnSaveDate   — сохранить дату (только админ)
    //   gridItems     — таблица состава
    //   btnDeleteItem — удалить позицию (только админ)
    //   lblTotal      — итог
    //   btnClose      — закрыть
    public partial class OrderCompositionForm : Form
    {
        // Репозиторий заказов.
        private readonly OrderRepository _orderRepository = new OrderRepository();
        // Текущий заказ.
        private readonly Order _order;
        // Список позиций заказа.
        private System.Collections.Generic.List<OrderItem> _items;

        public OrderCompositionForm(Order order)
        {
            _order = order;
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Состав заказа";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlTop.BackColor = AppStyle.SecondaryBackgroundColor;
            pnlBottom.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;

            // Кнопки/поля для админа.
            bool isAdmin = CurrentSession.IsAdministrator;
            dtpOrderDate.Enabled = isAdmin;
            btnSaveDate.Visible = isAdmin;
            btnDeleteItem.Visible = isAdmin;

            // Обработчики.
            btnSaveDate.Click += (s, e) => SaveDate();
            btnDeleteItem.Click += (s, e) => DeleteItem();
            btnClose.Click += (s, e) => Close();

            // При загрузке — строим таблицу.
            Load += (s, e) => RefreshGrid();
        }

        // Перерисовывает таблицу состава и итог.
        private void RefreshGrid()
        {
            lblOrderInfo.Text = $"Заказ от {_order.OrderDate:dd.MM.yyyy} — {_order.UserFullName}";
            dtpOrderDate.Value = _order.OrderDate;

            // Перечитываем позиции.
            _items = _orderRepository.GetOrderItems(_order.OrderId);

            gridItems.DataSource = null;
            gridItems.DataSource = _items.Select(i => new
            {
                Модель = $"{i.Manufacturer} | {i.ProductName}",
                Размер = i.SizeValue,
                Количество = i.Quantity,
                Цена = i.UnitPrice,
                Сумма = i.Total
            }).ToList();

            lblTotal.Text = $"Итого: {_items.Sum(i => i.Total):N0} ₽";
        }

        // Сохранить новую дату заказа.
        private void SaveDate()
        {
            try
            {
                _orderRepository.UpdateOrderDate(_order.OrderId, dtpOrderDate.Value);
                _order.OrderDate = dtpOrderDate.Value;
                RefreshGrid();
                MessageBox.Show(this, "Дата заказа обновлена.", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось сохранить дату: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Удалить выбранную позицию заказа.
        private void DeleteItem()
        {
            // Ничего не выбрано — выходим.
            if (gridItems.CurrentRow == null || gridItems.CurrentRow.Index >= _items.Count) return;
            var item = _items[gridItems.CurrentRow.Index];

            // Нельзя удалить последнюю позицию — тогда удаляйте заказ целиком.
            if (_items.Count == 1)
            {
                MessageBox.Show(this,
                    "Нельзя удалить последнюю позицию заказа. Чтобы удалить заказ целиком, используйте кнопку «Удалить заказ» в списке заказов.",
                    "Действие недоступно", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Подтверждение.
            var confirm = MessageBox.Show(this,
                $"Удалить из заказа позицию «{item.ProductName}», размер {item.SizeValue}? Товар будет возвращён на склад.",
                "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            try
            {
                _orderRepository.DeleteOrderItem(item.OrderItemId);
                RefreshGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось удалить позицию: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}