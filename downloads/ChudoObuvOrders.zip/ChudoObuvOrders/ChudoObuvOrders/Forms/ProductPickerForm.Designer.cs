namespace ChudoObuvOrders.Forms
{
    partial class ProductPickerForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblClient;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ListBox lstProducts;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnGoToCart;
        private System.Windows.Forms.Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblClient = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lstProducts = new System.Windows.Forms.ListBox();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnGoToCart = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            //
            // lblClient
            //
            this.lblClient.AutoSize = true;
            this.lblClient.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold);
            this.lblClient.Location = new System.Drawing.Point(12, 8);
            this.lblClient.Name = "lblClient";
            this.lblClient.Size = new System.Drawing.Size(120, 22);
            this.lblClient.Text = "Клиент:";
            //
            // txtSearch
            //
            this.txtSearch.Location = new System.Drawing.Point(12, 36);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(500, 27);
            //
            // pnlTop
            //
            this.pnlTop.Controls.Add(this.lblClient);
            this.pnlTop.Controls.Add(this.txtSearch);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(524, 76);
            //
            // lstProducts
            //
            this.lstProducts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstProducts.ItemHeight = 19;
            this.lstProducts.Location = new System.Drawing.Point(0, 76);
            this.lstProducts.Name = "lstProducts";
            this.lstProducts.Size = new System.Drawing.Size(524, 322);
            //
            // btnSelect
            //
            this.btnSelect.Location = new System.Drawing.Point(12, 12);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(200, 36);
            this.btnSelect.Text = "Открыть карточку товара";
            this.btnSelect.UseVisualStyleBackColor = true;
            //
            // btnGoToCart
            //
            this.btnGoToCart.BackColor = System.Drawing.ColorTranslator.FromHtml("#70B2AF");
            this.btnGoToCart.Location = new System.Drawing.Point(222, 12);
            this.btnGoToCart.Name = "btnGoToCart";
            this.btnGoToCart.Size = new System.Drawing.Size(200, 36);
            this.btnGoToCart.Text = "Перейти к корзине (0)";
            this.btnGoToCart.UseVisualStyleBackColor = false;
            //
            // btnCancel
            //
            this.btnCancel.Location = new System.Drawing.Point(432, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 36);
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            //
            // pnlBottom
            //
            this.pnlBottom.Controls.Add(this.btnSelect);
            this.pnlBottom.Controls.Add(this.btnGoToCart);
            this.pnlBottom.Controls.Add(this.btnCancel);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 398);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(524, 60);
            //
            // ProductPickerForm
            //
            this.ClientSize = new System.Drawing.Size(524, 458);
            this.Controls.Add(this.lstProducts);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.MinimumSize = new System.Drawing.Size(460, 380);
            this.Name = "ProductPickerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}
