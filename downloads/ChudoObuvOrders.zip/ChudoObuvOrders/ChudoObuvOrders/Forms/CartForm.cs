using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.Session;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма корзины.
    //
    // Компоненты (создаются в дизайнере):
    //   gridCart       — таблица с составом заказа
    //   lblTotal       — итоговая сумма
    //   btnRemove      — удалить выбранную позицию
    //   btnConfirm     — подтвердить заказ
    //   btnCancelOrder — отказаться (очистить корзину)
    //   btnBack        — назад к каталогу (корзина сохраняется)
    public partial class CartForm : Form
    {
        // Репозиторий заказов.
        private readonly OrderRepository _orderRepository = new OrderRepository();

        public CartForm()
        {
            // Инициализация компонентов из дизайнера.
            InitializeComponent();

            // Настраиваем внешний вид.
            Text = "Чудо Обувь — Оформление заказа";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlBottom.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;

            // Обработчики кнопок.
            btnRemove.Click += (s, e) => RemoveSelected();
            btnConfirm.Click += BtnConfirm_Click;
            btnCancelOrder.Click += BtnCancelOrder_Click;
            btnBack.Click += (s, e) => Close();

            // При загрузке формы обновляем таблицу.
            Load += (s, e) => RefreshGrid();
        }

        // Перерисовывает таблицу корзины и итог.
        private void RefreshGrid()
        {
            // Обнуляем источник, потом заново — иначе DataGridView может не обновиться.
            gridCart.DataSource = null;
            gridCart.DataSource = CartContext.Items
                .Select(i => new
                {
                    i.ProductName,
                    i.Manufacturer,
                    Размер = i.SizeValue,
                    i.Quantity,
                    Цена = i.UnitPrice,
                    Сумма = i.Total
                })
                .ToList();

            // Итоговая сумма.
            lblTotal.Text = $"Итого: {CartContext.Items.Sum(i => i.Total):N0} ₽";

            // Кнопки активны, только если в корзине что-то есть.
            btnConfirm.Enabled = btnCancelOrder.Enabled = btnRemove.Enabled = CartContext.Items.Count > 0;
        }

        // Удаление выбранной строки из корзины.
        private void RemoveSelected()
        {
            // Строка не выбрана — ничего не делаем.
            if (gridCart.CurrentRow == null) return;

            // Индекс выбранной строки совпадает с индексом в списке корзины.
            int rowIndex = gridCart.CurrentRow.Index;
            if (rowIndex >= 0 && rowIndex < CartContext.Items.Count)
                CartContext.Items.RemoveAt(rowIndex);

            RefreshGrid();
        }

        // Кнопка "Подтвердить заказ".
        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            // Пустая корзина — нечего оформлять.
            if (CartContext.Items.Count == 0) return;

            // Спрашиваем подтверждение.
            var confirmResult = MessageBox.Show(this,
                "Оформить заказ на выбранные товарные позиции? Отменить оформленный заказ можно будет только через раздел администратора.",
                "Подтверждение заказа", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmResult != DialogResult.Yes) return;

            try
            {
                // Если менеджер оформляет на клиента — берём его, иначе текущего пользователя.
                int userId = (CartContext.OrderOnBehalfOf ?? CurrentSession.CurrentUser).UserId;
                _orderRepository.CreateOrder(userId, CartContext.Items);

                MessageBox.Show(this, "Заказ успешно оформлен.", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Очищаем корзину и закрываем форму с результатом OK.
                CartContext.Clear();
                DialogResult = DialogResult.OK;
            }
            catch (InsufficientStockException ex)
            {
                // Не хватило товара — показываем предупреждение.
                MessageBox.Show(this, ex.Message, "Недостаточно товара на складе",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                RefreshGrid();
            }
            catch (Exception ex)
            {
                // Любая другая ошибка.
                MessageBox.Show(this, $"Не удалось оформить заказ: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Кнопка "Отказаться от заказа".
        private void BtnCancelOrder_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show(this,
                "Отказаться от текущего заказа? Все выбранные позиции будут удалены.",
                "Подтверждение отмены", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirmResult != DialogResult.Yes) return;

            // Чистим корзину и закрываем форму.
            CartContext.Clear();
            RefreshGrid();
            Close();
        }
    }
}