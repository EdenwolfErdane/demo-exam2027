using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

// Карточка товара в каталоге (User Control). Вид — в Designer, здесь — заполнение данными.
public partial class ProductCard : UserControl
{
    public event Action<DataRow> Clicked;
    DataRow row;

    public ProductCard() { InitializeComponent(); }

    public void Bind(DataRow r)
    {
        row = r;
        int qty = (int)r["Qty"];
        // Мало на складе (3 и меньше) — красный фон.
        pnlRoot.BackColor = qty <= 3 ? Color.FromArgb(255, 128, 128) : Color.White;
        lblInfo.Text = r["Manufacturer"] + " | " + r["ProductName"] + "\n" + r["CategoryName"] + "\nСостав: " + r["Composition"];
        lblPrice.Text = ((decimal)r["Price"]).ToString("N0") + " ₽\n" + (qty > 5 ? "много" : "мало");
        picImage.Image = LoadImage(r["ImageFileName"] as string);
    }

    // Нет картинки (пусто или файла нет) — берём заглушку picture.png.
    public static Image LoadImage(string fileName)
    {
        string path = Path.Combine(Application.StartupPath, "Resources", "Images", fileName ?? "");
        if (!File.Exists(path)) path = Path.Combine(Application.StartupPath, "Resources", "picture.png");
        return Image.FromFile(path);
    }

    // Один обработчик Click на панель, картинку и обе надписи.
    private void Card_Click(object sender, EventArgs e)
    {
        if (Clicked != null) Clicked(row);
    }
}
