﻿partial class StatisticsForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StatisticsForm));
        this.gridOrders = new System.Windows.Forms.DataGridView();
        this.lblCount = new System.Windows.Forms.Label();
        this.lblRevenue = new System.Windows.Forms.Label();
        this.lblAverage = new System.Windows.Forms.Label();
        this.btnBack = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).BeginInit();
        this.SuspendLayout();
        //
        // gridOrders — таблица всех заказов
        //
        this.gridOrders.AllowUserToAddRows = false;
        this.gridOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.gridOrders.BackgroundColor = System.Drawing.Color.White;
        this.gridOrders.Location = new System.Drawing.Point(10, 10);
        this.gridOrders.Name = "gridOrders";
        this.gridOrders.ReadOnly = true;
        this.gridOrders.RowHeadersVisible = false;
        this.gridOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.gridOrders.Size = new System.Drawing.Size(660, 230);
        this.gridOrders.TabIndex = 0;
        //
        // lblCount — показатель «Всего заказов»
        //
        this.lblCount.AutoSize = true;
        this.lblCount.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
        this.lblCount.Location = new System.Drawing.Point(10, 250);
        this.lblCount.Name = "lblCount";
        this.lblCount.Text = "Всего заказов: 0";
        this.lblCount.TabIndex = 1;
        //
        // lblRevenue — показатель «Общая выручка»
        //
        this.lblRevenue.AutoSize = true;
        this.lblRevenue.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
        this.lblRevenue.Location = new System.Drawing.Point(190, 250);
        this.lblRevenue.Name = "lblRevenue";
        this.lblRevenue.Text = "Общая выручка: 0 ₽";
        this.lblRevenue.TabIndex = 2;
        //
        // lblAverage — показатель «Средний чек»
        //
        this.lblAverage.AutoSize = true;
        this.lblAverage.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
        this.lblAverage.Location = new System.Drawing.Point(400, 250);
        this.lblAverage.Name = "lblAverage";
        this.lblAverage.Text = "Средний чек: 0 ₽";
        this.lblAverage.TabIndex = 3;
        //
        // btnBack
        //
        this.btnBack.Location = new System.Drawing.Point(540, 285);
        this.btnBack.Name = "btnBack";
        this.btnBack.Size = new System.Drawing.Size(130, 28);
        this.btnBack.TabIndex = 4;
        this.btnBack.Text = "Назад";
        this.btnBack.UseVisualStyleBackColor = true;
        this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
        //
        // StatisticsForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.White;
        this.ClientSize = new System.Drawing.Size(684, 323);
        this.Controls.Add(this.gridOrders);
        this.Controls.Add(this.lblCount);
        this.Controls.Add(this.lblRevenue);
        this.Controls.Add(this.lblAverage);
        this.Controls.Add(this.btnBack);
        this.Font = new System.Drawing.Font("Calibri", 10F);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MaximizeBox = false;
        this.Name = "StatisticsForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        this.Text = "Чудо Обувь — Статистика заказов";
        ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView gridOrders;
    private System.Windows.Forms.Label lblCount;
    private System.Windows.Forms.Label lblRevenue;
    private System.Windows.Forms.Label lblAverage;
    private System.Windows.Forms.Button btnBack;
}
