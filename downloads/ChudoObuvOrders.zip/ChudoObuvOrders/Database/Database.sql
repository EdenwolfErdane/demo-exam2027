/* =========================================================================
   БД для системы оформления заказа обуви "Чудо Обувь"
   СУБД: Microsoft SQL Server
   Схема нормализована до 3НФ, обеспечена ссылочная целостность (FK).
   Совместимо с SQL Server 2008 и новее (без DATEFROMPARTS/STRING_AGG и т.п.).
   ========================================================================= */

CREATE DATABASE ChudoObuvDB;
GO
USE ChudoObuvDB;
GO

/* ---------- Справочник ролей пользователей ---------- */
CREATE TABLE Roles
(
    RoleId      INT IDENTITY(1,1) NOT NULL,
    RoleName    NVARCHAR(50)      NOT NULL,
    CONSTRAINT PK_Roles PRIMARY KEY (RoleId),
    CONSTRAINT UQ_Roles_RoleName UNIQUE (RoleName)
);
GO

/* ---------- Пользователи системы (вход по логину, без пароля) ---------- */
CREATE TABLE Users
(
    UserId      INT IDENTITY(1,1) NOT NULL,
    LastName    NVARCHAR(100)     NOT NULL,
    FirstName   NVARCHAR(100)     NOT NULL,
    MiddleName  NVARCHAR(100)     NULL,
    Login       NVARCHAR(50)      NOT NULL,
    RoleId      INT               NOT NULL,
    CONSTRAINT PK_Users PRIMARY KEY (UserId),
    CONSTRAINT UQ_Users_Login UNIQUE (Login),
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId)
        REFERENCES Roles (RoleId)
        ON UPDATE CASCADE ON DELETE NO ACTION
);
GO

/* ---------- Категории товаров (используются для фильтра каталога) ---------- */
CREATE TABLE Categories
(
    CategoryId   INT IDENTITY(1,1) NOT NULL,
    CategoryName NVARCHAR(100)     NOT NULL,
    CONSTRAINT PK_Categories PRIMARY KEY (CategoryId),
    CONSTRAINT UQ_Categories_Name UNIQUE (CategoryName)
);
GO

/* ---------- Модели обуви (карточка товара в каталоге) ---------- */
CREATE TABLE Products
(
    ProductId       INT IDENTITY(1,1)  NOT NULL,
    CategoryId      INT                NOT NULL,
    SubcategoryName NVARCHAR(100)      NULL,
    ProductName     NVARCHAR(255)      NOT NULL,
    Manufacturer    NVARCHAR(150)      NOT NULL,
    Description     NVARCHAR(MAX)      NULL,
    Composition     NVARCHAR(MAX)      NULL,
    ImageFileName   NVARCHAR(255)      NULL,      -- имя файла в Resources\Images, NULL/не найден -> picture.png
    BasePrice       DECIMAL(10,2)      NOT NULL,
    CONSTRAINT PK_Products PRIMARY KEY (ProductId),
    CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryId)
        REFERENCES Categories (CategoryId)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT CK_Products_BasePrice CHECK (BasePrice >= 0)
);
GO

/* ---------- Размерный ряд (включает полуразмеры, напр. 37.5) ---------- */
CREATE TABLE Sizes
(
    SizeId    INT IDENTITY(1,1) NOT NULL,
    SizeValue DECIMAL(4,1)      NOT NULL,
    CONSTRAINT PK_Sizes PRIMARY KEY (SizeId),
    CONSTRAINT UQ_Sizes_Value UNIQUE (SizeValue)
);
GO

/* ---------- Товарная позиция: сочетание модель + размер, доступное количество ---------- */
CREATE TABLE StockItems
(
    StockItemId INT IDENTITY(1,1) NOT NULL,
    ProductId   INT               NOT NULL,
    SizeId      INT               NOT NULL,
    Quantity    INT               NOT NULL DEFAULT 0,
    CONSTRAINT PK_StockItems PRIMARY KEY (StockItemId),
    CONSTRAINT UQ_StockItems_ProductSize UNIQUE (ProductId, SizeId),
    CONSTRAINT FK_StockItems_Products FOREIGN KEY (ProductId)
        REFERENCES Products (ProductId)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_StockItems_Sizes FOREIGN KEY (SizeId)
        REFERENCES Sizes (SizeId)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT CK_StockItems_Quantity CHECK (Quantity >= 0)
);
GO

/* ---------- Заказы ---------- */
CREATE TABLE Orders
(
    OrderId   INT IDENTITY(1,1) NOT NULL,
    OrderDate DATETIME2         NOT NULL DEFAULT SYSDATETIME(),
    UserId    INT               NOT NULL,   -- клиент, оформивший заказ (ФИО берётся из Users)
    CONSTRAINT PK_Orders PRIMARY KEY (OrderId),
    CONSTRAINT FK_Orders_Users FOREIGN KEY (UserId)
        REFERENCES Users (UserId)
        ON UPDATE CASCADE ON DELETE NO ACTION
);
GO

/* ---------- Состав заказа (товарные позиции в заказе) ---------- */
CREATE TABLE OrderItems
(
    OrderItemId  INT IDENTITY(1,1) NOT NULL,
    OrderId      INT               NOT NULL,
    StockItemId  INT               NOT NULL,
    Quantity     INT               NOT NULL,
    UnitPrice    DECIMAL(10,2)     NOT NULL,  -- цена за единицу на момент оформления (со скидкой)
    CONSTRAINT PK_OrderItems PRIMARY KEY (OrderItemId),
    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId)
        REFERENCES Orders (OrderId)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_OrderItems_StockItems FOREIGN KEY (StockItemId)
        REFERENCES StockItems (StockItemId)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_OrderItems_UnitPrice CHECK (UnitPrice >= 0)
);
GO

/* Скидка 25% и суммарный остаток по модели больше не хранятся во view —
   они вычисляются в коде C# (ProductRepository) по данным простых
   запросов SELECT * FROM Products / StockItems / Orders / OrderItems. */

/* ---------- Полезные индексы под поиск/фильтр/сортировку ---------- */
CREATE INDEX IX_Products_CategoryId ON Products(CategoryId);
CREATE INDEX IX_StockItems_ProductId ON StockItems(ProductId);
CREATE INDEX IX_OrderItems_OrderId ON OrderItems(OrderId);
CREATE INDEX IX_Orders_UserId ON Orders(UserId);
GO

/* =========================================================================
   РОЛИ
   ========================================================================= */
INSERT INTO Roles (RoleName) VALUES
    (N'Администратор'), (N'Менеджер'), (N'Авторизованный пользователь');
GO
-- ===================== СПРАВОЧНИКИ И ПОЛЬЗОВАТЕЛИ =====================
INSERT INTO Users (LastName, FirstName, MiddleName, Login, RoleId) VALUES
    (N'Иванов', N'Иван', N'Сергеевич', N'isivanov', (SELECT RoleId FROM Roles WHERE RoleName = N'Администратор')),
    (N'Петров', N'Пётр', N'Алексеевич', N'papetrov', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Сидорова', N'Анна', N'Дмитриевна', N'asidorova', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Кузнецова', N'Екатерина', N'Андреевна', N'ekuznetsova', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Смирнов', N'Дмитрий', N'Владимирович', N'dsmirnov', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Попов', N'Алексей', N'Николаевич', N'apopov', (SELECT RoleId FROM Roles WHERE RoleName = N'Администратор')),
    (N'Васильева', N'Ольга', N'Игоревна', N'ovasileva', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Соколов', N'Павел', N'Викторович', N'psokolov', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Михайлова', N'Татьяна', N'Юрьевна', N'tmikhailova', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Новикова', N'Наталья', N'Сергеевна', N'nnovikova', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Фёдоров', N'Андрей', N'Максимович', N'afedorov', (SELECT RoleId FROM Roles WHERE RoleName = N'Администратор')),
    (N'Морозов', N'Сергей', N'Павлович', N'smorozov', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Волкова', N'Юлия', N'Александровна', N'jvolkova', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Алексеев', N'Артём', N'Евгеньевич', N'aalekseev', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Лебедева', N'Ирина', N'Владимировна', N'ilebedeva', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Егоров', N'Никита', N'Денисович', N'negorov', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Павлова', N'Елена', N'Петровна', N'epavlova', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь')),
    (N'Козлов', N'Роман', N'Олегович', N'rkozlov', (SELECT RoleId FROM Roles WHERE RoleName = N'Администратор')),
    (N'Степанова', N'Виктория', N'Романовна', N'vstepanova', (SELECT RoleId FROM Roles WHERE RoleName = N'Менеджер')),
    (N'Николаев', N'Владимир', N'Иванович', N'vnikolaev', (SELECT RoleId FROM Roles WHERE RoleName = N'Авторизованный пользователь'));
GO

-- ===================== РАЗМЕРНЫЙ РЯД =====================
INSERT INTO Sizes (SizeValue) VALUES
    (18),
    (19),
    (20),
    (21),
    (22),
    (23),
    (24),
    (25),
    (26),
    (27),
    (28),
    (29),
    (30),
    (31),
    (32),
    (33),
    (34),
    (35),
    (36),
    (36.5),
    (37),
    (37.5),
    (38),
    (38.5),
    (39),
    (39.5),
    (40),
    (40.5),
    (41),
    (41.5),
    (42),
    (42.5),
    (43),
    (44),
    (45);
GO

-- ===================== КАТЕГОРИИ =====================
INSERT INTO Categories (CategoryName) VALUES
    (N'Детская обувь'),
    (N'Женская обувь'),
    (N'Мужская обувь');
GO

-- ===================== ТОВАРЫ (МОДЕЛИ) =====================
INSERT INTO Products (CategoryId, SubcategoryName, ProductName, Manufacturer, Description, Composition, ImageFileName, BasePrice) VALUES
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Кроссовки', N'Кроссовки детские «Звёздочка» экокожа', N'Малыш-Спорт', N'Кроссовки детские «Звёздочка» экокожа. Производитель: ООО «Малыш-Спорт», г. Смоленск', N'Верх — экокожа (полиуретан на хлопковой основе), подкладка — хлопок 100%, подошва — ПВХ', N'IMG_KS_195217.png', 2190),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Кроссовки', N'Кроссовки детские «Гонщик» экокожа', N'Топ-Топ', N'Кроссовки детские «Гонщик» экокожа. Производитель: Фабрика «Топ-Топ», г. Киров', N'Верх — экокожа (микрофибра), подкладка — текстиль сетчатый (полиэстер), подошва — термопластичная резина (ТЭП)', N'IMG_KS_195213.png', 2490),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Кроссовки', N'Кроссовки детские «Радуга» экокожа перфорированная', N'Лапушка', N'Кроссовки детские «Радуга» экокожа перфорированная. Производитель: ИП Смирнова Л.В. (бренд «Лапушка»), г. Вологда', N'Верх — экокожа перфорированная, вставки — нейлон, стелька — ортопедическая с латексной подушкой, подошва — ЭВА', N'IMG_KS_195222.png', 1990),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Сапоги', N'Сапожки детские «Снежинка» зимние на меху', N'Тёплые ножки', N'Сапожки детские «Снежинка» зимние на меху. Производитель: ООО «Тёплые ножки», г. Новосибирск', N'Верх — экокожа морозостойкая, утеплитель — искусственный мех (акрил 70%, полиэстер 30%), подкладка — флис, подошва — термоэластопласт (ТЭП)', N'IMG_KB_185501.png', 3490),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Сапоги', N'Сапожки детские «Медвежонок» демисезонные непромокаемые', N'Северята', N'Сапожки детские «Медвежонок» демисезонные непромокаемые. Производитель: Компания «Северята», г. Архангельск', N'Верх — плащёвая ткань с водоотталкивающей пропиткой (полиэстер 100%), отделка — экокожа, подкладка — микрофибра, мембрана — AirTex, подошва — резина', N'IMG_KB_164816.png', 3190),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Сапоги', N'Сапожки детские «Принцесса» кожаные', N'Весна', N'Сапожки детские «Принцесса» кожаные. Производитель: Мастерская «Весна», г. Тула', N'Верх — натуральная кожа (КРС), подкладка — шерсть натуральная (70%), байка (30%), стелька — войлочная, подошва — полиуретан', N'IMG_KB_164811.png', 4290),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Босоножки', N'Сандалии детские «Пчёлка» ортопедические летние', N'Здоровый шаг', N'Сандалии детские «Пчёлка» ортопедические летние. Производитель: ООО «Здоровый шаг», г. Воронеж', N'Верх — нубук натуральный, подкладка — кожа растительного дубления, стелька — анатомическая с супинатором (латекс + пробка), подошва — каучук', N'IMG_KSd_195207.png', 2790),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Босоножки', N'Сандалии детские «Морячок» текстильные с фиксатором', N'Карапуз', N'Сандалии детские «Морячок» текстильные с фиксатором. Производитель: ИП Кузнецов А.Д. (бренд «Карапуз»), г. Краснодар', N'Верх — джинсовая ткань (хлопок 100%), окантовка — искусственная кожа, подкладка — хлопок, подошва — ЭВА лёгкая', N'IMG_KSd_185508.png', 1690),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Детская обувь'), N'Туфли', N'Туфли детские «Бантик» лаковые праздничные', N'Маленький франт', N'Туфли детские «Бантик» лаковые праздничные. Производитель: Дом обуви «Маленький франт», г. Москва', N'Верх — искусственная лаковая кожа (ПВХ), носок усиленный — термопластичный полиуретан, подкладка — кожа искусственная дышащая, стелька — анатомическая с амортизацией, подошва — полиуретан', N'IMG_KSho_185512.png', 2390),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Сапоги', N'Сапоги зимние натуральная кожа', N'Барбари', N'Сапоги женские зимние, нескользящая, устойчивая подошва, натуральный мех. Производитель: Дом обуви «Барбари», г. Новороссийск', N'Верх — натуральная кожа, подкладка — евромех, натуральный мех, текстильный утеплитель, подошва — резина', N'IMG_WB_170905.png', 25000),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Сапоги', N'Сапоги осенние натуральная кожа', N'Барбари', N'Сапоги женские демисезонные из высококачественной натуральной кожи. Производитель: Дом обуви «Барбари», г. Новороссийск', N'Верх — натуральная кожа, подкладка — текстильный утеплитель, стелька — текстиль, подошва — ТПР', N'IMG_WB_170859.png', 15000),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Сапоги', N'Сапоги трубы демисезонные замшевые', N'Твой комфорт', N'Сапоги женские демисезонные замшевые. Производитель: ОАО «Твой комфорт», г. Ярославль', N'Верх — натуральная замша, утепленные, тракторная подошва, стелька — байка, подошва — резина', N'IMG_WB_170906.png', 17000),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Босоножки', N'Босоножки «Песчаный берег» коричневые', N'Стиль и комфорт', N'Коричневая кожаная модель с открытым носком, боковой пряжкой и закрытым каблуком. Производитель: ИП «Стиль и комфорт», г. Санкт-Петербург', N'Верх — 100% козья кожа, подкладка — 100% кожа; подошва: 100% кожа', N'IMG_WSd_174332.png', 7500),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Босоножки', N'Женские босоножки «Черный кофе» со скульптурным каблуком', N'Кожевенные традиции', N'Открытый носок и ремешок со сборной пряжкой, низкий каблук и резиновая подошва гарантируют комфорт. Производитель: ЗАО «Кожевенные традиции», г. Вятка', N'Верх — кожа собственного производств, подкладка — кожа; подошва: резина', N'IMG_WSd_185156.png', 5600),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Босоножки', N'Босоножки женские «Летний бриз»', N'Модный силуэт', N'Босоножки женские кожаные белые, регулируемый ремешок, закрытый каблук и кожаная подошва. Производитель: ООО «Модный силуэт», г. Кострома', N'Верх — натуральная кожа, подкладка — натуральная кожа, подошва — кожа', N'IMG_WSd_185551.png', 7130),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Туфли', N'Демисезонные туфли натуральная кожа', N'Модный силуэт', N'Комфортные лаконичные лодочки, классический дизайна с современными акцентами. Производитель: ООО «Модный силуэт», г. Кострома', N'Верх — натуральная овечья кожа, подкладка и стелька — натуральная овечья кожа, подошва — резина', N'IMG_WSho_174409.png', 12340),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Туфли', N'Туфли женские натуральная кожа с металлическими вставками', N'Кожевенные традиции', N'Стильные туфли для весеннего и летнего сезона. Производитель: ЗАО «Кожевенные традиции», г. Вятка', N'Верх — натуральная телячьей кожа, металлическая пряжка, подкладка и стелька— натуральная овечья кожа, подошва — резина', N'IMG_WSho_185202.png', 7757),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Туфли', N'Туфли классические лодочки натуральная кожа', N'Стиль и комфорт', N'Модель из натуральной кожи, классический острый носок и изящная шпилька. Производитель: ИП «Стиль и комфорт», г. Санкт-Петербург', N'Верх — натуральная кожа, подкладка и стелька — натуральная кожа, подошва — тунит', N'IMG_WSho_185545.png', 7550),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Кроссовки', N'Кроссовки белые с оранжевым и красным', N'Топ-Топ', N'Многослойный верх из кожи и текстиля. Производитель: Фабрика «Топ-Топ», г. Киров', N'Верх — 70% кожа, 30% текстиль, подкладка — текстиль, подошва — резина', N'IMG_WS_174110.png', 9450),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Кроссовки', N'Кроссовки летние кожаные', N'Топ-Топ', N'Уверенность на каждом шагу. Материал обеспечивает долговечность и комфорт при носке. Производитель: Фабрика «Топ-Топ», г. Киров', N'Верх — 87% кожа, 11% текстиль, 2% синтетика; подкладка: 100% текстиль; подошва: резина, пластик', N'IMG_WS_185528.png', 8565),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Кроссовки', N'Кроссовки кожаные', N'Стиль и комфорт', N'Кроссовки женские из натуральной кожи. Производитель: ИП «Стиль и комфорт», г. Санкт-Петербург', N'Верх — натуральная кожа, подкладка — кожа, подошва — полиуретан', N'IMG_WS_185535.png', 8765),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Женская обувь'), N'Кроссовки', N'Кроссовки «Стиль и комфорт»', N'Стиль и комфорт', N'Кроссовки женские из натуральной кожи и синтетических материалов, сетчатые вставки. Производитель: ИП «Стиль и комфорт», г. Санкт-Петербург', N'Верх — 70% кожа, 20% полиамид, 10% полиуретан; подкладка — текстиль, подошва — ТПУ', N'IMG_WS_185538.png', 7795),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Кроссовки', N'Кроссовки для бега «Драйв»', N'Азимут', N'Сочетание стиля, комфорта и современных технологий. Производитель: Фабрика «Азимут», г. Санкт-Петербург', N'Верх — сетка, подкладка — текстиль, подошва — резина', N'IMG_MS_185531.png', 6550),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Кроссовки', N'Кроссовки «Азимут Бег»', N'Азимут', N'Универсальный выбор для повседневного использования. Производитель: Фабрика «Азимут», г. Санкт-Петербург', N'Верх — 6% кожа, 29% текстиль, 15% полимерные материалы; подкладка — 100% текстиль; подошва — полимерные материалы, резина', N'IMG_MS_185532.png', 7890),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Кроссовки', N'Кроссовки', N'Топ-Топ', N'Кроссовки для мужчин, идеальное сочетание стиля и комфорта. Производитель: Фабрика «Топ-Топ», г. Киров', N'Верх — 56% кожа, 29% текстиль, 15% полимерные материалы; подкладка — 100% текстиль; подошва — полимерные материалы, резина', N'IMG_MS_185533.png', 9567),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Туфли', N'Черные туфли в классическом стиле — база для деловых образов', N'Барбари', N'Модель выполнена из натуральной кожи, на резиновой подошве. Производитель: Дом обуви «Барбари», г. Новороссийск', N'Верх — натуральная кожа, подкладка — текстиль, стелька — натуральная кожа, подошва — резина', N'IMG_MSho_190514.png', 24569),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Туфли', N'Туфли мужские светлые классика демисезонные', N'Берестов', N'Туфли на низком каблуке кожаные', N'Верх — натуральная кожа, подкладка — текстиль, стелька — натуральная кожа, подошва — ТЭП', N'IMG_MSho_190518.png', 10155),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Туфли', N'Туфли из натуральной кожи', N'Берестов', N'Модель выполнена из натуральной кожи, на резиновой подошве, поддеживает классический и деловой стиль образов. Производитель: Дом обуви «Берестов», г. Москва', N'Верх — натуральная кожа, подкладка — натуральная кожа, стелька — натуральная кожа, подошва — резина', N'IMG_MSho_191612.png', 25625),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Ботинки', N'Ботинки мужские демисезонные', N'Барбари', N'Ботинки из натуральной кожи темно-коричневого и черного цвета на шнурках. Производитель: Дом обуви «Берестов», г. Москва', N'Верх — натуральная кожа, подкладка — текстиль, подошва — искусственный материал', N'IMG_MB_174349.png', 21500),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Ботинки', N'Ботинки черные из натуральной кожи', N'Кожевенные традиции', N'Ботинки представляют баланс традиций и современности. Выполнены из натуральной кожи насыщенного черного цвета. Производитель: ЗАО «Кожевенные традиции», г. Вятка', N'Верх — натуральная кожа, подкладка — ворсин, стелька — ворсин, подошва — тунит', N'IMG_MB_191200.png', 14567),
    ((SELECT CategoryId FROM Categories WHERE CategoryName = N'Мужская обувь'), N'Ботинки', N'Ботинки зимние классические', N'Барбари', N'Выбор на каждый день — натуральная кожа, натуральный мех. Производитель: Дом обуви «Барбари», г. Новороссийск', N'Верх — натуральная кожа, подкладка — натуральный мех, стелька — натуральный мех, подошва — ТЭП', N'IMG_MB_191205.png', 15670);
GO

-- ===================== ТОВАРНЫЕ ПОЗИЦИИ (МОДЕЛЬ + РАЗМЕР) =====================
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 20;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 21;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 22;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 23;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 24;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 25;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Гонщик» экокожа' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 33;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Гонщик» экокожа' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 34;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 30
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Радуга» экокожа перфорированная' AND p.Manufacturer = N'Лапушка' AND s.SizeValue = 19;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 30
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки детские «Радуга» экокожа перфорированная' AND p.Manufacturer = N'Лапушка' AND s.SizeValue = 20;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 15
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Снежинка» зимние на меху' AND p.Manufacturer = N'Тёплые ножки' AND s.SizeValue = 19;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 15
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Снежинка» зимние на меху' AND p.Manufacturer = N'Тёплые ножки' AND s.SizeValue = 20;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Медвежонок» демисезонные непромокаемые' AND p.Manufacturer = N'Северята' AND s.SizeValue = 21;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Медвежонок» демисезонные непромокаемые' AND p.Manufacturer = N'Северята' AND s.SizeValue = 22;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Медвежонок» демисезонные непромокаемые' AND p.Manufacturer = N'Северята' AND s.SizeValue = 23;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Принцесса» кожаные' AND p.Manufacturer = N'Весна' AND s.SizeValue = 18;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Принцесса» кожаные' AND p.Manufacturer = N'Весна' AND s.SizeValue = 19;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапожки детские «Принцесса» кожаные' AND p.Manufacturer = N'Весна' AND s.SizeValue = 20;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Пчёлка» ортопедические летние' AND p.Manufacturer = N'Здоровый шаг' AND s.SizeValue = 21;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Пчёлка» ортопедические летние' AND p.Manufacturer = N'Здоровый шаг' AND s.SizeValue = 22;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Пчёлка» ортопедические летние' AND p.Manufacturer = N'Здоровый шаг' AND s.SizeValue = 23;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Пчёлка» ортопедические летние' AND p.Manufacturer = N'Здоровый шаг' AND s.SizeValue = 24;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Морячок» текстильные с фиксатором' AND p.Manufacturer = N'Карапуз' AND s.SizeValue = 27;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Морячок» текстильные с фиксатором' AND p.Manufacturer = N'Карапуз' AND s.SizeValue = 28;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Морячок» текстильные с фиксатором' AND p.Manufacturer = N'Карапуз' AND s.SizeValue = 29;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Сандалии детские «Морячок» текстильные с фиксатором' AND p.Manufacturer = N'Карапуз' AND s.SizeValue = 30;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли детские «Бантик» лаковые праздничные' AND p.Manufacturer = N'Маленький франт' AND s.SizeValue = 18;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли детские «Бантик» лаковые праздничные' AND p.Manufacturer = N'Маленький франт' AND s.SizeValue = 19;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 7
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли детские «Бантик» лаковые праздничные' AND p.Manufacturer = N'Маленький франт' AND s.SizeValue = 20;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 12
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги зимние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 12
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги зимние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги осенние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги осенние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги трубы демисезонные замшевые' AND p.Manufacturer = N'Твой комфорт' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги трубы демисезонные замшевые' AND p.Manufacturer = N'Твой комфорт' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Сапоги трубы демисезонные замшевые' AND p.Manufacturer = N'Твой комфорт' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 10
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 10
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 10
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 10
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 10
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Женские босоножки «Черный кофе» со скульптурным каблуком' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 35;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки женские «Летний бриз»' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки женские «Летний бриз»' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Босоножки женские «Летний бриз»' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 25
FROM Products p, Sizes s
WHERE p.ProductName = N'Демисезонные туфли натуральная кожа' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 25
FROM Products p, Sizes s
WHERE p.ProductName = N'Демисезонные туфли натуральная кожа' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 25
FROM Products p, Sizes s
WHERE p.ProductName = N'Демисезонные туфли натуральная кожа' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли женские натуральная кожа с металлическими вставками' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли женские натуральная кожа с металлическими вставками' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли женские натуральная кожа с металлическими вставками' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 4
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли женские натуральная кожа с металлическими вставками' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 9
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли классические лодочки натуральная кожа' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 9
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли классические лодочки натуральная кожа' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки белые с оранжевым и красным' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 35;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 2
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки белые с оранжевым и красным' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки летние кожаные' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 37;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки летние кожаные' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 37.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки летние кожаные' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 5
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки летние кожаные' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 38.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 16
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 16
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 36;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 16
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 16
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Стиль и комфорт»' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Стиль и комфорт»' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 18
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки для бега «Драйв»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 41.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 18
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки для бега «Драйв»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 42;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 18
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки для бега «Драйв»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 42.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 18
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки для бега «Драйв»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 43;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 38;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 38.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 39;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 39.5;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 50
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 41;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 41;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 42;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Кроссовки' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 44;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Черные туфли в классическом стиле — база для деловых образов' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 40;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Черные туфли в классическом стиле — база для деловых образов' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 41;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 23
FROM Products p, Sizes s
WHERE p.ProductName = N'Черные туфли в классическом стиле — база для деловых образов' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 43;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 15
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли мужские светлые классика демисезонные' AND p.Manufacturer = N'Берестов' AND s.SizeValue = 42;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 15
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли мужские светлые классика демисезонные' AND p.Manufacturer = N'Берестов' AND s.SizeValue = 43;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 15
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли мужские светлые классика демисезонные' AND p.Manufacturer = N'Берестов' AND s.SizeValue = 44;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 3
FROM Products p, Sizes s
WHERE p.ProductName = N'Туфли из натуральной кожи' AND p.Manufacturer = N'Берестов' AND s.SizeValue = 44;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 1
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки мужские демисезонные' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 41;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 1
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки мужские демисезонные' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 42;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки черные из натуральной кожи' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 42;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 20
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки черные из натуральной кожи' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 43;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 30
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки зимние классические' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 41;
INSERT INTO StockItems (ProductId, SizeId, Quantity)
SELECT p.ProductId, s.SizeId, 30
FROM Products p, Sizes s
WHERE p.ProductName = N'Ботинки зимние классические' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 42;
GO

-- ===================== ЗАКАЗЫ (ИСТОРИЧЕСКИЕ, ИЗ Orders_import) =====================
-- Заказ №1 (Сидорова Анна Дмитриевна, 2026-04-02)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-02', UserId FROM Users WHERE Login = N'asidorova';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 2190
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 20;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 2790
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сандалии детские «Пчёлка» ортопедические летние' AND p.Manufacturer = N'Здоровый шаг' AND s.SizeValue = 22;
GO

-- Заказ №2 (Павлова Елена Петровна, 2026-04-05)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-05', UserId FROM Users WHERE Login = N'epavlova';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 25000
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сапоги зимние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 36;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7500
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Босоножки «Песчаный берег» коричневые' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 38;
GO

-- Заказ №3 (Васильева Ольга Игоревна, 2026-04-08)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-08', UserId FROM Users WHERE Login = N'ovasileva';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 17000
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сапоги трубы демисезонные замшевые' AND p.Manufacturer = N'Твой комфорт' AND s.SizeValue = 37;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 8565
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки летние кожаные' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 37;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7795
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки «Стиль и комфорт»' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;
GO

-- Заказ №4 (Лебедева Ирина Владимировна, 2026-04-12)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-12', UserId FROM Users WHERE Login = N'ilebedeva';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7757
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Туфли женские натуральная кожа с металлическими вставками' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 38;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 12340
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Демисезонные туфли натуральная кожа' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 38;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7130
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Босоножки женские «Летний бриз»' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 39;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 8765
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 36;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 15000
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сапоги осенние натуральная кожа' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 39;
GO

-- Заказ №5 (Морозов Сергей Павлович, 2026-04-18)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-18', UserId FROM Users WHERE Login = N'smorozov';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 9567
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 41;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 21500
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Ботинки мужские демисезонные' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 41;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7890
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 39;
GO

-- Заказ №6 (Михайлова Татьяна Юрьевна, 2026-04-22)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-22', UserId FROM Users WHERE Login = N'tmikhailova';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 24569
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Черные туфли в классическом стиле — база для деловых образов' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 40;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 14567
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Ботинки черные из натуральной кожи' AND p.Manufacturer = N'Кожевенные традиции' AND s.SizeValue = 42;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 15670
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Ботинки зимние классические' AND p.Manufacturer = N'Барбари' AND s.SizeValue = 41;
GO

-- Заказ №7 (Алексеев Артём Евгеньевич, 2026-04-25)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-25', UserId FROM Users WHERE Login = N'aalekseev';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 4290
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сапожки детские «Принцесса» кожаные' AND p.Manufacturer = N'Весна' AND s.SizeValue = 18;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 2, 2190
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки детские «Звёздочка» экокожа' AND p.Manufacturer = N'Малыш-Спорт' AND s.SizeValue = 21;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 1690
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сандалии детские «Морячок» текстильные с фиксатором' AND p.Manufacturer = N'Карапуз' AND s.SizeValue = 28;
GO

-- Заказ №8 (Николаев Владимир Иванович, 2026-04-28)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-04-28', UserId FROM Users WHERE Login = N'vnikolaev';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 25625
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Туфли из натуральной кожи' AND p.Manufacturer = N'Берестов' AND s.SizeValue = 44;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 3, 7890
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки «Азимут Бег»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 40;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 2, 6550
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки для бега «Драйв»' AND p.Manufacturer = N'Азимут' AND s.SizeValue = 43;
GO

-- Заказ №9 (Смирнов Дмитрий Владимирович, 2026-05-05)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-05-05', UserId FROM Users WHERE Login = N'dsmirnov';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 2490
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки детские «Гонщик» экокожа' AND p.Manufacturer = N'Топ-Топ' AND s.SizeValue = 33;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 2, 3190
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Сапожки детские «Медвежонок» демисезонные непромокаемые' AND p.Manufacturer = N'Северята' AND s.SizeValue = 22;
GO

-- Заказ №10 (Павлова Елена Петровна, 2026-05-08)
DECLARE @OrderId INT;
INSERT INTO Orders (OrderDate, UserId) SELECT '2026-05-08', UserId FROM Users WHERE Login = N'epavlova';
SET @OrderId = SCOPE_IDENTITY();
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7550
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Туфли классические лодочки натуральная кожа' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 7130
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Босоножки женские «Летний бриз»' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 37;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 1, 12340
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Демисезонные туфли натуральная кожа' AND p.Manufacturer = N'Модный силуэт' AND s.SizeValue = 36;
INSERT INTO OrderItems (OrderId, StockItemId, Quantity, UnitPrice)
SELECT @OrderId, si.StockItemId, 2, 8765
FROM StockItems si JOIN Products p ON p.ProductId = si.ProductId JOIN Sizes s ON s.SizeId = si.SizeId
WHERE p.ProductName = N'Кроссовки кожаные' AND p.Manufacturer = N'Стиль и комфорт' AND s.SizeValue = 35;

GO
