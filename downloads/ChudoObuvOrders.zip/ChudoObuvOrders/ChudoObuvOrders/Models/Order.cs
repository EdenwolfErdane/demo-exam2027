using System;
using System.Collections.Generic;

namespace ChudoObuvOrders.Models
{
    // Заказ.
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public int UserId { get; set; }
        public string UserFullName { get; set; }
    }

    // Позиция состава заказа — для формы состава.
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int StockItemId { get; set; }
        public string ProductName { get; set; }
        public string Manufacturer { get; set; }
        public decimal SizeValue { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        // Сумма строки.
        public decimal Total => Quantity * UnitPrice;
    }

    // Позиция корзины — то, что ещё не оформлено в заказ.
    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Manufacturer { get; set; }
        public int StockItemId { get; set; }
        public decimal SizeValue { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        // Сумма строки.
        public decimal Total => Quantity * UnitPrice;
    }

    // Хранит корзину и признак "оформляем на клиента" в рамках сессии.
    public static class CartContext
    {
        // Позиции корзины.
        public static List<CartItem> Items { get; } = new List<CartItem>();

        // Если задан — заказ оформляется менеджером/админом на этого клиента.
        public static User OrderOnBehalfOf { get; set; }

        // Полная очистка корзины и сброс "на кого оформляем".
        public static void Clear()
        {
            Items.Clear();
            OrderOnBehalfOf = null;
        }
    }
}