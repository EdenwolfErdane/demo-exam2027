﻿using System;
using System.Data;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Корзина и оформление заказа. Вид — в CartForm.Designer.cs.
public partial class CartForm : Form
{
    Чудо_ОбувьDataSet ds = Session.Data;

    public CartForm()
    {
        InitializeComponent();
        gridCart.DataSource = Session.Cart;   // таблица сама показывает список
        // Менеджер и администратор оформляют заказ на выбранного клиента.
        lblClient.Visible = cmbClient.Visible = Session.IsStaff;
        if (Session.IsStaff)
        {
            // Клиенты — строки таблицы Пользователи; ФИО собирает выражение столбца.
            new ПользователиTableAdapter().Fill(ds.Пользователи);
            if (!ds.Пользователи.Columns.Contains("ФИО"))
                ds.Пользователи.Columns.Add("ФИО", typeof(string),
                    "Фамилия + ' ' + Имя + ' ' + IsNull(Отчество, '')");
            cmbClient.DisplayMember = "ФИО";
            cmbClient.ValueMember = "Код_пользователя";
            cmbClient.DataSource = new DataView(ds.Пользователи, "", "Фамилия", DataViewRowState.CurrentRows);
        }
    }

    // Изменить количество у выбранной строки.
    private void btnQty_Click(object sender, EventArgs e)
    {
        if (gridCart.CurrentRow == null) return;
        int i = gridCart.CurrentRow.Index;
        Session.Cart[i].Qty = (int)nudQty.Value;
        Session.Cart.ResetItem(i);   // перерисовать строку
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (gridCart.CurrentRow != null) Session.Cart.RemoveAt(gridCart.CurrentRow.Index);
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        if (MessageBox.Show("Очистить корзину?", "Отказ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        { Session.Cart.Clear(); Close(); }
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }

    private void btnConfirm_Click(object sender, EventArgs e)
    {
        if (Session.Cart.Count == 0) { MessageBox.Show("Корзина пуста.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        if (MessageBox.Show("Оформить заказ?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            int clientId = Session.IsStaff ? (int)cmbClient.SelectedValue : Session.UserId;

            // Таблицы, куда пишем, загружают адаптеры из мастера.
            new ЗаказыTableAdapter().Fill(ds.Заказы);
            new Строки_заказовTableAdapter().Fill(ds.Строки_заказов);
            var склад = new Товарные_позицииTableAdapter();
            склад.Fill(ds.Товарные_позиции);

            // Сначала проверяем, что всего хватает, потом списываем — всё или ничего.
            foreach (var l in Session.Cart)
            {
                var check = ds.Товарные_позиции.FindByКод_позиции(l.StockItemId);
                if (check == null || check.Количество < l.Qty)
                    throw new Exception("Не хватает на складе: " + l.Name);
            }

            // Новый заказ: строка в таблице Заказы; ключ придёт сам после Update.
            var order = ds.Заказы.NewЗаказыRow();
            order.Дата_заказа = DateTime.Now;
            order.Код_пользователя = clientId;
            ds.Заказы.AddЗаказыRow(order);

            foreach (var l in Session.Cart)
            {
                var pos = ds.Товарные_позиции.FindByКод_позиции(l.StockItemId);
                pos.Количество -= l.Qty;   // списали со склада
                var line = ds.Строки_заказов.NewСтроки_заказовRow();
                line.Код_заказа = order.Код_заказа;
                line.Код_позиции = pos.Код_позиции;
                line.Количество = l.Qty;
                line.Цена_за_единицу = l.Price;
                ds.Строки_заказов.AddСтроки_заказовRow(line);
            }

            // Update отправляет изменения в базу — сначала заказ, потом строки.
            new ЗаказыTableAdapter().Update(ds.Заказы);
            склад.Update(ds.Товарные_позиции);
            new Строки_заказовTableAdapter().Update(ds.Строки_заказов);

            Session.Cart.Clear();
            MessageBox.Show("Заказ оформлен.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Не удалось оформить заказ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
