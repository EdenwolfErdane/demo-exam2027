using System.Drawing;

namespace ChudoObuvOrders.UI
{
    // Единая цветовая схема и шрифт для всех форм.
    public static class AppStyle
    {
        // Основной фон.
        public static readonly Color BackgroundColor = ColorTranslator.FromHtml("#FFFFFF");
        // Дополнительный фон (панели).
        public static readonly Color SecondaryBackgroundColor = ColorTranslator.FromHtml("#D2F6E7");
        // Акцент (кнопки целевого действия).
        public static readonly Color AccentColor = ColorTranslator.FromHtml("#70B2AF");
        // Подсветка "мало на складе".
        public static readonly Color LowStockColor = ColorTranslator.FromHtml("#FF8080");

        // Шрифты.
        public static readonly Font DefaultFont = new Font("Calibri", 10F);
        public static readonly Font TitleFont = new Font("Calibri", 14F, FontStyle.Bold);
        public static readonly Font PriceFont = new Font("Calibri", 12F, FontStyle.Bold);

        // Пути к ресурсам.
        public const string AppIconPath = @"Resources\Чудо Обувь.ico";
        public const string LogoPath = @"Resources\Чудо Обувь.png";
        public const string PlaceholderImagePath = @"Resources\picture.png";
        public const string ImagesFolder = @"Resources\Images";
    }
}