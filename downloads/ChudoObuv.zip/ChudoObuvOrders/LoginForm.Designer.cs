﻿partial class LoginForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
        this.pnlHeader = new System.Windows.Forms.Panel();
        this.lblTitle = new System.Windows.Forms.Label();
        this.lblSub = new System.Windows.Forms.Label();
        this.pnlBody = new System.Windows.Forms.Panel();
        this.lblLogin = new System.Windows.Forms.Label();
        this.txtLogin = new System.Windows.Forms.TextBox();
        this.btnOk = new System.Windows.Forms.Button();
        this.btnGuest = new System.Windows.Forms.Button();
        this.lblHint = new System.Windows.Forms.Label();
        this.pnlHeader.SuspendLayout();
        this.pnlBody.SuspendLayout();
        this.SuspendLayout();
        //
        // pnlHeader — бирюзовая шапка окна
        //
        this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.pnlHeader.Controls.Add(this.lblTitle);
        this.pnlHeader.Controls.Add(this.lblSub);
        this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
        this.pnlHeader.Location = new System.Drawing.Point(0, 0);
        this.pnlHeader.Name = "pnlHeader";
        this.pnlHeader.Size = new System.Drawing.Size(420, 78);
        //
        // lblTitle
        //
        this.lblTitle.AutoSize = true;
        this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 16F);
        this.lblTitle.ForeColor = System.Drawing.Color.White;
        this.lblTitle.Location = new System.Drawing.Point(24, 14);
        this.lblTitle.Name = "lblTitle";
        this.lblTitle.Size = new System.Drawing.Size(124, 30);
        this.lblTitle.Text = "Чудо Обувь";
        //
        // lblSub
        //
        this.lblSub.AutoSize = true;
        this.lblSub.Font = new System.Drawing.Font("Segoe UI", 9.5F);
        this.lblSub.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(245)))), ((int)(((byte)(243)))));
        this.lblSub.Location = new System.Drawing.Point(24, 48);
        this.lblSub.Name = "lblSub";
        this.lblSub.Size = new System.Drawing.Size(155, 17);
        this.lblSub.Text = "Система заказа обуви · вход";
        //
        // pnlBody — светлая панель содержимого
        //
        this.pnlBody.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(250)))), ((int)(((byte)(248)))));
        this.pnlBody.Controls.Add(this.lblLogin);
        this.pnlBody.Controls.Add(this.txtLogin);
        this.pnlBody.Controls.Add(this.btnOk);
        this.pnlBody.Controls.Add(this.btnGuest);
        this.pnlBody.Controls.Add(this.lblHint);
        this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
        this.pnlBody.Location = new System.Drawing.Point(0, 78);
        this.pnlBody.Name = "pnlBody";
        this.pnlBody.Size = new System.Drawing.Size(420, 182);
        //
        // lblLogin
        //
        this.lblLogin.AutoSize = true;
        this.lblLogin.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.lblLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(50)))), ((int)(((byte)(56)))));
        this.lblLogin.Location = new System.Drawing.Point(24, 22);
        this.lblLogin.Name = "lblLogin";
        this.lblLogin.Size = new System.Drawing.Size(53, 19);
        this.lblLogin.Text = "Логин";
        //
        // txtLogin
        //
        this.txtLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.txtLogin.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.txtLogin.Location = new System.Drawing.Point(24, 46);
        this.txtLogin.Name = "txtLogin";
        this.txtLogin.Size = new System.Drawing.Size(372, 25);
        this.txtLogin.TabIndex = 1;
        //
        // btnOk
        //
        this.btnOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnOk.FlatAppearance.BorderSize = 0;
        this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnOk.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnOk.ForeColor = System.Drawing.Color.White;
        this.btnOk.Location = new System.Drawing.Point(24, 90);
        this.btnOk.Name = "btnOk";
        this.btnOk.Size = new System.Drawing.Size(180, 36);
        this.btnOk.TabIndex = 2;
        this.btnOk.Text = "Войти";
        this.btnOk.UseVisualStyleBackColor = false;
        this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
        //
        // btnGuest
        //
        this.btnGuest.BackColor = System.Drawing.Color.White;
        this.btnGuest.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnGuest.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(178)))), ((int)(((byte)(175)))));
        this.btnGuest.FlatAppearance.BorderSize = 1;
        this.btnGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnGuest.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
        this.btnGuest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(138)))), ((int)(((byte)(136)))));
        this.btnGuest.Location = new System.Drawing.Point(216, 90);
        this.btnGuest.Name = "btnGuest";
        this.btnGuest.Size = new System.Drawing.Size(180, 36);
        this.btnGuest.TabIndex = 3;
        this.btnGuest.Text = "Без входа";
        this.btnGuest.UseVisualStyleBackColor = false;
        this.btnGuest.Click += new System.EventHandler(this.btnGuest_Click);
        //
        // lblHint
        //
        this.lblHint.AutoSize = false;
        this.lblHint.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.lblHint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(116)))), ((int)(((byte)(122)))));
        this.lblHint.Location = new System.Drawing.Point(24, 138);
        this.lblHint.Name = "lblHint";
        this.lblHint.Size = new System.Drawing.Size(372, 34);
        this.lblHint.Text = "isivanov — администратор · papetrov — менеджер · asidorova — пользователь. Вход без пароля.";
        //
        // LoginForm
        //
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
        this.BackColor = System.Drawing.Color.White;
        this.ClientSize = new System.Drawing.Size(420, 260);
        this.Controls.Add(this.pnlBody);
        this.Controls.Add(this.pnlHeader);
        this.Font = new System.Drawing.Font("Segoe UI", 10F);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MaximizeBox = false;
        this.Name = "LoginForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Чудо Обувь — Вход";
        this.pnlHeader.ResumeLayout(false);
        this.pnlHeader.PerformLayout();
        this.pnlBody.ResumeLayout(false);
        this.pnlBody.PerformLayout();
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.Panel pnlHeader;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.Label lblSub;
    private System.Windows.Forms.Panel pnlBody;
    private System.Windows.Forms.Label lblLogin;
    private System.Windows.Forms.TextBox txtLogin;
    private System.Windows.Forms.Button btnOk;
    private System.Windows.Forms.Button btnGuest;
    private System.Windows.Forms.Label lblHint;
}
