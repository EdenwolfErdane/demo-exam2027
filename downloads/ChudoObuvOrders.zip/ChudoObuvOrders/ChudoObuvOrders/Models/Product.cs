namespace ChudoObuvOrders.Models
{
    // Строка каталога товаров (собирается в ProductRepository).
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Manufacturer { get; set; }
        public string Description { get; set; }
        public string Composition { get; set; }
        public string ImageFileName { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public decimal BasePrice { get; set; }
        public decimal DiscountPrice { get; set; }
        public int TotalQuantity { get; set; }

        // Скидка есть, если цена со скидкой меньше базовой.
        public bool HasDiscount => DiscountPrice < BasePrice;

        // "много" / "мало": больше 5 — много, иначе мало.
        public string QuantityLabel => TotalQuantity > 5 ? "много" : "мало";

        // Подсветка "мало на складе", если 3 или меньше.
        public bool IsLowStock => TotalQuantity <= 3;
    }
}