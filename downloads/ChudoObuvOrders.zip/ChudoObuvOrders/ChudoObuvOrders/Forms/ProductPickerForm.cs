using System;
using System.Linq;
using System.Windows.Forms;
using ChudoObuvOrders.Data;
using ChudoObuvOrders.Models;
using ChudoObuvOrders.UI;

namespace ChudoObuvOrders.Forms
{
    // Форма выбора товаров для заказа (когда менеджер оформляет на клиента).
    //
    // Компоненты (в дизайнере):
    //   lblClient    — ФИО клиента
    //   txtSearch    — поиск по имени товара
    //   lstProducts  — список найденных товаров
    //   btnSelect    — открыть карточку товара
    //   btnGoToCart  — перейти в корзину
    //   btnCancel    — отмена
    public partial class ProductPickerForm : Form
    {
        // Репозиторий товаров.
        private readonly ProductRepository _productRepository = new ProductRepository();
        // Найденные товары.
        private System.Collections.Generic.List<Product> _found = new System.Collections.Generic.List<Product>();

        public ProductPickerForm(User client)
        {
            InitializeComponent();

            // Внешний вид.
            Text = "Чудо Обувь — Добавление заказа";
            Icon = new System.Drawing.Icon(AppStyle.AppIconPath);
            BackColor = AppStyle.BackgroundColor;
            pnlTop.BackColor = AppStyle.SecondaryBackgroundColor;
            pnlBottom.BackColor = AppStyle.SecondaryBackgroundColor;
            Font = AppStyle.DefaultFont;

            // Запоминаем, на кого оформляем заказ, и чистим корзину.
            CartContext.OrderOnBehalfOf = client;
            CartContext.Items.Clear();
            lblClient.Text = $"Клиент: {client.FullName}";

            // Обработчики.
            txtSearch.TextChanged += (s, e) => Search();
            btnSelect.Click += (s, e) => SelectProduct();
            lstProducts.DoubleClick += (s, e) => SelectProduct();
            btnGoToCart.Click += (s, e) => GoToCart();
            btnCancel.Click += (s, e) => { CartContext.Clear(); Close(); };

            // При загрузке — сразу поиск (покажет все товары).
            Load += (s, e) => Search();
        }

        // Ищет товары и заполняет список.
        private void Search()
        {
            _found = _productRepository.GetCatalog(txtSearch.Text, null, PriceSortOrder.None);
            lstProducts.DataSource = null;
            lstProducts.DisplayMember = "Display";
            lstProducts.DataSource = _found
                .Select(p => new { p.ProductId, Display = $"{p.Manufacturer} | {p.ProductName}" })
                .ToList();
        }

        // Открывает карточку выбранного товара.
        private void SelectProduct()
        {
            if (lstProducts.SelectedIndex < 0) return;

            int productId = _found[lstProducts.SelectedIndex].ProductId;
            using (var form = new ProductDetailForm(productId))
                Navigator.OpenModal(this, form);

            // Обновляем счётчик в кнопке корзины.
            btnGoToCart.Text = $"Перейти к корзине ({CartContext.Items.Count})";
        }

        // Переход в корзину.
        private void GoToCart()
        {
            if (CartContext.Items.Count == 0)
            {
                MessageBox.Show(this, "Добавьте хотя бы одну товарную позицию в заказ.",
                    "Заказ пуст", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var cartForm = new CartForm())
            {
                var result = Navigator.OpenModal(this, cartForm);
                if (result == DialogResult.OK) DialogResult = DialogResult.OK;
            }
        }
    }
}