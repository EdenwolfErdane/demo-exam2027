﻿using System;
using System.Data;
using System.Windows.Forms;
using ChudoObuvOrders;
using ChudoObuvOrders.Чудо_ОбувьDataSetTableAdapters;

// Статистика заказов (задание 5). Вид — в StatisticsForm.Designer.cs.
public partial class StatisticsForm : Form
{
    public StatisticsForm()
    {
        InitializeComponent();
        LoadStats();
    }

    void LoadStats()
    {
        var ds = Session.Data;
        // Заказы, клиенты и строки заказов загружают адаптеры из мастера.
        new ЗаказыTableAdapter().Fill(ds.Заказы);
        new ПользователиTableAdapter().Fill(ds.Пользователи);
        new Строки_заказовTableAdapter().Fill(ds.Строки_заказов);

        // Таблица для списка заказов. Сумма каждого заказа — по его строкам
        // (Количество × Цена за единицу); у заказа без строк сумма будет 0.
        var t = new DataTable("Заказы");
        t.Columns.Add("Номер", typeof(int));
        t.Columns.Add("Дата", typeof(DateTime));
        t.Columns.Add("Клиент", typeof(string));
        t.Columns.Add("Сумма", typeof(decimal));
        foreach (var o in ds.Заказы)
        {
            decimal sum = 0;
            foreach (var oi in o.GetСтроки_заказовRows())
                sum += oi.Количество * oi.Цена_за_единицу;
            var u = o.ПользователиRow;
            t.Rows.Add(o.Код_заказа, o.Дата_заказа,
                u == null ? "" : u.Фамилия + " " + u.Имя, sum);
        }
        gridOrders.DataSource = t;

        // Три показателя считаем по уже выведенной таблице.
        decimal revenue = 0;
        foreach (DataRow r in t.Rows) revenue += (decimal)r["Сумма"];
        int count = t.Rows.Count;
        lblCount.Text = "Всего заказов: " + count;
        lblRevenue.Text = "Общая выручка: " + revenue.ToString("N2") + " ₽";
        lblAverage.Text = "Средний чек: " + (count == 0 ? 0m : revenue / count).ToString("N2") + " ₽";
    }

    private void btnBack_Click(object sender, EventArgs e) { Close(); }
}
