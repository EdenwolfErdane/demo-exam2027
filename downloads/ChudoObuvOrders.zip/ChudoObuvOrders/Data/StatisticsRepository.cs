// Linq — для суммирования и средней.
using System.Linq;
// Модели заказов.
using ChudoObuvOrders.Models;

namespace ChudoObuvOrders.Data
{
    // Строка таблицы статистики: заказ и его итоговая сумма.
    public class OrderTotalRow
    {
        // Номер заказа.
        public int OrderId { get; set; }
        // Дата заказа.
        public System.DateTime OrderDate { get; set; }
        // ФИО клиента.
        public string ClientName { get; set; }
        // Итоговая сумма заказа.
        public decimal OrderTotal { get; set; }
    }

    // Три общих показателя по всем заказам.
    public class OrderStatistics
    {
        // Общее количество заказов.
        public int OrdersCount { get; set; }
        // Общая сумма выручки.
        public decimal TotalRevenue { get; set; }
        // Средняя стоимость заказа.
        public decimal AverageOrder { get; set; }
    }

    // Считает общую статистику по заказам (Задание 5).
    public class StatisticsRepository
    {
        // Заказы с итоговой суммой каждого заказа.
        public System.Collections.Generic.List<OrderTotalRow> GetOrderTotals()
        {
            // Заказы уже с ФИО клиента.
            var repo = new OrderRepository();
            var orders = repo.GetOrders();

            // Сюда собираем результат.
            var result = new System.Collections.Generic.List<OrderTotalRow>();

            // Для каждого заказа считаем сумму его позиций.
            foreach (var order in orders)
            {
                // Позиции конкретного заказа.
                var items = repo.GetOrderItems(order.OrderId);

                result.Add(new OrderTotalRow
                {
                    OrderId = order.OrderId,
                    OrderDate = order.OrderDate,
                    ClientName = order.UserFullName,
                    // Сумма заказа = сумма сумм его позиций.
                    OrderTotal = items.Sum(i => i.Total)
                });
            }

            return result;
        }

        // Общие показатели: количество, выручка, средний чек.
        public OrderStatistics GetStatistics()
        {
            // Те же строки, по которым строится таблица.
            var rows = GetOrderTotals();

            return new OrderStatistics
            {
                OrdersCount = rows.Count,
                TotalRevenue = rows.Sum(r => r.OrderTotal),
                // Делить на ноль нельзя — проверяем количество.
                AverageOrder = rows.Count == 0 ? 0 : rows.Sum(r => r.OrderTotal) / rows.Count
            };
        }
    }
}
