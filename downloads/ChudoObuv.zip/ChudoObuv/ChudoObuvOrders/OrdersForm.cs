using System;
using System.Data;
using System.Windows.Forms;

// Заказы (менеджер/админ). Вид — в OrdersForm.Designer.cs.
public partial class OrdersForm : Form
{
    public OrdersForm()
    {
        InitializeComponent();
        // Дата и удаление позиции — только администратору.
        dtp.Visible = btnDate.Visible = btnDelItem.Visible = Session.IsAdmin;
        LoadOrders();
    }

    int OrderId() { return gridOrders.CurrentRow == null ? 0 : (int)gridOrders.CurrentRow.Cells["Номер"].Value; }

    void LoadOrders()
    {
        gridOrders.DataSource = Db.Table(@"SELECT o.Код_заказа AS Номер, o.Дата_заказа AS Дата, u.Фамилия + ' ' + u.Имя AS Клиент
                                           FROM Заказы o JOIN Пользователи u ON u.Код_пользователя = o.Код_пользователя ORDER BY o.Дата_заказа DESC");
        LoadItems();
    }

    void LoadItems()
    {
        var t = Db.Table(@"SELECT oi.Код_строки AS Код, p.Производство + ' | ' + p.Наименование AS Модель, z.Размер AS Размер, oi.Количество AS Количество, oi.Цена_за_единицу AS Цена
                           FROM Строки_заказов oi JOIN Товарные_позиции s ON s.Код_позиции = oi.Код_позиции
                           JOIN Товары p ON p.Код_товара = s.Код_товара JOIN Размеры z ON z.Код_размера = s.Код_размера
                           WHERE oi.Код_заказа = @o", "@o", OrderId());
        gridItems.DataSource = t;
        decimal sum = 0;
        foreach (DataRow r in t.Rows) sum += (int)r["Количество"] * (decimal)r["Цена"];
        lblTotal.Text = "Итого: " + sum.ToString("N2") + " ₽";
    }

    // Выбрали заказ — показываем его состав.
    private void gridOrders_SelectionChanged(object sender, EventArgs e) { LoadItems(); }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        // Каталог с поиском → карточка → корзина → выбор клиента → подтверждение.
        new MainForm(true).ShowDialog();
        LoadOrders();
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (OrderId() == 0) return;
        if (MessageBox.Show("Удалить заказ и вернуть товар на склад?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        // Сначала вернуть остатки, потом удалить (позиции удалятся каскадом).
        Db.Run(@"UPDATE s SET s.Количество = s.Количество + oi.Количество FROM Товарные_позиции s
                 JOIN Строки_заказов oi ON oi.Код_позиции = s.Код_позиции WHERE oi.Код_заказа = @o", "@o", OrderId());
        Db.Run("DELETE FROM Заказы WHERE Код_заказа = @o", "@o", OrderId());
        LoadOrders();
    }

    private void btnDate_Click(object sender, EventArgs e)
    {
        if (OrderId() == 0) return;
        Db.Run("UPDATE Заказы SET Дата_заказа = @d WHERE Код_заказа = @o", "@d", dtp.Value, "@o", OrderId());
        LoadOrders();
    }

    private void btnDelItem_Click(object sender, EventArgs e)
    {
        if (gridItems.CurrentRow == null) return;
        int id = (int)gridItems.CurrentRow.Cells["Код"].Value;
        Db.Run(@"UPDATE s SET s.Количество = s.Количество + oi.Количество FROM Товарные_позиции s
                 JOIN Строки_заказов oi ON oi.Код_позиции = s.Код_позиции WHERE oi.Код_строки = @i", "@i", id);
        Db.Run("DELETE FROM Строки_заказов WHERE Код_строки = @i", "@i", id);
        LoadItems();
    }
}
